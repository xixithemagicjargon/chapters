# Chapters Interactive Novel Plugin

Chapters 编辑在 ChatGPT/Codex Local Project 中使用的内部审核插件。支持只读解析 `.xlsx` 剧本与 `.docx` 大纲、确定性 Metrics、可追溯的编辑评判、英文流畅度检查、完整审核、DOCX 大纲评审，以及独立的 v1.7 付费结构与商业化重构；不会回写源文件。

## 核心设计

- 在每次 `prepare` 尝试内，Workbook Adapter 将每个明确传入的 Excel 源快照解析一次，并发布不可变、自包含的 StoryBundle。
- `story-bundle/manifest.json` 是所有下游的唯一入口。Bundle 完成后，Metrics、Agent 和报告都不得再读取 Excel。
- Agent 先读 manifest，再用 `jq`、`rg` 和 `sed` 按章、Choice 或有界文本窗口渐进读取；确认候选问题后才读 `source-map.ndjson`。
- Runtime 只负责解析、确定性计算和必要验证；Agent 直接阅读 Bundle 与 Rubric，写 notes、annotations 和 findings。
- 确定性产物位于 `derived/metrics/<metrics-id>/`，Agent 产物位于 `analysis/`，两者不写入 StoryBundle。
- `prepare` 的可修复输入错误会提供结构化问题清单，并在能够定位时给出文件/Sheet/行列与修复提示；Agent 用中文指导编辑修复，但永不自动改写原 Excel。

## 对话入口

- `review-chapters-script`：完整审计，产出 `analysis/audit-report.md` 与编辑可转发的 `analysis/editor-summary.docx`。
- `check-chapters-metrics`：PC/FC/PO、价格、行数、比例、间隔和格式等确定性问题。
- `evaluate-chapters-script`：付费节点、L2 升级、回报、按钮与分支连贯性等专项编辑评判。
- `check-english-fluency`：单独检查翻译腔、语域、句式、对白节奏和术语一致性。
- `interactive-fiction-monetization-review`：独立解析付费结构、分析或优化付费选项，并按 v1.7 生成唯一一套编辑式商业化重构报告。
- `interactive-fiction-outline-review`：读取 DOCX 小说大纲，先检查书名、故事线、重点人物介绍及逐章 PC/Sub-PC/PO/场景等内容是否缺失，再评审逻辑、逐章男女主感情变化、钩子与付费机会；每条结论用“章节或文档区域＋Scene/选择节点＋可搜索原文”定位，不输出行号或段落号。报告目录根层只放 Markdown 报告，JSON、JS 和其他中间文件统一放在 `working-files/`。

六个 Skill 都是用户意图入口，彼此不调用。前四个使用当前共享规则；第 5 个只复用同一套只读解析和确定性数字，其 v1.7 专业标准与现有审核规则隔离；第 6 个只读 DOCX 大纲，并使用独立的大纲评审标准。

## 编辑使用

插件安装完成后请新建对话，打开存有待审 `.xlsx` 或 `.docx` 的 Local Project，然后直接用自然语言提出请求。例如：“完整审核这些 Excel”“检查第 1、3 章的 PC/FC 和价格”“评价这些付费分支是否值得”“检查英文是否地道”“分析并优化这些付费选项，给一套商业化重构方案”，或“评审这份 DOCX 小说大纲”。Agent 会按意图选择一个入口；指定 DOCX 但未指定 Skill 或只是说“帮我看看”时，会先读取内容，确认为小说大纲后询问是否使用“互动小说大纲评审”技能，得到明确同意后才开始评审和生成报告。已经指定该 Skill 或明确要求大纲评审时不重复询问；明确指定其他 Skill 或翻译、排版等具体任务时仍按原请求处理。源文件始终保持不变。

v0.1.0 只定义安装后的使用行为；ZIP、GitLab、签名与团队分发流程不在本版本范围内。

## Agent 命令

以下相对路径命令从插件根目录运行；当前目录不在插件中时，使用 `python3 <plugin-root>/shared/scripts/chapters.py ...`。

```text
python3 shared/scripts/chapters.py prepare     ...
python3 shared/scripts/chapters.py metrics     ...
python3 shared/scripts/chapters.py validate    ...
python3 shared/scripts/chapters.py editor-docx ...
```

`prepare` 是唯一可读取 Excel 的命令；`metrics` 和 `validate` 都从已发布的 manifest 开始；`editor-docx` 只把 Agent 写好的摘要渲染成编辑可转发的 .docx，不读 Bundle。各命令返回 receipt，Agent 使用 receipt 中的准确路径，不猜测 Bundle 或 Metrics 目录。

详细契约见 [StoryBundle](shared/references/story-bundle.md)、[CLI 错误](shared/references/command-errors.md)、[审核状态](shared/references/review-state.md)、[Findings](shared/references/findings.md) 和 [v0.1.0 设计基线](docs/plugin-design.md)。规则权威仅有 [Metrics 配置](shared/rules/metrics-config.json) 与 [Editorial Rubric](shared/rules/editorial-rubric.md)。
