#!/usr/bin/env python3
"""Extract ordered text and structural candidates from a DOCX outline.

This script is deliberately read-only and uses only the Python standard library.
It does not execute macros, links, embedded objects, or instructions in the file.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path
from typing import Any, Iterable
from xml.etree import ElementTree as ET


W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS = {"w": W_NS}

CHAPTER_RE = re.compile(
    r"^\s*[*#\-•]*\s*(?:new\s+)?chapter\s*(?P<number>\d+)\b", re.IGNORECASE
)
SCENE_RE = re.compile(
    r"^\s*scene\s*(?P<number>\d+)?\s*(?:[:：.\-]|$)", re.IGNORECASE
)
CHOICE_RE = re.compile(
    r"^\s*(?P<label>"
    r"(?:outfit\s+|paid\s+|premium\s+)?"
    r"(?:sub\s*[- ]?\s*)?"
    r"(?:pc|fc|po|outfit)"
    r")\s*(?P<option_number>\d*)",
    re.IGNORECASE,
)
PRICE_WITH_UNIT_RE = re.compile(
    r"(?P<value>\d{1,3})\s*(?P<unit>gems?|diamonds?|钻)", re.IGNORECASE
)
PAREN_PRICE_RE = re.compile(r"[（(]\s*(?P<value>\d{1,3})\s*[）)]")


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def attr(element: ET.Element, namespace: str, name: str) -> str | None:
    return element.get(f"{{{namespace}}}{name}")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_xml(archive: zipfile.ZipFile, member: str) -> ET.Element | None:
    try:
        return ET.fromstring(archive.read(member))
    except KeyError:
        return None


def load_style_names(archive: zipfile.ZipFile) -> dict[str, str]:
    root = parse_xml(archive, "word/styles.xml")
    if root is None:
        return {}
    styles: dict[str, str] = {}
    for style in root.findall(".//w:style", NS):
        style_id = attr(style, W_NS, "styleId")
        name_node = style.find("./w:name", NS)
        style_name = attr(name_node, W_NS, "val") if name_node is not None else None
        if style_id:
            styles[style_id] = style_name or style_id
    return styles


def core_properties(archive: zipfile.ZipFile) -> dict[str, str]:
    root = parse_xml(archive, "docProps/core.xml")
    if root is None:
        return {}
    wanted = {"title", "subject", "creator", "description", "keywords", "lastModifiedBy"}
    properties: dict[str, str] = {}
    for node in root.iter():
        name = local_name(node.tag)
        if name in wanted and node.text and node.text.strip():
            properties[name] = node.text.strip()
    return properties


def element_text(element: ET.Element) -> str:
    parts: list[str] = []

    def visit(node: ET.Element, deleted: bool = False) -> None:
        name = local_name(node.tag)
        deleted = deleted or name == "del"
        if not deleted:
            if name == "t" and node.text:
                parts.append(node.text)
            elif name == "tab":
                parts.append("\t")
            elif name in {"br", "cr"}:
                parts.append("\n")
        for child in list(node):
            visit(child, deleted)

    visit(element)
    text = "".join(parts).replace("\u00a0", " ")
    lines = [line.rstrip() for line in text.splitlines()]
    return "\n".join(lines).strip()


def paragraph_style(paragraph: ET.Element, styles: dict[str, str]) -> tuple[str, str]:
    style_node = paragraph.find("./w:pPr/w:pStyle", NS)
    style_id = attr(style_node, W_NS, "val") if style_node is not None else ""
    return style_id or "", styles.get(style_id or "", style_id or "Normal")


def iter_body_blocks(body: ET.Element) -> Iterable[ET.Element]:
    for child in list(body):
        name = local_name(child.tag)
        if name in {"p", "tbl"}:
            yield child
        elif name in {"sdt", "customXml", "ins"}:
            containers = [
                node for node in child.iter() if local_name(node.tag) == "sdtContent"
            ]
            if containers:
                for container in containers:
                    yield from iter_body_blocks(container)
            else:
                yield from iter_body_blocks(child)


def table_rows(table: ET.Element) -> list[list[str]]:
    rows: list[list[str]] = []
    for row in table.findall("./w:tr", NS):
        values: list[str] = []
        for cell in row.findall("./w:tc", NS):
            paragraphs = [
                element_text(paragraph)
                for paragraph in cell.findall(".//w:p", NS)
                if element_text(paragraph)
            ]
            values.append("\n".join(paragraphs))
        rows.append(values)
    return rows


def declared_counts(title: str) -> dict[str, int]:
    result: dict[str, int] = {}
    sub_match = re.search(r"(\d+)\s*Sub\s*[- ]?\s*PC", title, re.IGNORECASE)
    if sub_match:
        result["sub_pc"] = int(sub_match.group(1))
    without_sub = re.sub(
        r"\d+\s*Sub\s*[- ]?\s*PC", "", title, flags=re.IGNORECASE
    )
    pc_match = re.search(r"(\d+)\s*PC", without_sub, re.IGNORECASE)
    if pc_match:
        result["pc"] = int(pc_match.group(1))
    po_match = re.search(r"(\d+)\s*PO", title, re.IGNORECASE)
    if po_match:
        result["po"] = int(po_match.group(1))
    return result


def classify_choice(label: str) -> str:
    normalized = re.sub(r"\s+", " ", label.strip().lower())
    if "outfit" in normalized or normalized.endswith("po"):
        return "PO"
    if "sub" in normalized and "pc" in normalized:
        return "Sub-PC"
    if "sub" in normalized and "fc" in normalized:
        return "Sub-FC"
    if "pc" in normalized:
        return "PC"
    return "FC"


def parse_price(text_after_label: str) -> list[dict[str, Any]]:
    prices: list[dict[str, Any]] = []
    unit_match = PRICE_WITH_UNIT_RE.search(text_after_label)
    if unit_match:
        prices.append(
            {
                "value": int(unit_match.group("value")),
                "unit": unit_match.group("unit"),
                "certainty": "explicit",
            }
        )
        return prices
    paren_match = PAREN_PRICE_RE.search(text_after_label)
    if paren_match:
        prices.append(
            {
                "value": int(paren_match.group("value")),
                "unit": None,
                "certainty": "suspected",
            }
        )
    return prices


def raw_source_lines(
    item: dict[str, Any],
) -> Iterable[tuple[dict[str, int | str], str]]:
    if item["type"] == "paragraph":
        for segment_number, line in enumerate(item["text"].splitlines(), start=1):
            if line.strip():
                yield (
                    {
                        "source_type": "paragraph",
                        "paragraph_number": item["paragraph_number"],
                        "segment_number": segment_number,
                    },
                    line.strip(),
                )
    else:
        for row_number, row in enumerate(item["rows"], start=1):
            for column_number, cell in enumerate(row, start=1):
                for segment_number, line in enumerate(cell.splitlines(), start=1):
                    if line.strip():
                        yield (
                            {
                                "source_type": "table",
                                "table_number": item["table_number"],
                                "row_number": row_number,
                                "column_number": column_number,
                                "segment_number": segment_number,
                            },
                            line.strip(),
                        )


def source_lines(
    item: dict[str, Any], lines_by_item_order: dict[int, list[dict[str, Any]]]
) -> Iterable[tuple[str, int, str]]:
    for entry in lines_by_item_order[item["order"]]:
        line_number = int(entry["line"])
        yield f"DOCX content line {line_number}", line_number, str(entry["text"])


def assign_chapter(
    order: int, chapters: list[dict[str, Any]]
) -> tuple[int | None, str | None]:
    for chapter in chapters:
        if chapter["start_item_order"] <= order <= chapter["end_item_order"]:
            return chapter["number"], chapter["raw_title"]
    return None, None


def extract(path: Path) -> dict[str, Any]:
    with zipfile.ZipFile(path) as archive:
        document = parse_xml(archive, "word/document.xml")
        if document is None:
            raise ValueError("DOCX has no word/document.xml")
        body = document.find(".//w:body", NS)
        if body is None:
            raise ValueError("DOCX has no document body")
        styles = load_style_names(archive)

        items: list[dict[str, Any]] = []
        paragraph_number = 0
        table_number = 0
        for order, block in enumerate(iter_body_blocks(body), start=1):
            name = local_name(block.tag)
            if name == "p":
                paragraph_number += 1
                style_id, style_name = paragraph_style(block, styles)
                items.append(
                    {
                        "order": order,
                        "type": "paragraph",
                        "paragraph_number": paragraph_number,
                        "style_id": style_id,
                        "style_name": style_name,
                        "text": element_text(block),
                    }
                )
            elif name == "tbl":
                table_number += 1
                rows = table_rows(block)
                items.append(
                    {
                        "order": order,
                        "type": "table",
                        "table_number": table_number,
                        "rows": rows,
                    }
                )

        content_lines: list[dict[str, Any]] = []
        lines_by_item_order: dict[int, list[dict[str, Any]]] = {}
        for item in items:
            item_lines: list[dict[str, Any]] = []
            for locator, text in raw_source_lines(item):
                entry = {
                    "line": len(content_lines) + 1,
                    "item_order": item["order"],
                    **locator,
                    "text": text,
                }
                content_lines.append(entry)
                item_lines.append(entry)
            lines_by_item_order[item["order"]] = item_lines
            item["content_line_start"] = item_lines[0]["line"] if item_lines else None
            item["content_line_end"] = item_lines[-1]["line"] if item_lines else None

        chapter_candidates: list[dict[str, Any]] = []
        for item in items:
            for reference, content_line, line in source_lines(
                item, lines_by_item_order
            ):
                match = CHAPTER_RE.match(line)
                if match:
                    chapter_candidates.append(
                        {
                            "number": int(match.group("number")),
                            "raw_title": line,
                            "reference": reference,
                            "content_line": content_line,
                            "start_item_order": item["order"],
                            "declared_counts": declared_counts(line),
                        }
                    )
                    break

        for index, chapter in enumerate(chapter_candidates):
            next_start = (
                chapter_candidates[index + 1]["start_item_order"]
                if index + 1 < len(chapter_candidates)
                else (items[-1]["order"] + 1 if items else 1)
            )
            chapter["end_item_order"] = next_start - 1
            chapter_line_numbers = [
                entry["line"]
                for order in range(chapter["start_item_order"], next_start)
                for entry in lines_by_item_order.get(order, [])
            ]
            chapter["end_content_line"] = (
                chapter_line_numbers[-1] if chapter_line_numbers else chapter["content_line"]
            )

        scene_candidates: list[dict[str, Any]] = []
        choice_candidates: list[dict[str, Any]] = []
        for item in items:
            chapter_number, chapter_title = assign_chapter(
                item["order"], chapter_candidates
            )
            for reference, content_line, line in source_lines(
                item, lines_by_item_order
            ):
                scene_match = SCENE_RE.match(line)
                if scene_match:
                    scene_candidates.append(
                        {
                            "item_order": item["order"],
                            "reference": reference,
                            "content_line": content_line,
                            "chapter_number": chapter_number,
                            "chapter_title": chapter_title,
                            "raw": line,
                            "declared_scene_number": (
                                int(scene_match.group("number"))
                                if scene_match.group("number")
                                else None
                            ),
                        }
                    )
                choice_match = CHOICE_RE.match(line)
                if choice_match and not CHAPTER_RE.match(line):
                    label = choice_match.group("label")
                    choice_candidates.append(
                        {
                            "item_order": item["order"],
                            "reference": reference,
                            "content_line": content_line,
                            "chapter_number": chapter_number,
                            "chapter_title": chapter_title,
                            "raw": line,
                            "label": label,
                            "type": classify_choice(label),
                            "option_number": (
                                int(choice_match.group("option_number"))
                                if choice_match.group("option_number")
                                else None
                            ),
                            "prices": parse_price(line[choice_match.end() :]),
                        }
                    )

        names = set(archive.namelist())
        document_xml = archive.read("word/document.xml")
        warnings: list[dict[str, Any]] = []

        def add_warning(code: str, detail: str) -> None:
            warnings.append({"code": code, "detail": detail})

        if not chapter_candidates:
            add_warning("no-chapters", "No Chapter heading candidates were detected.")
        if b"<w:ins" in document_xml or b"<w:del" in document_xml:
            add_warning(
                "tracked-revisions",
                "Tracked insertions/deletions exist; deleted text was excluded.",
            )
        if any(name.startswith("word/media/") for name in names):
            add_warning("media", "Images or other media exist and may contain text.")
        if any(name.startswith("word/embeddings/") for name in names):
            add_warning(
                "embedded-objects", "Embedded objects exist and were not executed."
            )
        if b"<w:altChunk" in document_xml:
            add_warning("altchunk", "External/alternative content exists.")
        if b"<w:txbxContent" in document_xml:
            add_warning(
                "text-boxes",
                "Text boxes exist; their text may need render-based verification.",
            )
        if b"<w:drawing" in document_xml or b"<w:pict" in document_xml:
            add_warning(
                "drawings",
                "Drawings exist; visually verify any text or story content they contain.",
            )
        if "word/vbaProject.bin" in names:
            add_warning(
                "macros", "A macro payload exists; it was not read or executed."
            )

        rels = parse_xml(archive, "word/_rels/document.xml.rels")
        external_relationships = 0
        if rels is not None:
            external_relationships = sum(
                1
                for relationship in list(rels)
                if relationship.get("TargetMode") == "External"
            )
        if external_relationships:
            add_warning(
                "external-relationships",
                f"{external_relationships} external relationships were not opened.",
            )

        return {
            "extractor_version": "1.1",
            "source": {
                "path": str(path.resolve()),
                "filename": path.name,
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            },
            "core_properties": core_properties(archive),
            "summary": {
                "items": len(items),
                "paragraphs": paragraph_number,
                "tables": table_number,
                "content_lines": len(content_lines),
                "chapters_detected": len(chapter_candidates),
                "scene_markers_detected": len(scene_candidates),
                "choice_markers_detected": len(choice_candidates),
            },
            "items": items,
            "content_lines": content_lines,
            "candidates": {
                "chapters": chapter_candidates,
                "scenes": scene_candidates,
                "choices": choice_candidates,
            },
            "warnings": warnings,
        }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Extract ordered DOCX outline content to UTF-8 JSON."
    )
    parser.add_argument("source", type=Path, help="Source .docx file (read-only)")
    parser.add_argument(
        "--output",
        type=Path,
        help="Output JSON path; omit to write JSON to stdout",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    source: Path = args.source
    if source.suffix.lower() != ".docx":
        print("error: source must have a .docx extension", file=sys.stderr)
        return 2
    if not source.is_file():
        print(f"error: source not found: {source}", file=sys.stderr)
        return 2
    try:
        result = extract(source)
    except (OSError, ValueError, zipfile.BadZipFile, ET.ParseError) as error:
        print(f"error: could not extract DOCX: {error}", file=sys.stderr)
        return 1

    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
        print(
            json.dumps(
                {
                    "status": "ok",
                    "output": str(args.output.resolve()),
                    "summary": result["summary"],
                    "warnings": result["warnings"],
                },
                ensure_ascii=False,
            )
        )
    else:
        sys.stdout.write(payload)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
