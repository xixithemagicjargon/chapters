#!/usr/bin/env python3
"""Create a paragraph-numbered locator DOCX without modifying the source."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Any
from xml.dom import Node, minidom


W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
XML_NS = "http://www.w3.org/XML/1998/namespace"
SCHEMA_VERSION = "1.0"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def is_deleted(node: Node) -> bool:
    current = node.parentNode
    while current is not None:
        if (
            current.nodeType == Node.ELEMENT_NODE
            and current.namespaceURI == W_NS
            and current.localName == "del"
        ):
            return True
        current = current.parentNode
    return False


def paragraph_text(paragraph: Node) -> str:
    parts: list[str] = []

    def visit(node: Node) -> None:
        if node.nodeType == Node.ELEMENT_NODE and node.namespaceURI == W_NS:
            if node.localName == "t" and not is_deleted(node):
                parts.append(
                    "".join(
                        child.data
                        for child in node.childNodes
                        if child.nodeType == Node.TEXT_NODE
                    )
                )
                return
            if node.localName == "tab" and not is_deleted(node):
                parts.append("\t")
                return
            if node.localName in {"br", "cr"} and not is_deleted(node):
                parts.append("\n")
                return
        for child in node.childNodes:
            visit(child)

    visit(paragraph)
    return "\n".join(line.rstrip() for line in "".join(parts).splitlines()).strip()


def is_in_table(paragraph: Node) -> bool:
    current = paragraph.parentNode
    while current is not None:
        if (
            current.nodeType == Node.ELEMENT_NODE
            and current.namespaceURI == W_NS
            and current.localName == "tc"
        ):
            return True
        current = current.parentNode
    return False


def first_element_child(node: Node) -> Node | None:
    for child in node.childNodes:
        if child.nodeType == Node.ELEMENT_NODE:
            return child
    return None


def add_marker(document: minidom.Document, paragraph: Node, marker: str) -> None:
    prefix = paragraph.prefix or "w"
    run = document.createElementNS(W_NS, f"{prefix}:r")
    properties = document.createElementNS(W_NS, f"{prefix}:rPr")
    properties.appendChild(document.createElementNS(W_NS, f"{prefix}:b"))
    color = document.createElementNS(W_NS, f"{prefix}:color")
    color.setAttributeNS(W_NS, f"{prefix}:val", "C00000")
    properties.appendChild(color)
    highlight = document.createElementNS(W_NS, f"{prefix}:highlight")
    highlight.setAttributeNS(W_NS, f"{prefix}:val", "yellow")
    properties.appendChild(highlight)
    run.appendChild(properties)
    text = document.createElementNS(W_NS, f"{prefix}:t")
    text.setAttributeNS(XML_NS, "xml:space", "preserve")
    text.appendChild(document.createTextNode(f"[{marker}] "))
    run.appendChild(text)

    first = first_element_child(paragraph)
    if first is not None and first.namespaceURI == W_NS and first.localName == "pPr":
        paragraph.insertBefore(run, first.nextSibling)
    elif paragraph.firstChild is not None:
        paragraph.insertBefore(run, paragraph.firstChild)
    else:
        paragraph.appendChild(run)


def number_document_xml(document_xml: bytes) -> tuple[bytes, list[dict[str, Any]]]:
    try:
        document = minidom.parseString(document_xml)
    except Exception as error:
        raise ValueError(f"could not parse word/document.xml: {error}") from error
    paragraphs = list(document.getElementsByTagNameNS(W_NS, "p"))
    mapping: list[dict[str, Any]] = []
    for number, paragraph in enumerate(paragraphs, start=1):
        marker = f"P{number:04d}"
        mapping.append(
            {
                "marker": marker,
                "paragraph_number": number,
                "in_table": is_in_table(paragraph),
                "text": paragraph_text(paragraph),
            }
        )
        add_marker(document, paragraph, marker)
    return document.toxml(encoding="UTF-8"), mapping


def build_locator(
    source: Path, output: Path, map_output: Path
) -> dict[str, Any]:
    source = source.resolve()
    output = output.resolve()
    map_output = map_output.resolve()
    if source.suffix.lower() != ".docx" or not source.is_file():
        raise ValueError(f"source must be an existing .docx file: {source}")
    if output.suffix.lower() != ".docx":
        raise ValueError("locator output must have a .docx extension")
    if output == source:
        raise ValueError("locator output must not overwrite the source")
    if output.exists() or map_output.exists():
        raise ValueError("locator output or paragraph map already exists")
    expected_map_parent = output.parent / "working-files"
    if map_output.parent != expected_map_parent:
        raise ValueError(
            "paragraph map must be inside the locator output directory's "
            "working-files folder"
        )
    output.parent.mkdir(parents=True, exist_ok=True)
    map_output.parent.mkdir(parents=True, exist_ok=True)

    source_hash = sha256_file(source)
    docx_temp: Path | None = None
    map_temp: Path | None = None
    output_committed = False
    try:
        with tempfile.NamedTemporaryFile(
            prefix=".locator-", suffix=".docx", dir=map_output.parent, delete=False
        ) as handle:
            docx_temp = Path(handle.name)
        with tempfile.NamedTemporaryFile(
            prefix=".paragraph-map-", suffix=".json", dir=map_output.parent, delete=False
        ) as handle:
            map_temp = Path(handle.name)

        mapping: list[dict[str, Any]] | None = None
        with zipfile.ZipFile(source) as source_zip, zipfile.ZipFile(
            docx_temp, "w"
        ) as destination_zip:
            for info in source_zip.infolist():
                data = source_zip.read(info.filename)
                if info.filename == "word/document.xml":
                    data, mapping = number_document_xml(data)
                destination_zip.writestr(info, data)
        if mapping is None:
            raise ValueError("DOCX has no word/document.xml")
        if not mapping:
            raise ValueError("DOCX has no paragraphs to number")

        with zipfile.ZipFile(docx_temp) as archive:
            bad_member = archive.testzip()
            if bad_member:
                raise ValueError(f"locator DOCX ZIP check failed at {bad_member}")
            locator_xml = archive.read("word/document.xml")
            if f"[{mapping[0]['marker']}]".encode() not in locator_xml:
                raise ValueError("first paragraph marker is missing from locator DOCX")
            if f"[{mapping[-1]['marker']}]".encode() not in locator_xml:
                raise ValueError("last paragraph marker is missing from locator DOCX")

        payload = {
            "status": "ok",
            "schema_version": SCHEMA_VERSION,
            "source": str(source),
            "source_sha256": source_hash,
            "locator_docx": str(output),
            "locator_sha256": sha256_file(docx_temp),
            "paragraphs": len(mapping),
            "markers": mapping,
        }
        map_temp.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        if sha256_file(source) != source_hash:
            raise ValueError("source DOCX changed while creating locator copy")
        os.replace(docx_temp, output)
        docx_temp = None
        output_committed = True
        os.replace(map_temp, map_output)
        map_temp = None
        return payload
    except Exception:
        if output_committed:
            output.unlink(missing_ok=True)
        raise
    finally:
        if docx_temp is not None:
            docx_temp.unlink(missing_ok=True)
        if map_temp is not None:
            map_temp.unlink(missing_ok=True)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Create a paragraph-numbered locator copy of a DOCX."
    )
    parser.add_argument("source", type=Path, help="Source .docx file (read-only)")
    parser.add_argument("--output", required=True, type=Path, help="New locator DOCX")
    parser.add_argument(
        "--map-output", required=True, type=Path, help="New paragraph map JSON"
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        result = build_locator(args.source, args.output, args.map_output)
    except (OSError, ValueError, zipfile.BadZipFile) as error:
        print(f"error: could not create locator DOCX: {error}", file=sys.stderr)
        return 1
    print(
        json.dumps(
            {
                "status": "ok",
                "output": result["locator_docx"],
                "map_output": str(args.map_output.resolve()),
                "paragraphs": result["paragraphs"],
                "source_sha256": result["source_sha256"],
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
