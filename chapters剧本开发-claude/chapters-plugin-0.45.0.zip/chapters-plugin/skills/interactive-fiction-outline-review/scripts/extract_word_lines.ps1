param(
    [Parameter(Mandatory = $true)][string]$Source,
    [Parameter(Mandatory = $true)][string]$Output
)

$ErrorActionPreference = 'Stop'
$wdDoNotSaveChanges = 0
$wdStatisticLines = 1
$wdActiveEndPageNumber = 3
$wdPrintView = 3
$wdRestartContinuous = 0
$wdLine = 5
$wdExtend = 1
$wdStory = 6

function Get-Sha256([string]$Path) {
    $stream = [System.IO.File]::OpenRead($Path)
    try {
        $sha256 = [System.Security.Cryptography.SHA256]::Create()
        try {
            ([System.BitConverter]::ToString($sha256.ComputeHash($stream))).Replace('-', '').ToLowerInvariant()
        }
        finally {
            $sha256.Dispose()
        }
    }
    finally {
        $stream.Dispose()
    }
}

$sourcePath = [System.IO.Path]::GetFullPath($Source)
$outputPath = [System.IO.Path]::GetFullPath($Output)
if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) { throw "Source not found: $sourcePath" }
if ([System.IO.Path]::GetExtension($sourcePath).ToLowerInvariant() -ne '.docx') { throw 'Source must be a .docx file' }
if (Test-Path -LiteralPath $outputPath) { throw "Output already exists: $outputPath" }

$hashBefore = Get-Sha256 $sourcePath
$word = $null
$document = $null
try {
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $document = $word.Documents.Open($sourcePath, $false, $true, $false)
    $word.ActiveWindow.View.Type = $wdPrintView
    foreach ($section in $document.Sections) {
        $numbering = $section.PageSetup.LineNumbering
        $numbering.Active = $true
        $numbering.StartingNumber = 1
        $numbering.CountBy = 1
        $numbering.RestartMode = $wdRestartContinuous
    }
    $document.Repaginate()

    $includeFootnotes = $false
    $totalLines = [int]$document.ComputeStatistics($wdStatisticLines, [ref]$includeFootnotes)
    $lines = [System.Collections.Generic.List[object]]::new()
    $selection = $word.Selection
    [void]$selection.HomeKey($wdStory)
    for ($lineNumber = 1; $lineNumber -le $totalLines; $lineNumber++) {
        $start = [int]$selection.Start
        if ($lineNumber -lt $totalLines) {
            [void]$selection.MoveDown($wdLine, 1, $wdExtend)
            $end = [int]$selection.End
        }
        else {
            $end = [int]$document.Content.End
        }
        if ($end -le $start -and $lineNumber -lt $totalLines) {
            throw "Word did not advance at line $lineNumber"
        }
        $lineRange = $document.Range($start, $end)
        $text = ($lineRange.Text -replace "[\r\a\v]", '' -replace "\t", ' ').Trim()
        $page = [int]$document.Range($start, $start).Information($wdActiveEndPageNumber)
        $lines.Add([ordered]@{
            line = $lineNumber
            page = $page
            start = $start
            end = $end
            text = $text
        })
        $selection.SetRange($end, $end)
    }

    $payload = [ordered]@{
        status = 'ok'
        schema_version = '1.0'
        renderer = 'microsoft-word'
        renderer_version = [string]$word.Version
        source = $sourcePath
        source_sha256 = $hashBefore
        view = 'print'
        line_numbering = 'continuous'
        total_lines = $totalLines
        lines = $lines
        warnings = @()
    }
    $outputDirectory = [System.IO.Path]::GetDirectoryName($outputPath)
    if (-not (Test-Path -LiteralPath $outputDirectory)) {
        New-Item -ItemType Directory -Path $outputDirectory | Out-Null
    }
    $payload | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $outputPath -Encoding UTF8
}
finally {
    if ($document) {
        try { $document.Close($wdDoNotSaveChanges) } catch {}
    }
    if ($word) {
        try { $word.Quit($wdDoNotSaveChanges) } catch {}
    }
    if ($document) {
        try { [void][System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($document) } catch {}
    }
    if ($word) {
        try { [void][System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($word) } catch {}
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}

$hashAfter = Get-Sha256 $sourcePath
if ($hashAfter -ne $hashBefore) {
    Remove-Item -LiteralPath $outputPath -ErrorAction SilentlyContinue
    throw 'Source DOCX changed while collecting Word visual line numbers'
}
$result = Get-Content -LiteralPath $outputPath -Raw | ConvertFrom-Json
if ($result.status -ne 'ok' -or $result.total_lines -lt 1 -or $result.lines.Count -lt 1) {
    throw 'Word visual line map is empty or invalid'
}
[ordered]@{
    status = 'ok'
    output = $outputPath
    renderer = 'microsoft-word'
    total_lines = $result.total_lines
    source_sha256 = $hashAfter
} | ConvertTo-Json -Compress
