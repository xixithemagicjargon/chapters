#!/usr/bin/env python3
"""Extract visual line numbers from a DOCX with Word or LibreOffice.

Word mode uses the bundled PowerShell helper and Microsoft Word's layout engine.
LibreOffice mode renders a temporary line-numbered DOCX to PDF, then reads the
printed margin line numbers with pdftotext. The source DOCX is never modified.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET


W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
SCHEMA_VERSION = "1.0"


class VisualLineError(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_command(command: list[str], label: str) -> subprocess.CompletedProcess[str]:
    try:
        result = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
    except OSError as error:
        raise VisualLineError(f"{label} could not start: {error}") from error
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip()
        raise VisualLineError(f"{label} failed: {detail or 'unknown error'}")
    return result


def validate_payload(payload: dict[str, Any], source: Path) -> None:
    if payload.get("status") != "ok":
        raise VisualLineError("visual line map status is not ok")
    lines = payload.get("lines")
    if not isinstance(lines, list) or not lines:
        raise VisualLineError("visual line map is empty")
    numbers = [line.get("line") for line in lines]
    if any(not isinstance(number, int) or number < 1 for number in numbers):
        raise VisualLineError("visual line map contains invalid line numbers")
    if numbers != sorted(numbers) or len(numbers) != len(set(numbers)):
        raise VisualLineError("visual line numbers are not strictly increasing")
    if payload.get("source_sha256") != sha256_file(source):
        raise VisualLineError("source DOCX hash does not match visual line map")


def find_command(explicit: str | None, names: tuple[str, ...]) -> str:
    if explicit:
        path = Path(explicit).expanduser()
        if not path.is_file():
            raise VisualLineError(f"command not found: {path}")
        return str(path.resolve())
    for name in names:
        found = shutil.which(name)
        if found:
            return found
    raise VisualLineError(f"required command not found: {' or '.join(names)}")


def word_mode(source: Path, output: Path) -> dict[str, Any]:
    if os.name != "nt":
        raise VisualLineError("Microsoft Word mode is only available on Windows")
    powershell = find_command(None, ("powershell.exe", "powershell", "pwsh"))
    helper = Path(__file__).with_name("extract_word_lines.ps1")
    if not helper.is_file():
        raise VisualLineError(f"Word helper is missing: {helper}")
    run_command(
        [
            powershell,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(helper),
            "-Source",
            str(source),
            "-Output",
            str(output),
        ],
        "Microsoft Word visual line extraction",
    )
    try:
        payload = json.loads(output.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as error:
        raise VisualLineError(f"could not read Word visual line map: {error}") from error
    validate_payload(payload, source)
    return payload


def enable_continuous_line_numbering(document_xml: bytes) -> bytes:
    text = document_xml.decode("utf-8")
    namespace_match = re.search(
        r"xmlns:(?P<prefix>[A-Za-z_][\w.-]*)=[\"']"
        + re.escape(W_NS)
        + r"[\"']",
        text,
    )
    if not namespace_match:
        raise VisualLineError("WordprocessingML namespace was not found")
    prefix = namespace_match.group("prefix")
    section_pattern = re.compile(
        rf"<{re.escape(prefix)}:sectPr\b[^>]*>.*?</{re.escape(prefix)}:sectPr>",
        re.DOTALL,
    )
    line_pattern = re.compile(
        rf"<{re.escape(prefix)}:lnNumType\b[^>]*/>"
        rf"|<{re.escape(prefix)}:lnNumType\b[^>]*>.*?</{re.escape(prefix)}:lnNumType>",
        re.DOTALL,
    )
    line_tag = (
        f'<{prefix}:lnNumType {prefix}:countBy="1" '
        f'{prefix}:restart="continuous" {prefix}:start="0"/>'
    )

    def update_section(match: re.Match[str]) -> str:
        section = match.group(0)
        if line_pattern.search(section):
            return line_pattern.sub(line_tag, section, count=1)
        opening_end = section.find(">") + 1
        return section[:opening_end] + line_tag + section[opening_end:]

    updated, count = section_pattern.subn(update_section, text)
    if count < 1:
        raise VisualLineError("DOCX has no section properties for line numbering")
    return updated.encode("utf-8")


def make_line_numbered_copy(source: Path, destination: Path) -> None:
    try:
        with zipfile.ZipFile(source) as source_zip, zipfile.ZipFile(
            destination, "w"
        ) as destination_zip:
            found_document = False
            for info in source_zip.infolist():
                data = source_zip.read(info.filename)
                if info.filename == "word/document.xml":
                    data = enable_continuous_line_numbering(data)
                    found_document = True
                destination_zip.writestr(info, data)
            if not found_document:
                raise VisualLineError("DOCX has no word/document.xml")
    except (OSError, zipfile.BadZipFile) as error:
        raise VisualLineError(f"could not prepare LibreOffice render copy: {error}") from error


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def parse_bbox_visual_lines(bbox_path: Path) -> list[dict[str, Any]]:
    try:
        root = ET.parse(bbox_path).getroot()
    except (OSError, ET.ParseError) as error:
        raise VisualLineError(f"could not parse pdftotext bbox output: {error}") from error

    mapped: list[dict[str, Any]] = []
    for page_number, page in enumerate(
        (node for node in root.iter() if local_name(node.tag) == "page"), start=1
    ):
        records: list[dict[str, Any]] = []
        for line_node in (
            node for node in page.iter() if local_name(node.tag) == "line"
        ):
            words: list[dict[str, Any]] = []
            for word in (
                node for node in line_node.iter() if local_name(node.tag) == "word"
            ):
                text = "".join(word.itertext()).strip()
                if not text:
                    continue
                try:
                    words.append(
                        {
                            "text": text,
                            "x_min": float(word.get("xMin", "0")),
                            "x_max": float(word.get("xMax", "0")),
                            "y_min": float(word.get("yMin", "0")),
                            "y_max": float(word.get("yMax", "0")),
                        }
                    )
                except ValueError:
                    continue
            if not words:
                continue
            records.append(
                {
                    "words": words,
                    "text": " ".join(word["text"] for word in words),
                    "x_min": min(word["x_min"] for word in words),
                    "y_center": sum(
                        (word["y_min"] + word["y_max"]) / 2 for word in words
                    )
                    / len(words),
                    "height": max(word["y_max"] for word in words)
                    - min(word["y_min"] for word in words),
                }
            )
        if not records:
            continue

        nonnumeric_lefts = [
            min(
                word["x_min"]
                for word in record["words"]
                if not word["text"].isdigit()
            )
            for record in records
            if any(not word["text"].isdigit() for word in record["words"])
        ]
        if not nonnumeric_lefts:
            continue
        rounded_lefts = [round(value / 5) * 5 for value in nonnumeric_lefts]
        main_left = Counter(rounded_lefts).most_common(1)[0][0]

        body_records: list[dict[str, Any]] = []
        number_records: list[dict[str, Any]] = []
        for record in records:
            first = record["words"][0]
            is_margin_number = (
                first["text"].isdigit()
                and first["x_min"] < main_left - 8
                and (
                    len(record["words"]) == 1
                    or record["words"][1]["x_min"] >= main_left - 5
                )
            )
            if is_margin_number:
                number_records.append(record)
                if len(record["words"]) > 1:
                    body_records.append(
                        {
                            **record,
                            "text": " ".join(
                                word["text"] for word in record["words"][1:]
                            ),
                            "words": record["words"][1:],
                        }
                    )
            else:
                body_records.append(record)

        for number_record in number_records:
            number = int(number_record["words"][0]["text"])
            text = ""
            if len(number_record["words"]) > 1:
                text = " ".join(
                    word["text"] for word in number_record["words"][1:]
                )
            else:
                candidates = [
                    record
                    for record in body_records
                    if record["x_min"] >= main_left - 5
                ]
                if candidates:
                    nearest = min(
                        candidates,
                        key=lambda record: abs(
                            record["y_center"] - number_record["y_center"]
                        ),
                    )
                    tolerance = max(3.0, number_record["height"] * 0.75)
                    if abs(nearest["y_center"] - number_record["y_center"]) <= tolerance:
                        text = nearest["text"]
            mapped.append({"line": number, "page": page_number, "text": text})

    deduplicated: list[dict[str, Any]] = []
    seen: set[int] = set()
    for entry in sorted(mapped, key=lambda item: item["line"]):
        if entry["line"] in seen:
            raise VisualLineError(
                "LibreOffice rendered duplicate visual line numbers; "
                "continuous numbering could not be verified"
            )
        seen.add(entry["line"])
        deduplicated.append(entry)
    if not deduplicated:
        raise VisualLineError(
            "no printed visual line numbers were found in LibreOffice PDF"
        )
    return deduplicated


def libreoffice_mode(
    source: Path,
    output: Path,
    soffice_override: str | None,
    pdftotext_override: str | None,
) -> dict[str, Any]:
    soffice = find_command(soffice_override, ("soffice", "libreoffice"))
    pdftotext = find_command(pdftotext_override, ("pdftotext",))
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(
        prefix=".visual-lines-", dir=output.parent
    ) as temporary:
        work = Path(temporary)
        render_source = work / "render-source.docx"
        make_line_numbered_copy(source, render_source)
        profile = work / "libreoffice-profile"
        profile.mkdir()
        run_command(
            [
                soffice,
                "--headless",
                f"-env:UserInstallation={profile.resolve().as_uri()}",
                "--convert-to",
                "pdf",
                "--outdir",
                str(work),
                str(render_source),
            ],
            "LibreOffice PDF rendering",
        )
        pdf_path = work / "render-source.pdf"
        if not pdf_path.is_file():
            raise VisualLineError("LibreOffice did not produce the expected PDF")
        bbox_path = work / "render-source-bbox.html"
        run_command(
            [
                pdftotext,
                "-bbox-layout",
                "-enc",
                "UTF-8",
                str(pdf_path),
                str(bbox_path),
            ],
            "pdftotext visual line mapping",
        )
        lines = parse_bbox_visual_lines(bbox_path)
        version_result = run_command([soffice, "--version"], "LibreOffice version")
        renderer_version = version_result.stdout.strip()

    payload = {
        "status": "ok",
        "schema_version": SCHEMA_VERSION,
        "renderer": "libreoffice",
        "renderer_version": renderer_version,
        "source": str(source.resolve()),
        "source_sha256": sha256_file(source),
        "view": "pdf",
        "line_numbering": "continuous",
        "total_lines": len(lines),
        "lines": lines,
        "warnings": [
            "LibreOffice visual lines match its rendered PDF and may differ from Microsoft Word."
        ],
    }
    validate_payload(payload, source)
    output.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return payload


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Extract DOCX visual line numbers with Word or LibreOffice."
    )
    parser.add_argument("source", type=Path, help="Source .docx file (read-only)")
    parser.add_argument("--output", required=True, type=Path, help="New JSON output")
    parser.add_argument(
        "--mode",
        choices=("auto", "word", "libreoffice"),
        default="auto",
        help="auto prefers Word on Windows, then LibreOffice",
    )
    parser.add_argument("--soffice", help="Explicit soffice/libreoffice executable")
    parser.add_argument("--pdftotext", help="Explicit pdftotext executable")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    source = args.source.resolve()
    output = args.output.resolve()
    if source.suffix.lower() != ".docx" or not source.is_file():
        print(f"error: source must be an existing .docx file: {source}", file=sys.stderr)
        return 2
    if output.exists():
        print(f"error: output already exists: {output}", file=sys.stderr)
        return 2
    output.parent.mkdir(parents=True, exist_ok=True)
    source_hash = sha256_file(source)
    failures: list[str] = []
    try:
        if args.mode in {"auto", "word"}:
            try:
                payload = word_mode(source, output)
            except VisualLineError as error:
                output.unlink(missing_ok=True)
                failures.append(str(error))
                if args.mode == "word":
                    raise
            else:
                print(
                    json.dumps(
                        {
                            "status": "ok",
                            "output": str(output),
                            "renderer": payload["renderer"],
                            "total_lines": payload["total_lines"],
                        },
                        ensure_ascii=False,
                    )
                )
                return 0

        payload = libreoffice_mode(
            source, output, args.soffice, args.pdftotext
        )
        if failures:
            payload.setdefault("warnings", []).insert(
                0, f"Word mode was unavailable: {failures[-1]}"
            )
            output.write_text(
                json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
        if sha256_file(source) != source_hash:
            output.unlink(missing_ok=True)
            raise VisualLineError("source DOCX changed during visual line extraction")
        print(
            json.dumps(
                {
                    "status": "ok",
                    "output": str(output),
                    "renderer": payload["renderer"],
                    "total_lines": payload["total_lines"],
                },
                ensure_ascii=False,
            )
        )
        return 0
    except VisualLineError as error:
        output.unlink(missing_ok=True)
        if failures and args.mode == "auto":
            print(
                "error: no visual line renderer succeeded: "
                + " | ".join(failures + [str(error)]),
                file=sys.stderr,
            )
        else:
            print(f"error: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
