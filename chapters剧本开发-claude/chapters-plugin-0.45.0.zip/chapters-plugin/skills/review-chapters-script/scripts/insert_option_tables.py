"""Insert option-only Word fragments without reserializing the original document."""

from copy import deepcopy
import hashlib
from pathlib import Path
import xml.etree.ElementTree as ET
from xml.parsers import expat
import zipfile


W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
DOCUMENT = "word/document.xml"


def parts(path):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("duplicate Word package parts")
        return {name: archive.read(name) for name in names}


def text(element):
    return "".join(node.text or "" if node.tag == W + "t" else
                   "\n" if node.tag in (W + "br", W + "cr") else
                   "\t" if node.tag == W + "tab" else "" for node in element.iter())


def heading(element, style):
    value = element.find(f"{W}pPr/{W}pStyle")
    return element.tag == W + "p" and value is not None and value.get(W + "val") == style


def body_offsets(xml):
    """Find insertion offsets in UTF-8 bytes; never rewrite original XML nodes."""
    parser = expat.ParserCreate(namespace_separator="}")
    stack, offsets = [], []

    def start(name, _attributes):
        if len(stack) == 2 and stack[-1] == W[1:] + "body":
            offsets.append(parser.CurrentByteIndex)
        stack.append(name)

    parser.StartElementHandler = start
    parser.EndElementHandler = lambda _name: stack.pop()
    parser.Parse(xml, True)
    return offsets


def width_at(children, index):
    # A section's properties are stored at its end, not its beginning.
    for element in children[index:]:
        section = next(element.iter(W + "sectPr"), None)
        if section is None:
            continue
        size, margin = section.find(W + "pgSz"), section.find(W + "pgMar")
        if size is None or margin is None:
            raise ValueError("original page width or margins are not explicit")
        columns = section.find(W + "cols")
        if columns is not None and int(columns.get(W + "num", "1")) != 1:
            raise ValueError("multi-column insertion requires an explicit layout adapter")
        width = int(size.get(W + "w")) - sum(int(margin.get(W + side, "0"))
                                             for side in ("left", "right", "gutter"))
        if width <= 0:
            raise ValueError("original page has no usable table width")
        return width
    raise ValueError("cannot locate the original section for insertion")


def fit_table(table, width, *, repeat_header=True):
    rows = table.findall(W + "tr")
    original = [int(cell.find(f"{W}tcPr/{W}tcW").get(W + "w")) for cell in rows[0].findall(W + "tc")]
    widths = [width * value // sum(original) for value in original]
    widths[-1] += width - sum(widths)
    table.find(f"{W}tblPr/{W}tblW").set(W + "w", str(width))
    grid = table.find(W + "tblGrid")
    if grid is not None:
        table.remove(grid)
    grid = ET.Element(W + "tblGrid")
    for value in widths:
        ET.SubElement(grid, W + "gridCol", {W + "w": str(value)})
    table.insert(1, grid)
    for index, row in enumerate(rows):
        if len(row.findall(W + "tc")) != len(widths):
            raise ValueError("option table has an unexpected column shape")
        for cell, value in zip(row.findall(W + "tc"), widths):
            cell.find(f"{W}tcPr/{W}tcW").set(W + "w", str(value))
        if not repeat_header:
            for properties in row.findall(W + "trPr"):
                for marker in properties.findall(W + "tblHeader"):
                    properties.remove(marker)
        elif index == 0:
            properties = ET.Element(W + "trPr")
            ET.SubElement(properties, W + "tblHeader")
            row.insert(0, properties)


def plan_insertions(base_xml, donor_xml, chapters):
    children = list(ET.fromstring(base_xml).find(W + "body"))
    donor = list(ET.fromstring(donor_xml).find(W + "body"))
    offsets = body_offsets(base_xml)
    if len(offsets) != len(children):
        raise ValueError("cannot map original Word body to insertion offsets")
    if any(text(e) in ("选项优化", "选项新增") for e in children if heading(e, "Heading2")):
        raise ValueError("base Word must not already contain option tables")
    labels = [c["label"] for c in chapters]
    anchors = {}
    for index, element in enumerate(children):
        if heading(element, "Heading1") and text(element) in labels:
            label = text(element)
            if label in anchors:
                raise ValueError("same chapter has multiple Word headings")
            anchors[label] = index
    visible = [c["label"] for c in chapters if c.get("problems") or c.get("suggestions")]
    if set(anchors) != set(visible):
        raise ValueError("original Word chapter headings do not match the base summary")
    if [label for label, _index in sorted(anchors.items(), key=lambda x: x[1])] != visible:
        raise ValueError("original Word chapter order does not match the summary")
    last = next((i for i, e in enumerate(children) if e.tag == W + "sectPr"), None)
    if last is None:
        raise ValueError("original Word has no terminal section properties")
    donor_anchors = {text(e): i for i, e in enumerate(donor) if heading(e, "Heading1") and text(e) in labels}
    insertions = []
    for chapter in chapters:
        label = chapter["label"]
        if not (chapter.get("option_optimizations") or chapter.get("option_additions")):
            continue
        if label not in donor_anchors:
            raise ValueError("rendered option chapter is missing")
        begin = donor_anchors[label]
        end = next((i for i in range(begin + 1, len(donor))
                    if heading(donor[i], "Heading1") or donor[i].tag == W + "sectPr"), len(donor))
        fragment = deepcopy(donor[begin if label not in anchors else begin + 1:end])
        if label in anchors:
            start = anchors[label]
            boundary = min([i for i in anchors.values() if i > start] + [last])
            index = next((i for i in range(start + 1, boundary)
                          if heading(children[i], "Heading2") and text(children[i]) == "本章建议"), boundary)
        else:
            later_labels = labels[labels.index(label) + 1:]
            index = next((anchors[later] for later in later_labels if later in anchors), last)
        width = width_at(children, index)
        table_title = None
        for element in fragment:
            if list(element.iter(W + "sectPr")):
                raise ValueError("option fragment must not add a section")
            if heading(element, "Heading2"):
                table_title = text(element)
            if element.tag == W + "tbl":
                fit_table(element, width, repeat_header=table_title not in ("选项优化", "选项新增"))
        payload = b"".join(ET.tostring(e, encoding="utf-8") for e in fragment)
        insertions.append((offsets[index], payload))
    return sorted(insertions, key=lambda item: item[0])


def verify_inserted(base_path, final_path, insertions):
    before, after = parts(base_path), parts(final_path)
    if before.keys() != after.keys():
        raise ValueError("Word package parts changed")
    for name in before:
        if name != DOCUMENT and before[name] != after[name]:
            raise ValueError(f"original Word part changed: {name}")
    xml = after[DOCUMENT]
    shift, ranges = 0, []
    for offset, payload in insertions:
        start = offset + shift
        if xml[start:start + len(payload)] != payload:
            raise ValueError("inserted option fragment differs from the verified plan")
        ranges.append((start, start + len(payload)))
        shift += len(payload)
    for start, end in reversed(ranges):
        xml = xml[:start] + xml[end:]
    if xml != before[DOCUMENT]:
        raise ValueError("original Word XML changed outside the inserted options")
    ET.fromstring(after[DOCUMENT])
    return {"original_document_xml_unchanged": True, "other_parts_unchanged": True,
            "page_settings_unchanged": True, "inserted_chapters": len(insertions),
            "base_document_xml_sha256": hashlib.sha256(xml).hexdigest()}


def insert_tables(base_path, donor_path, chapters, output):
    before, donor = parts(base_path), parts(donor_path)
    styles = ET.fromstring(before["word/styles.xml"])
    if not {"Heading1", "Heading2"}.issubset({s.get(W + "styleId") for s in styles}):
        raise ValueError("original Word is missing required heading styles")
    insertions = plan_insertions(before[DOCUMENT], donor[DOCUMENT], chapters)
    xml, cursor = b"", 0
    for offset, payload in insertions:
        xml += before[DOCUMENT][cursor:offset] + payload
        cursor = offset
    xml += before[DOCUMENT][cursor:]
    with zipfile.ZipFile(base_path) as source, zipfile.ZipFile(output, "w") as target:
        target.comment = source.comment
        for info in source.infolist():
            target.writestr(info, xml if info.filename == DOCUMENT else before[info.filename])
    return verify_inserted(base_path, output, insertions)
