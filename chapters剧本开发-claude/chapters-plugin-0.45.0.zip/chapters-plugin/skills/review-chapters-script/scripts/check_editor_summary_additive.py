#!/usr/bin/env python3
"""Reject changed legacy content or incomplete monetization option tables."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys
from typing import Any, Mapping


OPTION_KEYS = {"option_optimizations", "option_additions"}
FINAL_TIERS = {17, 12, 10}
FINAL_TIER_ORDER = [17, 12, 10]
NO_OUTPUT_DECISIONS = {"retain_no_change", "exclude_character_creation"}


def chapter_number(label: str) -> int | None:
    match = re.search(r"第\s*([0-9]+)\s*章|\bChapter\s+([0-9]+)\b", label, re.I)
    if match:
        return int(next(value for value in match.groups() if value is not None))
    match = re.search(r"第\s*([零〇一二两三四五六七八九十百千]+)\s*章", label)
    if not match:
        return None
    digits = dict(zip("零〇一二两三四五六七八九", [0, 0, 1, 2, 2, 3, 4, 5, 6, 7, 8, 9]))
    total = current = 0
    for character in match.group(1):
        if character in digits:
            current = digits[character]
        else:
            total += (current or 1) * {"十": 10, "百": 100, "千": 1000}[character]
            current = 0
    return total + current


def _load(path: Path) -> Mapping[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError(f"cannot read JSON: {path}") from error
    if not isinstance(value, Mapping):
        raise ValueError(f"summary must be a JSON object: {path}")
    return value


def _chapters(summary: Mapping[str, Any], *, source: str) -> list[Mapping[str, Any]]:
    value = summary.get("chapters", [])
    if not isinstance(value, list):
        raise ValueError(f"chapters must be a list in {source}")
    chapters: list[Mapping[str, Any]] = []
    labels: set[str] = set()
    numbers: set[int] = set()
    for index, chapter in enumerate(value):
        if not isinstance(chapter, Mapping):
            raise ValueError(f"chapter {index + 1} must be an object in {source}")
        label = chapter.get("label")
        if not isinstance(label, str) or not label.strip():
            raise ValueError(f"chapter {index + 1} needs a label in {source}")
        if label in labels:
            raise ValueError(f"duplicate chapter label in {source}: {label}")
        number = chapter_number(label)
        if number is not None:
            if number in numbers:
                raise ValueError(f"same chapter has multiple headings in {source}: {number}")
            numbers.add(number)
        labels.add(label)
        chapters.append(chapter)
    return chapters


def _without_options(chapter: Mapping[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in chapter.items() if key not in OPTION_KEYS}


def _option_count(chapters: list[Mapping[str, Any]], key: str) -> int:
    total = 0
    for chapter in chapters:
        value = chapter.get(key, [])
        if not isinstance(value, list):
            raise ValueError(f"{key} must be a list in {chapter['label']}")
        total += len(value)
    return total


def _safe_bundle_file(bundle_root: Path, relative: object) -> Path:
    if not isinstance(relative, str) or not relative:
        raise ValueError("manifest choices path is missing")
    path = (bundle_root / relative).resolve()
    try:
        path.relative_to(bundle_root.resolve())
    except ValueError as error:
        raise ValueError(f"manifest choices path leaves the bundle: {relative}") from error
    return path


def _paid_groups(manifest_path: Path, scope_chapter_ids: list[str]) -> set[str]:
    manifest = _load(manifest_path)
    chapters = manifest.get("chapters")
    if not isinstance(chapters, list):
        raise ValueError("manifest chapters must be a list")
    by_id: dict[str, Mapping[str, Any]] = {}
    for chapter in chapters:
        if not isinstance(chapter, Mapping):
            raise ValueError("manifest chapter must be an object")
        chapter_id = chapter.get("chapter_id")
        if not isinstance(chapter_id, str) or not chapter_id:
            raise ValueError("manifest chapter_id is missing")
        by_id[chapter_id] = chapter
    if not scope_chapter_ids or len(scope_chapter_ids) != len(set(scope_chapter_ids)):
        raise ValueError("coverage scope_chapter_ids must be a non-empty unique list")
    missing_chapters = [item for item in scope_chapter_ids if item not in by_id]
    if missing_chapters:
        raise ValueError("coverage scope has unknown chapters: " + ", ".join(missing_chapters))

    bundle_root = manifest_path.resolve().parent
    result: set[str] = set()
    for chapter_id in scope_chapter_ids:
        files = by_id[chapter_id].get("files")
        if not isinstance(files, Mapping) or not isinstance(files.get("choices"), Mapping):
            raise ValueError(f"manifest choices entry is missing: {chapter_id}")
        choices_path = _safe_bundle_file(bundle_root, files["choices"].get("path"))
        choices = _load(choices_path)
        groups = choices.get("groups")
        if not isinstance(groups, list):
            raise ValueError(f"choices groups must be a list: {chapter_id}")
        for group in groups:
            if not isinstance(group, Mapping):
                raise ValueError(f"choice group must be an object: {chapter_id}")
            group_id = group.get("group_id")
            signals = group.get("signals", {})
            branches = group.get("branches", [])
            premium = (
                isinstance(signals, Mapping)
                and signals.get("has_premium_branch") is True
            ) or (
                isinstance(branches, list)
                and any(
                    isinstance(branch, Mapping) and branch.get("premium") is True
                    for branch in branches
                )
            )
            if premium:
                if not isinstance(group_id, str) or not group_id:
                    raise ValueError(f"paid choice group has no group_id: {chapter_id}")
                if group_id in result:
                    raise ValueError(f"duplicate paid group_id in manifest scope: {group_id}")
                result.add(group_id)
    return result


def _tiers(value: object, *, key: str) -> list[int | str]:
    if not isinstance(value, list):
        raise ValueError(f"required_tiers must be a list: {key}")
    tiers: list[int | str] = []
    for tier in value:
        valid_tier = (
            isinstance(tier, int)
            and not isinstance(tier, bool)
            and tier in FINAL_TIERS
        ) or tier == "cancel"
        if not valid_tier:
            raise ValueError(f"invalid tier in {key}: {tier}")
        if tier in tiers:
            raise ValueError(f"duplicate tier in {key}: {tier}")
        tiers.append(tier)
    return tiers


def _commercial_rows(
    chapters: list[Mapping[str, Any]], key: str
) -> list[tuple[str, str, int | str]]:
    rows: list[tuple[str, str, int | str]] = []
    for chapter in chapters:
        value = chapter.get(key, [])
        if not isinstance(value, list):
            raise ValueError(f"{key} must be a list in {chapter['label']}")
        for index, row in enumerate(value):
            if not isinstance(row, Mapping):
                raise ValueError(f"{key} row {index + 1} must be an object")
            coverage_key = row.get("coverage_key")
            tier = row.get("tier")
            if not isinstance(coverage_key, str) or not coverage_key:
                raise ValueError(f"{key} row {index + 1} needs coverage_key")
            valid_tier = (
                isinstance(tier, int)
                and not isinstance(tier, bool)
                and tier in FINAL_TIERS
            ) or tier == "cancel"
            if not valid_tier:
                raise ValueError(f"{key} row {index + 1} has invalid tier")
            rows.append((str(chapter["label"]), coverage_key, tier))
    return rows


def _check_commercial_coverage(
    after_chapters: list[Mapping[str, Any]],
    coverage: Mapping[str, Any],
    *,
    manifest_path: Path,
) -> dict[str, int]:
    scope = coverage.get("scope_chapter_ids")
    if not isinstance(scope, list) or any(not isinstance(item, str) for item in scope):
        raise ValueError("coverage scope_chapter_ids must be a string list")
    manifest_paid = _paid_groups(manifest_path, scope)
    manifest = _load(manifest_path)
    manifest_chapters = manifest.get("chapters")
    if not isinstance(manifest_chapters, list):
        raise ValueError("manifest chapters must be a list")
    labels_by_id: dict[str, str] = {}
    supplied_bindings = coverage.get("chapter_bindings", {})
    if not isinstance(supplied_bindings, Mapping):
        raise ValueError("chapter_bindings must map chapter_id to the original label")
    for chapter in manifest_chapters:
        if not isinstance(chapter, Mapping):
            raise ValueError("manifest chapter must be an object")
        chapter_id = chapter.get("chapter_id")
        number = chapter.get("number")
        if isinstance(chapter_id, str) and isinstance(number, int) and not isinstance(number, bool):
            matching = [item["label"] for item in after_chapters if chapter_number(str(item["label"])) == number]
            label = supplied_bindings.get(chapter_id)
            if label is None:
                if len(matching) > 1:
                    raise ValueError(f"same chapter has multiple headings: {chapter_id}")
                label = matching[0] if matching else f"第 {number} 章"
            if not isinstance(label, str) or not label.strip():
                raise ValueError(f"invalid chapter binding: {chapter_id}")
            if matching and label != matching[0]:
                raise ValueError(f"chapter binding changes the original heading: {chapter_id}")
            labels_by_id[chapter_id] = label
    scope_labels = [labels_by_id[item] for item in scope]
    if len(scope_labels) != len(set(scope_labels)):
        raise ValueError("coverage scope resolves to duplicate chapter labels")

    def item_label(item: Mapping[str, Any]) -> object:
        chapter_id = item.get("chapter_id")
        if chapter_id is None:
            return item.get("chapter_label")
        if chapter_id not in scope:
            raise ValueError(f"coverage item is outside scope: {chapter_id}")
        label = labels_by_id[chapter_id]
        if item.get("chapter_label", label) != label:
            raise ValueError(f"coverage item changes the original heading: {chapter_id}")
        return label

    existing = coverage.get("existing_paid_groups")
    additions = coverage.get("new_paid_nodes")
    if not isinstance(existing, list) or not isinstance(additions, list):
        raise ValueError("coverage needs existing_paid_groups and new_paid_nodes lists")

    expected_optimizations: dict[str, tuple[str, list[int | str]]] = {}
    expected_additions: dict[str, tuple[str, list[int | str]]] = {}
    covered_groups: set[str] = set()
    all_coverage_keys: set[str] = set()
    coverage_index: dict[str, tuple[str, str]] = {}
    retained_or_excluded = 0

    for index, item in enumerate(existing):
        if not isinstance(item, Mapping):
            raise ValueError(f"existing_paid_groups row {index + 1} must be an object")
        coverage_key = item.get("coverage_key")
        chapter_label = item_label(item)
        decision = item.get("decision")
        group_ids = item.get("group_ids")
        if not isinstance(coverage_key, str) or not coverage_key:
            raise ValueError(f"existing_paid_groups row {index + 1} needs coverage_key")
        if coverage_key in all_coverage_keys:
            raise ValueError(f"duplicate coverage_key: {coverage_key}")
        all_coverage_keys.add(coverage_key)
        if not isinstance(chapter_label, str) or not chapter_label:
            raise ValueError(f"existing_paid_groups row {index + 1} needs chapter_label")
        if not isinstance(group_ids, list) or not group_ids or any(
            not isinstance(group_id, str) or not group_id for group_id in group_ids
        ):
            raise ValueError(f"existing_paid_groups row {index + 1} needs group_ids")
        if len(group_ids) != len(set(group_ids)):
            raise ValueError(f"duplicate group_id inside coverage item: {coverage_key}")
        duplicate_groups = covered_groups.intersection(group_ids)
        if duplicate_groups:
            raise ValueError("paid groups appear twice in coverage: " + ", ".join(sorted(duplicate_groups)))
        covered_groups.update(group_ids)
        tiers = _tiers(item.get("required_tiers"), key=coverage_key)
        if decision == "optimize":
            if tiers != FINAL_TIER_ORDER:
                raise ValueError(f"optimized final node needs 17/12/10 tiers: {coverage_key}")
            expected_optimizations[coverage_key] = (chapter_label, tiers)
        elif decision == "cancel":
            if tiers != ["cancel"]:
                raise ValueError(f"cancelled node needs the cancel tier: {coverage_key}")
            expected_optimizations[coverage_key] = (chapter_label, tiers)
        elif decision in NO_OUTPUT_DECISIONS:
            if tiers:
                raise ValueError(f"no-output decision cannot require tiers: {coverage_key}")
            retained_or_excluded += len(group_ids)
        else:
            raise ValueError(f"invalid existing decision in {coverage_key}: {decision}")
        coverage_index[coverage_key] = (chapter_label, str(decision))

    if covered_groups != manifest_paid:
        missing = sorted(manifest_paid - covered_groups)
        extra = sorted(covered_groups - manifest_paid)
        details = []
        if missing:
            details.append("missing " + ", ".join(missing))
        if extra:
            details.append("unknown " + ", ".join(extra))
        raise ValueError("paid-group coverage is incomplete: " + "; ".join(details))

    for index, item in enumerate(additions):
        if not isinstance(item, Mapping):
            raise ValueError(f"new_paid_nodes row {index + 1} must be an object")
        coverage_key = item.get("coverage_key")
        chapter_label = item_label(item)
        decision = item.get("decision")
        if not isinstance(coverage_key, str) or not coverage_key:
            raise ValueError(f"new_paid_nodes row {index + 1} needs coverage_key")
        if coverage_key in all_coverage_keys:
            raise ValueError(f"duplicate coverage_key: {coverage_key}")
        all_coverage_keys.add(coverage_key)
        if not isinstance(chapter_label, str) or not chapter_label:
            raise ValueError(f"new_paid_nodes row {index + 1} needs chapter_label")
        tiers = _tiers(item.get("required_tiers"), key=coverage_key)
        if decision == "add":
            if tiers != FINAL_TIER_ORDER:
                raise ValueError(f"new final node needs 17/12/10 tiers: {coverage_key}")
            expected_additions[coverage_key] = (chapter_label, tiers)
        elif decision == "reject":
            if tiers:
                raise ValueError(f"rejected candidate cannot require tiers: {coverage_key}")
        else:
            raise ValueError(f"invalid new-node decision in {coverage_key}: {decision}")
        coverage_index[coverage_key] = (chapter_label, str(decision))

    actual_optimizations = _commercial_rows(after_chapters, "option_optimizations")
    actual_additions = _commercial_rows(after_chapters, "option_additions")

    def compare(
        actual: list[tuple[str, str, int | str]],
        expected: Mapping[str, tuple[str, list[int | str]]],
        *,
        name: str,
    ) -> None:
        grouped: dict[str, list[tuple[str, int | str]]] = {}
        for chapter_label, coverage_key, tier in actual:
            grouped.setdefault(coverage_key, []).append((chapter_label, tier))
        unknown = set(grouped) - set(expected)
        if unknown:
            raise ValueError(f"unknown {name} coverage keys: " + ", ".join(sorted(unknown)))
        missing = set(expected) - set(grouped)
        if missing:
            raise ValueError(f"missing {name} coverage keys: " + ", ".join(sorted(missing)))
        for coverage_key, (chapter_label, required) in expected.items():
            observed = grouped[coverage_key]
            if any(label != chapter_label for label, _tier in observed):
                raise ValueError(f"{name} is in the wrong chapter: {coverage_key}")
            observed_tiers = [tier for _label, tier in observed]
            if len(observed_tiers) != len(set(observed_tiers)):
                raise ValueError(f"duplicate {name} tier: {coverage_key}")
            if observed_tiers != required:
                raise ValueError(f"{name} tiers are incomplete or out of order: {coverage_key}")

    compare(actual_optimizations, expected_optimizations, name="optimization")
    compare(actual_additions, expected_additions, name="addition")

    action_labels = {
        chapter_label
        for chapter_label, _tiers in list(expected_optimizations.values())
        + list(expected_additions.values())
    }
    expected_exception_labels = set(scope_labels) - action_labels
    exceptions = coverage.get("chapter_action_exceptions")
    if not isinstance(exceptions, list):
        raise ValueError("coverage needs a chapter_action_exceptions list")
    observed_exception_labels: set[str] = set()
    for index, item in enumerate(exceptions):
        if not isinstance(item, Mapping):
            raise ValueError(f"chapter_action_exceptions row {index + 1} must be an object")
        chapter_label = item_label(item)
        reason = item.get("reason")
        evidence_keys = item.get("second_pass_coverage_keys")
        if not isinstance(chapter_label, str) or not chapter_label:
            raise ValueError(f"chapter_action_exceptions row {index + 1} needs chapter_label")
        if chapter_label in observed_exception_labels:
            raise ValueError(f"duplicate chapter action exception: {chapter_label}")
        observed_exception_labels.add(chapter_label)
        if not isinstance(reason, str) or not reason.strip():
            raise ValueError(f"chapter action exception needs a specific reason: {chapter_label}")
        if not isinstance(evidence_keys, list) or not evidence_keys or any(
            not isinstance(key, str) or not key for key in evidence_keys
        ):
            raise ValueError(f"chapter action exception needs second-pass evidence: {chapter_label}")
        if len(evidence_keys) != len(set(evidence_keys)):
            raise ValueError(f"duplicate second-pass evidence key: {chapter_label}")
        unknown_keys = [key for key in evidence_keys if key not in coverage_index]
        if unknown_keys:
            raise ValueError(
                f"unknown second-pass evidence in {chapter_label}: " + ", ".join(unknown_keys)
            )
        wrong_chapter = [
            key for key in evidence_keys if coverage_index[key][0] != chapter_label
        ]
        if wrong_chapter:
            raise ValueError(
                f"second-pass evidence is in the wrong chapter for {chapter_label}: "
                + ", ".join(wrong_chapter)
            )
        if not any(coverage_index[key][1] == "reject" for key in evidence_keys):
            raise ValueError(
                f"chapter action exception must cite a rejected new-node candidate: {chapter_label}"
            )

    if observed_exception_labels != expected_exception_labels:
        missing = sorted(expected_exception_labels - observed_exception_labels)
        extra = sorted(observed_exception_labels - expected_exception_labels)
        details = []
        if missing:
            details.append("missing " + ", ".join(missing))
        if extra:
            details.append("unexpected " + ", ".join(extra))
        raise ValueError("chapter action coverage is incomplete: " + "; ".join(details))
    return {
        "manifest_paid_groups": len(manifest_paid),
        "retained_or_excluded_groups": retained_or_excluded,
        "optimization_nodes": len(expected_optimizations),
        "addition_nodes": len(expected_additions),
        "chapters_with_actions": len(action_labels),
        "chapter_action_exceptions": len(observed_exception_labels),
    }


def check(
    before: Mapping[str, Any],
    after: Mapping[str, Any],
    coverage: Mapping[str, Any] | None = None,
    *,
    manifest_path: Path | None = None,
) -> dict[str, Any]:
    before_top = {key: value for key, value in before.items() if key != "chapters"}
    after_top = {key: value for key, value in after.items() if key != "chapters"}
    if before_top != after_top:
        raise ValueError("top-level legacy fields changed")

    before_chapters = _chapters(before, source="before")
    after_chapters = _chapters(after, source="after")
    before_by_label = {chapter["label"]: chapter for chapter in before_chapters}
    after_by_label = {chapter["label"]: chapter for chapter in after_chapters}

    missing = [label for label in before_by_label if label not in after_by_label]
    if missing:
        raise ValueError("legacy chapters were removed: " + ", ".join(missing))

    before_order = [chapter["label"] for chapter in before_chapters]
    after_legacy_order = [
        chapter["label"]
        for chapter in after_chapters
        if chapter["label"] in before_by_label
    ]
    if before_order != after_legacy_order:
        raise ValueError("legacy chapter order changed")

    for label, legacy in before_by_label.items():
        if _without_options(after_by_label[label]) != dict(legacy):
            raise ValueError(f"legacy chapter content changed: {label}")

    new_labels: list[str] = []
    for label, chapter in after_by_label.items():
        if label in before_by_label:
            continue
        legacy_part = _without_options(chapter)
        allowed = {"label", "problems", "suggestions"}
        if set(legacy_part) - allowed:
            raise ValueError(f"new PC-only chapter has unexpected legacy fields: {label}")
        if legacy_part.get("problems", []) or legacy_part.get("suggestions", []):
            raise ValueError(f"new PC-only chapter changes legacy output: {label}")
        new_labels.append(label)

    receipt = {
        "status": "compatible",
        "legacy_chapters": len(before_chapters),
        "new_pc_only_chapters": len(new_labels),
        "option_optimizations": _option_count(after_chapters, "option_optimizations"),
        "option_additions": _option_count(after_chapters, "option_additions"),
    }
    if coverage is not None:
        if manifest_path is None:
            raise ValueError("manifest_path is required with coverage")
        receipt.update(
            _check_commercial_coverage(
                after_chapters, coverage, manifest_path=manifest_path
            )
        )
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Check that PC option tables are strictly additive."
    )
    parser.add_argument("--before", required=True, type=Path)
    parser.add_argument("--after", required=True, type=Path)
    parser.add_argument("--coverage", type=Path)
    parser.add_argument("--manifest", type=Path)
    args = parser.parse_args()
    try:
        if (args.coverage is None) != (args.manifest is None):
            raise ValueError("--coverage and --manifest must be used together")
        receipt = check(
            _load(args.before),
            _load(args.after),
            None if args.coverage is None else _load(args.coverage),
            manifest_path=args.manifest,
        )
    except ValueError as error:
        print(json.dumps({"status": "incompatible", "error": str(error)}, ensure_ascii=False))
        return 1
    print(json.dumps(receipt, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
