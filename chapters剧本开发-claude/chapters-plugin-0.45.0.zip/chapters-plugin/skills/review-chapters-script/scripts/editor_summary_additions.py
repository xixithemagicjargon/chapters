#!/usr/bin/env python3
"""Freeze a real base review, merge chapter-scoped additions, and verify the result."""

from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile

from check_editor_summary_additive import OPTION_KEYS, _chapters, chapter_number, check
from insert_option_tables import heading, insert_tables, text as paragraph_text


PLUGIN = Path(__file__).resolve().parents[3]
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def read(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path: Path, value, *, exclusive=False):
    data = json.dumps(value, ensure_ascii=False, indent=2) + "\n"
    if exclusive and path.exists():
        if read(path) != value:
            raise ValueError(f"refusing to replace the frozen baseline: {path}")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data, encoding="utf-8")


def signature(manifest):
    return {
        "parser": manifest["parser"],
        "sources": [(item["path"], item["sha256"]) for item in manifest["sources"]],
        "chapters": [(item["chapter_id"], item["number"], item["files"])
                     for item in manifest["chapters"]],
    }


def run_runtime(*arguments):
    result = subprocess.run(
        [sys.executable, "-X", "utf8", str(PLUGIN / "shared/scripts/chapters.py"), *map(str, arguments)],
        capture_output=True, text=True, encoding="utf-8",
    )
    if result.returncode:
        raise ValueError(result.stdout.strip() or result.stderr.strip())
    receipt = json.loads(result.stdout)
    if receipt.get("status") == "error":
        raise ValueError(str(receipt))
    return receipt


def bindings_for(summary, manifest, explicit=None):
    chapters = _chapters(summary, source="baseline")
    explicit = explicit or {}
    if not isinstance(explicit, dict):
        raise ValueError("bindings must map chapter_id to the original chapter label")
    manifest_by_id = {item["chapter_id"]: item for item in manifest["chapters"]}
    if set(explicit) - set(manifest_by_id):
        raise ValueError("bindings contain an unknown chapter_id")
    labels = {item["label"] for item in chapters}
    bindings = {}
    for chapter_id, chapter in manifest_by_id.items():
        candidates = [label for label in labels if chapter_number(label) == chapter["number"]]
        label = explicit.get(chapter_id)
        if label is not None:
            if label not in labels or (candidates and label not in candidates):
                raise ValueError(f"binding does not identify the original chapter: {chapter_id}")
        elif len(candidates) == 1:
            label = candidates[0]
        elif len(candidates) > 1:
            raise ValueError(f"same chapter has multiple headings: {chapter_id}")
        if label is not None:
            bindings[chapter_id] = label
    if len(set(bindings.values())) != len(bindings) or set(bindings.values()) != labels:
        raise ValueError("each baseline chapter needs exactly one manifest chapter; supply --bindings for titles without chapter numbers")
    return bindings


def document_base_text(path):
    """Compare visible base content, ignoring layout and the two additive tables."""
    with zipfile.ZipFile(path) as archive:
        body = ET.fromstring(archive.read("word/document.xml")).find(W + "body")
    result, skip_table = [], False
    for element in body:
        if element.tag == W + "sectPr":
            continue
        label = "".join(n.text or "" for n in element.iter(W + "t"))
        if element.tag == W + "p" and label in ("选项优化", "选项新增"):
            skip_table = True
            continue
        if skip_table and element.tag == W + "tbl":
            headers = ["".join(n.text or "" for n in cell.iter(W + "t"))
                       for cell in element.find(W + "tr").findall(W + "tc")]
            if not headers or headers[0] != "位置":
                raise ValueError("baseline option heading is not followed by an option table")
            skip_table = False
            continue
        if label:
            if skip_table:
                raise ValueError("ambiguous baseline option section")
            paragraphs = [element] if element.tag == W + "p" else element.iter(W + "p")
            for paragraph in paragraphs:
                value = "".join(n.text or "" for n in paragraph.iter(W + "t"))
                if value:
                    result.append(value)
    if skip_table:
        raise ValueError("baseline option section has no table")
    return result


def confirm_baseline_document(summary_path, document_path):
    with zipfile.ZipFile(document_path) as archive:
        body = ET.fromstring(archive.read("word/document.xml")).find(W + "body")
    if any(heading(element, "Heading2") and paragraph_text(element) in ("选项优化", "选项新增")
           for element in body):
        raise ValueError("base Word already contains option tables; use its unmodified base backup")
    with tempfile.TemporaryDirectory(prefix="chapters-baseline-") as folder:
        rendered = Path(folder) / "base.docx"
        run_runtime("editor-docx", "--summary", summary_path, "--output", rendered)
        if document_base_text(rendered) != document_base_text(document_path):
            raise ValueError("summary does not match the completed base Word; do not freeze a rewritten summary")


def freeze(args):
    base = read(args.summary)
    if any(OPTION_KEYS.intersection(chapter) for chapter in base.get("chapters", [])):
        raise ValueError("baseline must be the original summary, not a summary rewritten with options")
    manifest = read(args.manifest)
    source_manifest = args.source_manifest or args.manifest
    if signature(manifest) != signature(read(source_manifest)):
        raise ValueError("source review and current manuscript differ; do not reuse the old report")
    run_runtime("validate", "--manifest", source_manifest, "--annotations", args.annotations,
                "--findings", args.findings, "--metrics", args.metrics)
    bindings = bindings_for(base, manifest, read(args.bindings) if args.bindings else None)
    if not args.baseline_docx:
        raise ValueError("freeze requires --baseline-docx: finish the base Word before option analysis")
    confirm_baseline_document(args.summary, args.baseline_docx)
    protected = [args.summary, args.report, args.annotations, args.findings, args.metrics,
                 source_manifest, args.manifest, PLUGIN / "shared/rules/editorial-rubric.md",
                 PLUGIN / "shared/rules/metrics-config.json"]
    backup = args.snapshot.with_suffix(".docx")
    inputs = {path.resolve() for path in protected + [args.baseline_docx]}
    if args.snapshot.resolve() in inputs or backup.resolve() in inputs or backup == args.snapshot:
        raise ValueError("snapshot cannot overwrite an original artifact")
    if args.snapshot.exists() or backup.exists():
        raise ValueError("refusing to replace the frozen baseline; choose a new snapshot filename")
    args.snapshot.parent.mkdir(parents=True, exist_ok=True)
    with backup.open("xb") as target:
        target.write(args.baseline_docx.read_bytes())
    protected.append(backup)
    snapshot = {
        "format": "editor-summary-baseline-v3",
        "mode": getattr(args, "mode", "fresh"),
        "base_docx_path": str(backup.resolve()),
        "source_docx_path": str(args.baseline_docx.resolve()),
        "manifest_path": str(args.manifest.resolve()),
        "source_summary_path": str(args.summary.resolve()),
        "base_summary": base,
        "chapter_bindings": bindings,
        "protected_files": {str(path.resolve()): digest(path) for path in protected},
    }
    write(args.snapshot, snapshot, exclusive=True)
    return {"status": "frozen", "snapshot": str(args.snapshot.resolve()),
            "base_docx_backup": str(backup.resolve()),
            "problem_rows": sum(len(c.get("problems", [])) for c in base["chapters"]),
            "suggestions": sum(len(c.get("suggestions", [])) for c in base["chapters"])}


def verify_snapshot(path):
    snapshot = read(path)
    if snapshot.get("format") != "editor-summary-baseline-v3":
        raise ValueError("baseline needs re-freezing with the completed original Word; original audit records need not be rewritten")
    if snapshot.get("base_docx_path") not in snapshot.get("protected_files", {}):
        raise ValueError("baseline has no protected original Word backup")
    for filename, expected in snapshot["protected_files"].items():
        if digest(Path(filename)) != expected:
            raise ValueError(f"original review changed after freezing: {filename}")
    if read(Path(snapshot["source_summary_path"])) != snapshot["base_summary"]:
        raise ValueError("snapshot does not contain the actual original summary")
    return snapshot


def assemble(snapshot, addon, coverage, manifest):
    if set(addon) != {"chapters"} or not isinstance(addon["chapters"], list):
        raise ValueError("addon may contain only a chapters list")
    final = deepcopy(snapshot["base_summary"])
    bindings = dict(snapshot["chapter_bindings"])
    by_id = {item["chapter_id"]: item for item in manifest["chapters"]}
    by_label = {chapter["label"]: chapter for chapter in final["chapters"]}
    scope = coverage.get("scope_chapter_ids", [])
    seen = set()
    for item in addon["chapters"]:
        if not isinstance(item, dict) or set(item) - (OPTION_KEYS | {"chapter_id"}):
            raise ValueError("addon cannot supply titles, ordinary problems, or suggestions")
        chapter_id = item.get("chapter_id")
        if chapter_id not in by_id or chapter_id not in scope or chapter_id in seen:
            raise ValueError(f"unknown, repeated or out-of-scope addon chapter: {chapter_id}")
        seen.add(chapter_id)
        label = bindings.get(chapter_id)
        if label is None:
            number = by_id[chapter_id]["number"]
            label = f"第 {number} 章"
            if label in by_label:
                raise ValueError("new option-only chapter collides with an original chapter")
            chapter = {"label": label, "problems": [], "suggestions": []}
            later = next((index for index, c in enumerate(final["chapters"])
                          if (chapter_number(c["label"]) or -1) > number), len(final["chapters"]))
            final["chapters"].insert(later, chapter)
            by_label[label] = chapter
            bindings[chapter_id] = label
        for key in OPTION_KEYS:
            value = item.get(key, [])
            if not isinstance(value, list):
                raise ValueError(f"{key} must be a list")
            by_label[label][key] = deepcopy(value)
    resolved = deepcopy(coverage)
    resolved["chapter_bindings"] = bindings
    for collection in ("existing_paid_groups", "new_paid_nodes", "chapter_action_exceptions"):
        for item in resolved.get(collection, []):
            chapter_id = item.get("chapter_id")
            if chapter_id not in by_id or chapter_id not in scope:
                raise ValueError(f"coverage needs an in-scope chapter_id: {chapter_id}")
            item["chapter_label"] = bindings.get(chapter_id, f"第 {by_id[chapter_id]['number']} 章")
    return final, resolved


def merge(args):
    snapshot = verify_snapshot(args.snapshot)
    manifest_path = Path(snapshot["manifest_path"])
    final, coverage = assemble(snapshot, read(args.addon), read(args.coverage), read(manifest_path))
    receipt = check(snapshot["base_summary"], final, coverage, manifest_path=manifest_path)
    protected = {Path(path).resolve() for path in snapshot["protected_files"]}
    protected.update(path.resolve() for path in (args.snapshot, args.addon, args.coverage))
    original = Path(snapshot["source_docx_path"])
    backup = Path(snapshot["base_docx_path"])
    outputs = [args.output, args.resolved_coverage, args.docx]
    if len({path.resolve() for path in outputs}) != len(outputs) or any(path.resolve() in protected for path in outputs):
        raise ValueError("outputs must be distinct and cannot overwrite protected inputs")
    if original.resolve() in {args.output.resolve(), args.resolved_coverage.resolve()}:
        raise ValueError("JSON output cannot overwrite the base Word")
    if snapshot.get("mode") == "preserve" and args.docx.resolve() == original.resolve():
        raise ValueError("a historical Word must be preserved in a different output file")
    if args.docx.suffix.lower() != ".docx":
        raise ValueError("Word output must end in .docx")
    if digest(original) != digest(backup):
        raise ValueError("base Word changed after freezing; do not replace an edited document")
    # The combined JSON is an audit record only. Render an option-only donor,
    # then splice its fragments into the immutable original Word package.
    options_only = {"chapters": [
        {"label": c["label"], **{key: c.get(key, []) for key in OPTION_KEYS}}
        for c in final["chapters"]
    ]}
    args.docx.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".option-insert-", dir=args.docx.parent) as folder:
        folder = Path(folder)
        donor_json, donor_docx = folder / "options.json", folder / "options.docx"
        staged = folder / "verified.docx"
        write(donor_json, options_only)
        rendered = run_runtime("editor-docx", "--summary", donor_json, "--output", donor_docx)
        if rendered["problem_rows"] or rendered["suggestions"]:
            raise ValueError("option fragment must not render any base problems or suggestions")
        verification = insert_tables(backup, donor_docx, final["chapters"], staged)
        verify_snapshot(args.snapshot)
        if digest(original) != digest(backup):
            raise ValueError("base Word changed during insertion")
        if args.docx.exists() and args.docx.resolve() != original.resolve():
            raise ValueError("output Word already exists; choose a new output filename")
        write(args.output, final)
        write(args.resolved_coverage, coverage)
        os.replace(staged, args.docx)
    receipt["document"] = {
        "output_path": str(args.docx.resolve()),
        "problem_rows": sum(len(c.get("problems", [])) for c in snapshot["base_summary"]["chapters"]),
        "suggestions": sum(len(c.get("suggestions", [])) for c in snapshot["base_summary"]["chapters"]),
        **verification,
    }
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    start = commands.add_parser("freeze")
    start.add_argument("--mode", choices=("fresh", "preserve"), default="fresh",
                       help="optional compatibility flag; both modes freeze an already completed Word")
    for flag in ("summary", "report", "annotations", "findings", "metrics", "manifest", "snapshot"):
        start.add_argument("--" + flag, type=Path, required=True)
    start.add_argument("--source-manifest", type=Path)
    start.add_argument("--bindings", type=Path)
    start.add_argument("--include-english", action="store_true")
    start.add_argument("--baseline-docx", type=Path, required=True)
    finish = commands.add_parser("merge")
    for flag in ("snapshot", "addon", "coverage", "output", "resolved-coverage"):
        finish.add_argument("--" + flag, type=Path, required=True)
    finish.add_argument("--docx", type=Path, required=True)
    args = parser.parse_args()
    try:
        result = freeze(args) if args.command == "freeze" else merge(args)
    except (ValueError, OSError, KeyError, TypeError, IndexError, zipfile.BadZipFile, ET.ParseError) as error:
        print(json.dumps({"status": "error", "message": str(error)}, ensure_ascii=False))
        return 1
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
