# 选项优化与新增的全量商业化方案

本文件只控制 `analysis/editor-summary.docx` 的“选项优化”和“选项新增”两张表。进入本步骤前，完整审核报告、普通问题表和原本章建议必须已经完成并冻结；本步骤不得反向改动这些内容，也不得向 `annotations.ndjson`、`findings.ndjson` 或 `audit-report.md` 追加商业化方案。

## 必须采用的完整标准

开始前完整阅读以下同插件资源，并以其当前版本作为商业化方案的唯一详细标准：

- `../../interactive-fiction-monetization-review/references/review-standard-v1.7.md`
- `../../interactive-fiction-monetization-review/references/pc-tagging-rules.md`
- `../../interactive-fiction-monetization-review/references/report-specification-v1.7.md`

这里整合的是该 Skill 的**全部选项优化与新增方法和结论范围**，不是只抽取几个示例。不要生成另一份商业化报告；把结果映射到本文规定的两张现有表即可。

商业化方案是编辑建议，不替代共享 Rubric 与 Metrics 的合格判断。17／12／10、4+2、连续购买链、欲望去重等只控制两张商业化表，不改变完整审核的检测结果、状态、计数和优先级。

## 覆盖范围

对本次审核范围执行两遍扫描：

1. **现有付费组全覆盖**：逐章查看 `choices.json` 中每个含 Premium 分支的物理选择组，包括叙事 PC、PO 和角色创建／捏脸组。每个组必须进入覆盖台账且只能出现一次。
2. **未收费正文全扫描**：通读范围内尚未收费的正文，记录所有成熟商业节点候选；每个认真评估过的候选必须明确为“新增”或“拒绝”。不能只看原有 PC 附近，也不能只补 Metrics 报出的数量缺口。

角色创建／捏脸不是叙事 PC，可在台账中标为 `exclude_character_creation`，不进入两张表。PO 属于商业选项：需要重构时进入“选项优化”，适合新增时进入“选项新增”，但继续遵守原有 PO 数量和标记规则。

## 逐章可执行项目标

商业化方案以**每章至少一个可执行项**为默认目标。可执行项是 `optimize`、`cancel` 或 `add`；`retain_no_change` 和 `reject` 只能证明做过判断，不能代替给编辑的方案。

如果某章第一遍扫描没有可执行项，必须对该章做第二遍专项复查：

1. 逐个重看所有现有付费组的触发位置、按钮承诺、三档差异、正文兑现、免费路径、合流、回收、相邻重复和价格结构；“能用”不等于“没有可提高之处”，优先挑对购买意愿影响最大的一个节点。
2. 重新扫描未收费正文中的冲突升级、秘密揭露、主动取证、关系壁垒、能力展示、公开站队、亲密推进、服装场景和章末转折；可考虑移动或合并现有收费点，不只考虑原地改按钮。
3. 对照本章的数量缺口、购买链空档和欲望重复，判断是否存在成熟的新节点；Metrics 缺口是寻找方向，不是强行收费的依据。
4. 在候选都列明后，选择一个最成熟、最不重复、最容易完整兑现的节点进入最终表。不要为了凑数把主线必需信息、普通转场或尚未形成结果的铺垫改成收费内容。

只有第二遍仍找不到安全、成熟且不重复的节点时，该章才可没有可执行项。此时必须在 `chapter_action_exceptions` 中说明为什么留空，并引用至少一个该章 `reject` 候选及本章复查过的覆盖项。留空是例外，不得用“现有节点都可以”“没有明显问题”等空泛理由。

## 覆盖台账

在 `analysis/notes/pc-monetization-coverage.json` 建立机器可核对的台账。所有条目使用 manifest 的 `chapter_id` 关联真实章节，不手写显示标题；合并工具自动绑定原章节标题。内部 `coverage_key` 和 `group_ids` 不显示在 docx；它们只防止漏项、重复和错章。

```json
{
  "scope_chapter_ids": ["ch-001"],
  "existing_paid_groups": [
    {
      "coverage_key": "existing-ch1-public-choice",
      "chapter_id": "ch-001",
      "group_ids": ["group-id-from-bundle"],
      "decision": "optimize",
      "required_tiers": [17, 12, 10]
    },
    {
      "coverage_key": "existing-ch1-character-creation",
      "chapter_id": "ch-001",
      "group_ids": ["group-id-from-bundle"],
      "decision": "exclude_character_creation",
      "required_tiers": []
    }
  ],
  "new_paid_nodes": [
    {
      "coverage_key": "new-ch1-e248-conflict",
      "chapter_id": "ch-001",
      "decision": "add",
      "required_tiers": [17, 12, 10]
    },
    {
      "coverage_key": "candidate-ch1-transition",
      "chapter_id": "ch-001",
      "decision": "reject",
      "required_tiers": []
    }
  ],
  "chapter_action_exceptions": [
    {
      "chapter_id": "ch-001",
      "reason": "第二遍复查后仍无安全节点：现有角色创建组不属于叙事收费，狼群身份揭示又是理解下一章所需的主线信息。",
      "second_pass_coverage_keys": [
        "existing-ch1-character-creation",
        "candidate-ch1-transition"
      ]
    }
  ]
}
```

现有付费组的 `decision` 只允许：

- `optimize`：保留商业节点，但重做位置、按钮、分支商品、正文兑现、免费路径、合流或回收；输出 17／12／10 三行。
- `cancel`：取消独立收费或并入另一节点；输出一行，`required_tiers` 为 `["cancel"]`。
- `retain_no_change`：按完整商业化标准检查后确实无需调整；不进入表，但必须留在台账。
- `exclude_character_creation`：角色创建／捏脸组；不进入表，但必须留在台账。

相邻物理组确实合并为一个最终商业节点时，可以在同一台账项列出多个 `group_ids`；每个物理组仍只能归属一项。不得用“同类问题若干处”代替逐组归档。

新增候选的 `decision` 只允许 `add` 或 `reject`。`add` 必须输出 17／12／10 三行；`reject` 不进入表，但保留在台账，理由写在分析笔记中。

`chapter_action_exceptions` 只记录没有任何可执行项的章节。每项必须有 `chapter_id`、具体理由和 `second_pass_coverage_keys`；引用项必须属于同章，且至少包含一个被拒绝的新增候选。已经有 `optimize`、`cancel` 或 `add` 的章节不得再写例外。

## 形成最终商业蓝图

严格执行 v1.7 的取舍顺序：先确定核心渴望、关系壁垒和人物进度，再评估现有节点，扫描新增节点，最后整体去重、排布付费节奏和连续购买链。输出一套最终蓝图，不给互相竞争、让编辑自行挑选的多套方向。

每个最终叙事 PC 或 PO 节点都设计三个**彼此独立、完整兑现**的 Premium 商品：

- **17 币**：该节点最强、最完整的行动与结果；
- **12 币**：不同的主要欲望、行动路径或关系／剧情结果，不是 17 币的删减版；
- **10 币**：更轻但仍完整的独立体验，不是缩水版或少写几行。

同一节点三档必须在行动、即时反馈、关系或剧情变化、公开范围、角色反应、资产／线索或后续回收中形成实质区别。免费分支保留理解和推进主线所需内容，但明确错过付费独享结果；合流不得默认玩家购买了任何一档。

每档方案都必须写清：

1. 玩家当前最想得到的具体结果，以及这档打破的壁垒；
2. MC 的具体动作或决定、对方／环境的即时反馈和玩家可见结果；
3. 至少三个按顺序发生的付费回报节拍与收束；
4. 免费分支保留什么、错过什么，以及安全合流状态；
5. 可验证的后续回收；无自然依据时明确“本章内收束”；
6. 与本章前后付费点及同节点另两档的区别；
7. PC 标签与购买链阶段，按 v1.7 的标记规则给出。

按钮必须是玩家当下能执行、且购买前能预期结果的英文行动／决定。不得使用 `Continue...`、`Yes.`、`Tell me more.` 等流程词，也不得把中文设计说明当按钮。

## 映射到选项优化

固定七列：**位置 / 现有选项与价格 / 处理动作与类型 / 方案方向/付费动机 / 建议 Premium 选项与价格 / 优化理由 / 具体调整方案**。

每个 `optimize` 节点输出三行，分别对应 17、12、10 币；三行使用相同 `coverage_key`，并分别写数值 `tier`。每个 `cancel` 节点输出一行，`tier` 写 `"cancel"`。

- `location`：Excel 文件、Sheet、原按钮行或单元格；移动时同时写原位置和目标位置。
- `current_option_and_price`：列全该物理组当前所有 Premium 英文按钮与价格；多项用换行分开。取消或合并时也不得省略原状态。
- `action_and_type`：`处理动作｜层级与节点类型｜PC 标签｜购买链阶段`，例如 `修改｜L1 关系变化｜{R}[L2]｜升温`；PO 写明 `PO｜服装/视觉｜打标豁免｜单点`。
- `direction_and_motivation`：固定写成 `方案：〈MC 行动〉，触发〈即时反馈〉，得到〈可见结果〉｜付费动机：满足〈具体欲望〉；玩家独享〈免费分支没有的结果／反馈／线索／资产／回收〉`。不得只写动机标签。
- `recommended_premium_option_and_price`：写本行档位与可直接判断的英文按钮。取消时写 `取消独立 Premium；并入／由〈明确节点〉承接`。
- `reason`：用“原文或当前结构 → 缺陷 → 玩家影响 → 这档为何成立 → 与相邻节点和另两档的区别”形成完整因果链。
- `plan`：固定写成 `付费正文：①…；②…；③…；收束…。免费分支：保留…，错过…。合流：共同状态…。回收：…。` 删除／合并方案还要说明必要信息由哪里承接。

## 映射到选项新增

固定六列：**位置 / 类型 / 方案方向/付费动机 / 建议 Premium 选项与价格 / 内容方案 / 新增理由**。

每个 `add` 节点输出三行，分别对应 17、12、10 币；三行使用相同 `coverage_key`，并分别写数值 `tier`。

- `location`：拟插入位置前后的 Excel 文件、Sheet、行号或单元格。
- `type`：`层级与节点类型｜PC 标签｜购买链阶段`；PO 明确写 PO。
- `direction_and_motivation`、`recommended_premium_option_and_price`、`content_plan` 使用与优化表相同的三档完整商品写法。
- `reason`：用“触发行／原文铺垫 → 尚未提供的可售结果 → 为什么此处成熟 → 为什么比同章其他未收费段落更适合 → 与相邻节点及另两档的区别”形成完整因果链。

## 写入 JSON 与强制核对

独立的 `editor-summary-options.json` 中每一行除渲染字段外，还必须携带两个内部字段：

```json
{
  "coverage_key": "existing-ch1-public-choice",
  "tier": 17
}
```

Runtime 会忽略这两个字段，Word 表格仍保持原七列和六列。它们只供覆盖检查器使用。

生成、合并和校验统一执行 [additive-output.md](additive-output.md) 的 `freeze` 与 `merge` 流程，不直接编辑最终摘要。两张表的显示字段见 [option-tables.md](option-tables.md)。

合并必须同时证明：真实基础摘要逐字段保留、同章仅有一个原标题、现有付费物理组不漏不重、优化／新增节点 17／12／10 三档齐全、取消节点仅一行、每章存在可执行项或有效的第二遍复查例外。Excel 定位继续来自 source map；内部标识不显示在 Word。
