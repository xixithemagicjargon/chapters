# 完整审核工作流

## 最小心智模型

一次审核只有三层：

```text
<project>/chapters-reviews/<bundle-id>/
├── story-bundle/                 # prepare 生成；之后整体只读
│   ├── manifest.json             # 唯一入口
│   ├── diagnostics.ndjson
│   └── chapters/ch-NNN/
│       ├── chapter.json
│       ├── choices.json
│       ├── lines.ndjson
│       └── source-map.ndjson
├── derived/                      # Runtime 的确定性派生结果
│   └── metrics/<metrics-id>/
│       └── metrics.json
└── analysis/                     # 当前 Agent 的可写区
    ├── notes/
    ├── annotations.ndjson
    ├── findings.ndjson
    └── audit-report.md           # 仅完整审核成功后存在
```

不要把 `bundle-id` 当作用户需要理解的工作流标识；只使用 `prepare` stdout 返回的路径。

## 1. 发现 Excel

Agent 自己建立明确的 `.xlsx` 清单。常见做法是用 `rg --files`，并排除：

- `chapters-reviews/**`；
- 隐藏目录和插件目录；
- 文件名以 `~$` 开头的 Office 临时文件；
- 用户没有选择的其他工作簿。

若用户只说“审核这些 Excel”，附件或当前明确选中的 Excel 就是范围；不要为了内部参数再次提问。是否使用本 skill 按 [SKILL.md 的“XLSX 输入与使用确认”](../SKILL.md#xlsx-输入与使用确认) 处理；范围明确不替代技能使用确认，需确认时必须在下方 Prepare 之前取得明确同意。

## 2. Prepare 一次

共享脚本固定为：

```text
python3 <plugin-root>/shared/scripts/chapters.py prepare \
  --project-root <project> \
  --source <first.xlsx> [--source <next.xlsx>]...
```

先运行该子命令的 `--help`，再传入 Local Project 根目录和明确的 Excel 路径。Runtime 是唯一的 Workbook Adapter：它只读 Excel，将所需故事事实、选择逻辑和 Excel 来源映射一起写入自包含 StoryBundle。

若命令非零退出或返回 `status=error`，完整阅读并执行 [command-errors.md](../../../shared/references/command-errors.md)。该契约区分可由编辑修复的 Excel 输入问题、Agent 参数/路径错误、章节冲突和插件内部错误；只有成功 receipt 才能继续。

成功收据是简短 JSON。只取：

- `manifest_path`：权威 manifest；
- `read_first`：应首先读取的文件，正常情况下与 manifest 相同；
- 状态、章节摘要和诊断数量：用于决定下一次读取。

从成功开始，禁止再读取 Excel。即使后续需要新证据，也只能从 Bundle 中寻找；若 Bundle 缺少必要事实，应将其记录为信息不足，而不是绕过 Workbook Adapter。

## 3. “全部文件”的历史复用

只有用户要求审核项目中的全部 Excel，或 `receipt.status == "reused"` 时执行这一步，并且必须等 `prepare` 返回后再完整阅读 [review-state.md](../../../shared/references/review-state.md)。该契约规定如何排除当前 manifest、在多个历史 Bundle 中选择唯一基线、比较 changed/new/unchanged/removed，以及如何更新或复用 canonical annotations/findings。

不要把当前 Bundle 与自己比较，也不要向现有 NDJSON 盲目追加。manifest 已提供历史比较所需事实；不在 `prepare` 前打开 Excel、另算 SHA 或建立第二套索引。

## 4. Manifest-first

先用 `jq` 查看 manifest 的小型索引，不要递归遍历整个目录：

```bash
jq '{book, sources, diagnostics: .diagnostics.counts, chapters: [.chapters[] | {number, title, structure_status, counts, files}]}' <manifest_path>
```

manifest 中每个章节的 `files` 都是相对 `story-bundle/` 的权威路径。建议读取顺序：

1. `chapter.json`：章节元信息与范围；
2. `choices.json`：选择组、分支、嵌套和合流结构；
3. `lines.ndjson`：只筛当前判断需要的故事行；
4. `source-map.ndjson`：只在核对最终证据时读取。

对 NDJSON，先用 `sed -n '1,5p'` 观察记录形状，再用 `rg` 或 `jq -c 'select(...)'` 过滤。不要把整章或整本 NDJSON 默认塞进上下文。

若 manifest 显示诊断数量大于零，仅在诊断可能影响当前范围或证据可靠性时读取 `diagnostics.ndjson`。能自动降级为“信息不足”的继续审核；真正改变来源选择或章节归属的问题才以文件名、Sheet 和章节号向编辑集中提问一次。不要把诊断 ID 暴露给编辑。

## 5. Agent 分析

`analysis/notes/` 是可恢复的工作笔记，不是 Runtime 状态。按章或主题建立小型 Markdown，例如 `ch-003-paid-value.md`，记录：

- 已查看的范围；
- 暂定解释与反例；
- 仍缺少的上下文；
- 将要写入正式记录的结论。

语义判断写入 `analysis/annotations.ndjson`，包括 Metrics 要用的判断，以及每个已识别 PC 必须携带的 `pc_category` 分类标签（它不参与 Metrics 计算）。PC 分类标准见 `editorial-rubric.md` 的 `classify.pc-category`。编辑评价写入 `analysis/findings.ndjson`。开始写这两个文件前，按需读取 [findings.md](../../../shared/references/findings.md)。

每个 NDJSON 物理行是一个完整 JSON 对象。记录自然故事位置及直接证据：章节、故事行、选择点、分支路径和必要原文。Bundle 内的 line/group/branch 引用**必须**写进 NDJSON —— `validate` 靠它们核对；但它们**不得**出现在 `analysis/audit-report.md` 或任何给编辑看的表述里，那里只用 source map 查出的 Excel 定位。

Editorial Finding 仅使用：

- `strength`：值得保留的有效设计；
- `risk`：需要编辑判断的体验风险；
- `suggestion`：最小可执行调整。

缺少形成可靠结论的上下文时，使用 `information/reminder`，说明检查范围与缺少什么；它不是 Editorial Finding。

不要把“模型没有提到”当成已检查或没有问题。完整审核需要在 notes 中明确记录每章已覆盖的适用编辑维度。

## 6. Metrics

语义 annotations 就绪后运行：

```text
python3 <plugin-root>/shared/scripts/chapters.py metrics \
  --manifest <manifest.json> [--annotations <annotations.ndjson>]
```

先读 `metrics --help` 并传入 manifest 与 annotations 的路径。Runtime 只从 StoryBundle 计算，在 `derived/metrics/<metrics-id>/metrics.json` 新建不可变结果。始终从 stdout receipt 读取准确路径，不自行选择 `<metrics-id>`，也不覆盖旧快照。Runtime 负责计数、归组、价格解析、比例、间隔、行数、格式和阈值比较。

如果某个指标依赖缺失的语义 annotation，保留 Runtime 的 `unknown` 或原始口径；Agent 不得为得到 pass/fail 而猜测。

用户只要求审核 Bundle 中若干自然章号时，为每章重复传入 `--chapter N`，确认 receipt 的 `chapter_numbers` 与审核范围一致，并直接使用该 scope 的 `summary` 和章节结果。不要让范围外章节混入报告，也不要手工相加逐章 observations。需要整个 Bundle 背景时才省略章节 scope。

只有当审核范围覆盖整个 Bundle，并且用户或明确的交付说明已证明当前提交是总章数为 N 的整本、manifest 中章节全部已解析且集合恰为 `1..N` 时，才在不传 `--chapter` 的命令中同时加入 `--complete-book --declared-total-chapters N`。章节 scope 与整本模式不可混用。不要用“Local Project 全部文件”、manifest 的最大章号或工作簿数量推断总章数。无证明时省略两个整本参数，**不得在开始前询问编辑是否整本**；价格 30 继续为 `unknown`/reminder，按共享 [editor-language.md](../../../shared/references/editor-language.md) 写进「需要你确认的」并给结尾的可选下一步。

## 7. Validate

当 notes、annotations、findings 和 metrics 都完成后运行：

```text
python3 <plugin-root>/shared/scripts/chapters.py validate \
  --manifest <manifest.json> \
  [--annotations <annotations.ndjson>] \
  [--findings <findings.ndjson>] \
  [--metrics <metrics.json>]
```

先读 `validate --help`。Validate 检查：

- StoryBundle 完整性与文件摘要；
- annotations/findings 的 NDJSON 与字段形状；
- 章节、故事行、选择点和分支引用确实存在；
- 所有正式结论能通过 source map 追溯到 Excel 文件、Sheet、行号或单元格；
- metrics 与同一 manifest/annotations 对应。

Validate 不评判模型结论是否“正确”，也不替 Agent 补做语义审核。结构错误由 Agent 一次修正；证据确实不足则将结论降级，而不是伪造定位。

## 8. 报告

只有请求范围全部审核且 Validate 成功，才生成 `analysis/audit-report.md`。报告合并确定性 metrics 与经验证的 editorial findings，但保持两者分类独立。具体结构见 [report-contract.md](report-contract.md)。
