# 编辑版 docx 契约

完整审核除 `analysis/audit-report.md` 之外，还要产出一份 **编辑版 docx**：`analysis/editor-summary.docx`。

## 两份文件的分工

| | `audit-report.md` | `editor-summary.docx` |
|---|---|---|
| 给谁 | 编辑自己核对、留档 | 编辑转给写手、发群里、开会用 |
| 内容 | 完整审核结果，含通过项、全书总览表、分类标签、方法说明 | **只有要改的东西** |
| 通过的项 | 要列出来（证明查过了） | **不出现** |
| 没问题的章 | 要出现（写「本次未发现需报告项」） | **整章不出现** |

docx 是 md 的**摘要**，不是另一份报告。它回答一个问题：**哪些地方要改、怎么改。**

## 只输出这五样

1. **全书大概问题点** —— 几句话说清这次一共几处要改、哪几类问题最集中、建议先动哪几处。
2. 每个**有问题的章节**，一张四列表：**检测点 / 检测内容 / 检测结果 / 建议**。
3. 该章的**建议点**（本章建议）。

其余一律不写进 docx：全书总览表、PC 分类标签、需要你确认的、这些结论是怎么得出的、插件版本、任何通过项、任何没问题的章节。

四列的写法：

- **检测点** —— 用「检测项目对照表」里的中文名，保留 PC、FC、L1、L2 这些行话。
- **检测内容** —— 一句话说清规则要求什么。抄对照表的「这项检查什么」即可。
- **检测结果** —— 先写「不通过」或「需留意」，紧跟实际值和 **Excel 行号或单元格**。例：`不通过：只有 2 个（Excel 行 137、176）`。行号让编辑能直接翻到那一行，这是整份文件最重要的信息。
- **建议** —— 具体怎么改。英文改写给英文建议稿，可整行复制。要编辑自己拿主意的写「这条要你定方向，我给不了改法」，不要编假建议。

## 怎么生成

先把内容写成 `analysis/editor-summary.json`，再交给 Runtime 渲染：

```text
python3 <plugin-root>/shared/scripts/chapters.py editor-docx \
  --summary <review>/analysis/editor-summary.json \
  --output  <review>/analysis/editor-summary.docx
```

Agent 决定**放什么进去**，Runtime 只负责把它变成一个能在 Word 里打开的文件。不要自己拼 docx，也不要引入第三方库。

JSON 形状：

```json
{
  "title": "HMQ 第 1–5 章 审核摘要",
  "overview": [
    "5 章一共 7 处要改，其中付费回报偏薄的 3 处最该先动手。",
    "第 1 章开头的免费选项只有 2 个，规则要求 3 个。"
  ],
  "chapters": [
    {
      "label": "第 1 章",
      "problems": [
        {
          "check": "FC 间隔",
          "checks_what": "第一章第一个 L1 前要有 3 个 FC",
          "result": "不通过：只有 2 个（Excel 行 137、176）",
          "advice": "在第一个付费选项前再加一个免费选项。"
        }
      ],
      "suggestions": ["第 1 章整体节奏偏快，建议把第一个付费点往后挪。"]
    }
  ]
}
```

- `title` 省略时用默认标题；`overview` 为空数组时文件里会写明「本次没有需要整体说明的问题。」
- **`problems` 和 `suggestions` 都为空的章节会被渲染器自动跳过** —— 不用自己过滤，但也别指望它能替你判断哪条该进去。
- 每个章节对象必须有 `label`，否则命令报 `docx_error`。
- 命令返回 receipt，含 `output_path`、`problem_rows`、`suggestions` 三个数，用它核对写进去的条数和你预期是否一致。

## 交付

聊天里给两个可点击链接，各一句话：

> 完整结果在 `analysis/audit-report.md`。要转给写手的话发这个：`analysis/editor-summary.docx`，里面只有要改的地方。

用词、状态念法一律以共享 [editor-language.md](../../../shared/references/editor-language.md) 为准。docx 里同样不出现规则 ID、插件内部术语、中间目录名。
