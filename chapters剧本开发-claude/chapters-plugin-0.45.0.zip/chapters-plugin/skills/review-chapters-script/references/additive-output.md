# 基础 Word 完成后的选项插入

本步骤接续 SKILL.md 第 11 步。基础审核及 Word 按 `review-workflow.md`、`report-contract.md` 和 `editor-docx.md` 完成；以下说明如何备份该 Word、准备选项内容并直接插入。

## 一、备份已经生成的基础 Word

将第 11 步生成的不含选项表的 `editor-summary.docx` 及其配套审核文件传给 `freeze`：

```text
python3 <plugin-root>/skills/review-chapters-script/scripts/editor_summary_additions.py freeze \
  --summary <review>/analysis/editor-summary.json \
  --baseline-docx <review>/analysis/editor-summary.docx \
  --report <review>/analysis/audit-report.md \
  --annotations <review>/analysis/annotations.ndjson \
  --findings <review>/analysis/findings.ndjson \
  --metrics <本次receipt指定的metrics.json> \
  --manifest <本次manifest.json> \
  --snapshot <review>/analysis/notes/editor-summary-baseline.json
```

工具核对来源引用及 JSON 与 Word 的可见内容，在快照旁保存同名 `.docx` 原件备份，并记录审核文件的校验值。日常完整审核使用本轮刚生成的 Word；快照文件名已存在时，另选新文件名。

用户指定向历史报告追加时，输入改用该报告及其配套审核文件，最终 Word 另存；配套资料不足时说明缺少哪些文件。来源 manifest 不同时传 `--source-manifest` 供工具核对同稿件身份。无自然章号的原标题用 `--bindings <json>` 绑定，如 `{"ch-020":"Still Here"}`。

## 二、独立生成选项内容

备份成功后，完整阅读 `pc-revision-plan.md`、其指定的商业化标准及 `option-tables.md`，按这些资源完成选项分析和覆盖台账。

只写独立的 `analysis/editor-summary-options.json`：

```json
{
  "chapters": [
    {
      "chapter_id": "ch-020",
      "option_optimizations": [],
      "option_additions": []
    }
  ]
}
```

此文件包含章节标识与两类选项行；每行字段见 `option-tables.md`，覆盖字段见 `pc-revision-plan.md`。覆盖台账使用 manifest 的 `chapter_id`，显示标题由工具绑定原文档，基础内容从已备份的 Word 取得。

## 三、直接插入并核对

```text
python3 <plugin-root>/skills/review-chapters-script/scripts/editor_summary_additions.py merge \
  --snapshot <review>/analysis/notes/editor-summary-baseline.json \
  --addon <review>/analysis/editor-summary-options.json \
  --coverage <review>/analysis/notes/pc-monetization-coverage.json \
  --output <review>/analysis/editor-summary-with-options.json \
  --resolved-coverage <review>/analysis/notes/pc-monetization-coverage-resolved.json \
  --docx <review>/analysis/editor-summary.docx
```

工具生成独立选项片段，并插入已备份 Word 的对应章节；组合 JSON 用作核对记录。原段落、表格、文字、样式和分节设置由工具保留。

- 同章仅有一个原标题，顺序为原检查点 → 选项优化 → 选项新增 → 原本章建议；原章顺序不变。基础摘要确实未显示的章节，有选项内容才新增一个章节标题。空表省略。
- 新增表适配原页面的可用宽度，沿用原纸张大小、方向、页边距和样式；新增内容可能使页数增加、原内容顺延。
- 写入前后均检查原审核文件未变；从最终 Word 移除本次插入片段后，原 `document.xml` 必须逐字节一致，其余压缩包部件（包括样式、页眉页脚、关系和图片）全部一致。
- 工具同时核对原字段保留、同章绑定及选项覆盖要求。检查失败时，目标 Word 和基础备份保持原样，根据工具返回的问题检查对应输入。

核对成功后，交付完整报告和插入选项后的 Word。
