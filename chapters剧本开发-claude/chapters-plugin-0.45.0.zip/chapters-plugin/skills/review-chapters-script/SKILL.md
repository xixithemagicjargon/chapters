---
name: review-chapters-script
description: Chapters .xlsx 综合审核入口，生成完整 Markdown 报告和编辑版 Word。用户指定 .xlsx 文件或含 .xlsx 的文件夹，但未指定 skill 或表述模糊时，先询问是否使用本 skill，明确同意后才审核；已点名本 skill 或已确认使用时直接执行。尊重明确指定的其他 skill 和具体任务；数量定价、英文流畅度、单项编辑评价或付费选项分析使用对应专项入口。
---

# Chapters 完整审核

把编辑指定的 Excel 作为只读来源，完成一次端到端审核，并在本次审核目录新建 Markdown 报告。永不修改、覆盖、另存或回写原工作簿。

确认使用本 skill 后，按以下三阶段执行：先完成原有审核及不含选项表的 Word，再独立生成选项方案，最后直接插入已经完成的 Word。“选项优化”和“选项新增”每次默认执行，不需要用户另行要求。

## XLSX 输入与使用确认

- 用户已点名 `review-chapters-script`（包括“Chapters 完整审核”），或已明确同意对当前范围使用本 skill 时，直接进入默认执行路径，不重复询问。用户明确指定其他 skill，或只要求数量定价、英文流畅度、单项编辑评价、付费选项分析、翻译、表格整理等具体任务时，按原请求处理，不因存在 `.xlsx` 就扩展为完整审核。
- 除上述情况外，用户指定 `.xlsx` 文件，或指定的文件夹中发现 `.xlsx`，但没有指定 skill、只说“看看/检查/分析/优化这些文件”或没有说明任务时，先询问是否使用本 skill。未点名 skill 的“完整审核这些 Excel”也先询问一次；文件范围明确不等于已选择审核技能。
- 询问前只确认文件存在并列出候选路径，不读取 Excel 内容、不运行 `prepare`、不创建审核目录、不开展评价或生成报告。文件夹只在用户指定范围内扫描，扩展名匹配不区分大小写，排除 `chapters-reviews/`、隐藏目录、Office `~$` 临时文件和插件目录；明确指定文件时不扩扫其他文件。没有合格 `.xlsx` 时说明未找到，不推荐本 skill。发现文件不等于已确认它是 Chapters 稿件。
- 对当前候选文件合并询问一次：“是否使用‘Chapters 完整审核’（review-chapters-script）技能审核这些 Excel，检查数量、定价和剧情设计，并生成完整报告及含选项优化、新增建议的 Word？”单文件用文件名替换“这些 Excel”；文件夹说明目录及候选文件数量，混合目录说明只针对其中的 `.xlsx`。不重复询问已明确的文件范围，也不夹带是否整本等额外问题。
- 等待用户明确同意后才进入默认执行路径；未回复或含糊回复不视为同意。用户拒绝时不启动本审核，按其另行说明的需求处理。确认只适用于本次选定范围。

## 默认执行路径

1. 先完成上方“XLSX 输入与使用确认”，再完整阅读 [review-workflow.md](references/review-workflow.md)。开始语义评价前按需读取 `../../shared/rules/editorial-rubric.md`；暂不读取报告模板。
2. 用 Agent 自带的文件或 Bash 工具扫描编辑指定范围内的 `.xlsx`。排除 `chapters-reviews/`、隐藏目录、Office `~$` 临时文件和插件目录。用户已指定文件时只使用这些文件，不再确认范围。
3. 解析本 skill 文件的位置以取得 `<plugin-root>`。查看 `python3 <plugin-root>/shared/scripts/chapters.py prepare --help`，然后调用 `prepare --project-root <project> --source <xlsx>`；每个 Excel 重复一次 `--source`。Agent 不解析 Excel，也不写临时解析脚本。若命令非零退出或返回 `status=error`，完整阅读并执行共享 [command-errors.md](../../shared/references/command-errors.md)；只有成功 receipt 才继续。
4. 从 stdout JSON 读取 `manifest_path` 或 `read_first`，并首先只读该 `story-bundle/manifest.json`。不要猜测审核目录、遍历 Bundle 猜结构，或要求编辑处理路径、哈希和内部标识。
5. 用户要求“全部文件”或 receipt 为 `reused` 时，完整阅读 [review-state.md](../../shared/references/review-state.md)，按其中的基线选择、changed/new/unchanged/removed 和 canonical analysis 更新规则处理。完整报告必须由本次已验证产物重新生成；不要复用旧报告，也不要向旧 NDJSON 盲目追加。
6. 按 manifest 渐进读取：先章节 `chapter.json` 和 `choices.json`，再从相关 `lines.ndjson` 读取足够的正文；只有核验证据时才读 `source-map.ndjson`。使用 `read`、`rg`、`jq`、`sed`，不要一次加载全部中间结果。
7. 将推理过程写在同级 `analysis/notes/`。将语义标签逐行写入 `analysis/annotations.ndjson`，既包括影响确定性计算的 `is_customization`、`intimacy_level`、`major_plot_turn`，也包括不参与计算但每个 PC 都必须携带的 `pc_category` 分类标签；将优点、风险和建议逐行写入 `analysis/findings.ndjson`。所有记录遵循共享 [findings.md](../../shared/references/findings.md)，携带当前 Editorial Rubric 的 `rubric_version`，并使用自然故事位置。
8. 查看 `python3 <plugin-root>/shared/scripts/chapters.py metrics --help`，再调用 `metrics --manifest <manifest>`，需要时传 `--annotations <ndjson>`。用户要求的审核范围只是 Bundle 中若干自然章号时，为每章重复传 `--chapter N`，直接使用 scoped `summary`；不得让范围外章节混入报告，也不得手工汇总逐章结果。只有审核范围覆盖整个 Bundle，且用户或明确的交付说明已证明当前提交是总章数为 N 的整本、manifest 章节全部已解析且集合恰为 `1..N` 时，才在不传 `--chapter` 的情况下同时传入 `--complete-book --declared-total-chapters N`；章节 scope 与整本模式不可混用。“Local Project 全部文件”只能证明扫描范围，不能证明已是整本；无证明时省略两个整本参数，**不得在开始前询问编辑是否整本**，价格 30 保持 `unknown`，按 `editor-language.md` 写进「需要你确认的」并给结尾的可选下一步。Runtime 只从 StoryBundle 与 annotations 计算；从 stdout receipt 读取本次不可变 `metrics.json` 的准确路径并确认 `chapter_numbers` 与审核范围一致，不要猜测或覆盖历史结果。Agent 不手算或改写确定性结果。
9. 覆盖用户要求的全部章节和适用编辑维度后，查看并调用 `validate --manifest <manifest>`，并传入本次 annotations、findings 和 Metrics 路径。根据它一次返回的全部结构或引用错误修正 analysis 文件，再次验证。不要回看 Excel。
10. 验证成功后才读取 [report-contract.md](references/report-contract.md)、[audit-report-template.md](assets/audit-report-template.md) 和共享 [editor-language.md](../../shared/references/editor-language.md)。**报告主体写在 `analysis/audit-report.md` 文件里**，按 report-contract 的必需结构组织（这次看了什么 → 全书总览表 → 全书与跨章 → 逐章详情 → 总体建议 → 需要你确认的 → 这些结论是怎么得出的）。聊天里只给一句话结论加上文件链接，不把报告正文复制进聊天。部分审核只在聊天中说明进度，不生成伪完整报告。
11. 报告写完后，完整阅读 [editor-docx.md](references/editor-docx.md)，把其中的摘要内容写成 `analysis/editor-summary.json`，再调用 `editor-docx --summary <json> --output <review>/analysis/editor-summary.docx` 生成**编辑版 docx**。它是报告的摘要，只含全书大概问题点、每个有问题章节的「检测点 / 检测内容 / 检测结果 / 建议」四列表、以及该章建议点；通过项、没问题的章节、全书总览表、分类标签、方法说明一律不进这份文件。用返回 receipt 的 `problem_rows` 和 `suggestions` 核对条数。此时的 Word 不含选项表，完成以下附加步骤后统一交付。

12. 完整阅读 [additive-output.md](references/additive-output.md)，使用其中的 `freeze` 工具备份第 11 步已完成的 Word 及审核记录；随后读取该文档指定的选项方案资源，独立生成选项数据。
13. 使用该文档的 `merge` 工具，将选项标题和表格直接插入已完成 Word 的对应章节，并核对工具返回的原内容与页面设置保留结果。同章排列为一个原标题下的“检查点四列表 → 选项优化 → 选项新增 → 本章建议”。完成后在聊天里给完整报告和最终 Word 两个链接，各一句话。

## 固定边界

- `prepare` 是唯一接触 Excel 内容的操作。成功后，`story-bundle/` 是本次审核唯一事实来源且整体只读；`metrics`、`validate` 和 Agent 都不得再读取 Excel。
- 共享脚本只负责解析、确定性计算和必要结构验证，不做模型语义判断。当前 Agent 直接浏览 Bundle、做判断并写 analysis。
- 不调用其他 Skill；各 Skill 只是不同用户意图的入口，共享同一 Runtime 和数据契约。
- 任一 CLI 命令非零退出或返回顶层 `status=error` 时读取 `command-errors.md`，先恢复或停止再继续；不得假定只有 `prepare` 会失败。
- 按规则数出来的结果与需要人判断的结果分开呈现。编辑判断只使用值得保留、有风险、建议这样改；证据不足写成「无法判断，需要你确认」并紧跟一句缺什么，不冒充符合/不符合规则。
- Excel 定位必须可追溯。Agent 先记录章节、故事行、选择点和 `branch_path`；文件、Sheet、行号与单元格通过 source map 和 `validate` 核对，不能凭记忆填写。
- 不生成总分、星级、综合通过率或单一“整书合格”结论。
- 只做审核和编辑评判，不扩展为整书续写、通用润色、市场预测或直接改稿。

面向编辑的用词、状态念法、清单行形状和版本呈现一律以共享 [editor-language.md](../../shared/references/editor-language.md) 为准：和编辑交流用中文，引用稿件保留精确英文原文不翻译，可直接采用的按钮或台词建议用英文并标为建议稿，**插件的中间目录和文件名一律不出现在报告和聊天里**。

## 按需资源

- [additive-output.md](references/additive-output.md)：基础 Word 完成后的备份、独立选项分析、原文档插入及保留校验。

- [review-workflow.md](references/review-workflow.md)：StoryBundle 布局、渐进读取、analysis 产物和端到端顺序。
- `../../shared/references/command-errors.md`：任一 CLI 命令失败时读取并恢复。
- `../../shared/references/review-state.md`：仅在“全部文件”或 receipt 为 `reused` 时读取。
- `../../shared/rules/metrics-config.json`：需要解释 Metrics、价格或机械阈值时读取。
- `../../shared/rules/editorial-rubric.md`：开始语义评价前读取。
- `../../shared/references/story-bundle.md` 与 `../../shared/references/findings.md`：需要确认 Bundle 或 analysis 字段时读取。
- [report-contract.md](references/report-contract.md) 与 [audit-report-template.md](assets/audit-report-template.md)：仅在全范围 Validate 成功后读取。
- `references/editor-docx.md`：生成编辑版 docx 前读取。
- `../../shared/references/editor-language.md`：生成任何面向编辑的输出或报错说明前读取。
