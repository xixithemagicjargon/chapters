# Excel 解析与 StoryBundle 取数规则

本文件把原 Skill 的 Excel 解析意图接到当前项目的唯一解析入口。这里不定义第二套表头、列号、归组或计数算法。

## 唯一解析入口

- `python3 <plugin-root>/shared/scripts/chapters.py prepare ...` 是唯一允许读取 `.xlsx` 的操作。
- Agent 不直接解析 Excel，不运行旧版 `interactive_novel_excel_parser.mjs`，也不按固定 A／D／E 列猜字段。
- `prepare` 成功发布 manifest 后，Excel 不再打开。后续事实只从同一个 StoryBundle 与其 Metrics 快照取得。
- 若命令失败或返回 `status=error`，按共享 `command-errors.md` 恢复；不得跳过失败继续做内容判断。

## 正文与列映射

- manifest 中列出的章节才是本次可分析正文；被排除或无法识别的工作表从 diagnostics 取得。
- 每章真实 Sheet、表头行和技术列映射从 `chapter.json` 取得，不复制旧版默认行列规则。
- manifest/diagnostics 已经表达 `workbook.unrecognized-sheet`、隐藏正文 Sheet、推断列等情况。结构异常进入技术核验，不在作者重构正文中混排。

## 选项与分支

- `choices.json` 是物理组选项、嵌套深度、父分支、Button、分支内容、合流、Premium/VIP 信号和价格词法结果的唯一结构来源。
- 付费与免费以 StoryBundle/Runtime 对每个分支解析出的商业信号为准；不得仅因 Dialogue Type 含 `Premium` 就覆盖价格单元格的事实。
- `depth=1` 只表示根组；更深 depth 表示结构嵌套。是否属于 v1.7 的一级或二级逻辑 PC，还要结合前序购买依赖判断。
- 结构状态为 `uncertain` 或 diagnostics 指向组选项时保留原始 group/branch/line ID，在面向编辑的报告中换成经 source map 核对的 Excel 位置，并将逻辑结论标为静态暂评。

## 正文与分支边界

- `lines.ndjson` 提供故事顺序、文本字段和完整 `branch_path`；`seq` 不是 Excel 行号。
- 选择前共享铺垫以 group 的 `preceding_line_id`、Button 位置和实际 branch_path 划界；各分支正文以 branch 的 `content_line_ids`、子组和 `merge_line_id` 为准。
- Callback 条件与 `End callback` 是舞台指示，不当作读者连续看到的正文；同一 Callback 区域的变体互斥。
- 只有准备发布证据时才读取 `source-map.ndjson`，把 line/group/branch 映射到文件、Sheet、Excel 行号或单元格。

## 三种商业统计单位

- **物理选项组**：直接取 StoryBundle 的 group。
- **逻辑付费点**：由 v1.7 判断多个物理组是否共享同一权益；必须保留全部物理证据与静态推断依据。
- **路径曝光**：需要 Paywall ID、变量或运行时路径数据。仅凭静态稿不能给最终数字。

三者不得互换。没有运行时数据时，把逻辑 PC 和路径曝光写为“静态暂评”或“待验证”。

## 数字来源

- 组选项、分支、价格、行数和 Runtime 已提供的其他确定性数字取自同一次 StoryBundle/Metrics。
- 使用 Metrics 的 observations/raw/unknown；不要把当前共享 hard check 的 pass/fail 当成 v1.7 专业判断。
- v1.7 的拟议一级/二级 PC、PO、17／12／10 选项数与内容组合是方案值，必须与现状事实分栏，不得写回 Metrics。

