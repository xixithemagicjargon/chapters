---
name: check-english-fluency
description: 单独检查 Chapters 稿件里英文读起来是否地道：翻译腔、语域不对、句式生硬、对白节奏不自然、术语前后不一致。用户说「看看英文顺不顺」「有没有翻译腔」「英文读着别扭」「帮我过一遍英文表达」时使用，即使范围是全部文件或全部章节；不用于数量定价等确定性指标、付费设计评价，也不生成完整审核报告。
---

# Chapters 英文流畅度检查

只做一件事：把稿件里读起来不像英文母语写出来的行挑出来，逐行给出 Excel 行号、原文和英文改写建议稿。不数任何指标，不评价付费设计，不生成完整审核报告，永不回写 Excel。

这项检查是**建议性的**：它产出的每一条都是建议，不判合格与不合格。

## 执行路径

1. 完整阅读共享 [editor-language.md](../../shared/references/editor-language.md)，再从 `../../shared/rules/editorial-rubric.md` 读取开头的 Result contract、末尾的 Boundaries，以及 `editorial.language-fluency` 这一节。**不要加载整份 Rubric** —— 其余规则和这次任务无关。
2. 用 Agent 自带的文件或 Bash 工具建立明确的 `.xlsx` 清单，排除 `chapters-reviews/`、隐藏目录、Office `~$` 临时文件和插件目录。用户已指定文件或章节时不要再次确认。
3. 解析本 skill 文件的位置以取得 `<plugin-root>`。查看 `python3 <plugin-root>/shared/scripts/chapters.py prepare --help`，再调用 `prepare --project-root <project> --source <xlsx>`；每个 Excel 重复一次 `--source`。Agent 不解析 Excel。若命令非零退出或返回 `status=error`，完整阅读并执行共享 [command-errors.md](../../shared/references/command-errors.md)；只有成功 receipt 才继续。
4. 从 receipt 给出的 `manifest.json` 开始。按用户指定的章节读 `lines.ndjson`；未指定时覆盖 manifest 里的全部章节。**这项检查不需要 `choices.json`、不需要 Metrics、不需要任何语义标注** —— 它只看正文文本。
5. 逐章判断，把结论逐行写入同级 `analysis/findings.ndjson`，`rule_id` 一律是 `editorial.language-fluency`，每条携带当前 Editorial Rubric 的 `rubric_version`。形状以共享 [findings.md](../../shared/references/findings.md) 为准。
6. 只在形成正式证据时读该章 `source-map.ndjson` 取 Excel 行号。查看并调用 `validate --manifest <manifest> --findings <ndjson>`，按它一次返回的全部错误修正记录，不要回看 Excel。
7. 按下面的输出形态在聊天里回答。**不创建 `analysis/audit-report.md`** —— 那是完整审核入口的产物。

## 跳过什么

这些**不看**，看了就是浪费时间和误报：

- `special_type` 为 `Callback` 的行（条件行和 `End callback`）——读者看不到的舞台指示。
- `INSERT OUTFIT CHOICE`、`INSERT OBJECT CHOICE` 这类标记行。
- PO 组的按钮 —— 任何按钮文案规则都不评价它们。
- 元数据行（Title、Blurb）。
- 角色故意的语言特征：方言、俚语、口头禅、破碎英语、时代腔调。报之前先和这个角色的其他台词对照。
- 英美拼写偏好，除非一章之内自己不一致（那属于术语不一致）。

## 输出形态

一段话结论 + 一张表，逐章分组。表格形状：

| 位置（Excel 文件名 · Sheet · 行号或单元格） | 英文原文 | 问题类别 | 修改建议（英文） |
|---|---|---|---|

- 第一句给出总数：「第 1–3 章一共 14 行读着有翻译腔，我按章列在下面。」不要用「已完成检查，详见下文」开头。
- 问题类别取自五类：翻译腔、语域不对、句式生硬、对白节奏不自然、术语不一致。
- **报模式，不报逐条**：同一个毛病反复出现时，说清是哪一类，每类最多引三个最有代表性的实例，不要把每一处个人偏好都列成一行。
- 修改建议给可直接整行复制的英文；需要编辑自己拿主意的写「这条要你定方向，我给不了改法」，不要编一句假建议。
- 行号一律取 source map 的 `excel_row`，**不要用 `lines.ndjson` 的 `seq`** —— 两者相差表头行数。
- 每章末尾写出该章存在问题的行数合计；某章没有需要修改的行时写明「这一章没有需要改的行」，不要留空。
- 用词、状态念法以 `editor-language.md` 为准。插件的中间目录和文件名不出现在答复里。

## 固定边界

- **不判断翻译准不准。** Bundle 里只有一列正文、没有源语言文本，所以任何「和原意有偏差」的说法都是凭空猜测。不许声称某句偏离了原文，也不许推测原文说了什么。
- 只管英文读起来地不地道。剧情优劣、文笔野心、市场潜力、付费设计一律不在范围内。
- 不数 PC、FC、PO、价格、行数、间隔 —— 那是 `check-chapters-metrics` 的事。
- 不评价付费点值不值、回报有没有兑现 —— 那是 `evaluate-chapters-script` 的事。
- 不生成完整审核报告 —— 那是 `review-chapters-script` 的事。
- 不调用其他 skill。`prepare` 是唯一接触 Excel 的操作，且只读。

## 参考

- `../../shared/rules/editorial-rubric.md` 的 `editorial.language-fluency`：五类问题的判据与排除项，唯一权威。
- `../../shared/references/editor-language.md`：给编辑看的字。
- `../../shared/references/findings.md`：写 findings 前读取。
- `../../shared/references/command-errors.md`：`prepare` 报错时读取。
