# 编辑评价用户契约

面向编辑的一切用词、状态念法、清单形状和版本呈现，以共享 [editor-language.md](../../../shared/references/editor-language.md) 为准；本文件下面的小节标题和内部术语是给 Agent 看的，不要照搬到答复里。

## 允许评价的范围

仅在当前 `editorial-rubric.md` 有定义时评价，例如：

- 付费节点是否落在有意义的剧情、情绪、关系或亲密节点；
- L2 是否是 L1 的升级延伸，并提供与 L1 强关联的额外价值；
- 按钮或付费承诺是否在分支中兑现，且至少有明确的即时反馈；
- 分支顺序、合流和后续人物状态是否连贯；
- PO 前是否存在清楚的场景理由；
- 按钮是否体现 MC 主动意图、关系里程碑和所承诺的具体体验；
- Rubric 定义的前情回顾、激发事件、章末钩子或其他叙事判断；
- 每个已识别 PC 卖的是哪一类价值，并按 `classify.pc-category` 打上分类标签。

Rubric 没有定义的一般文笔优劣、市场潜力、读者转化率或整书创作建议不在范围内。

## Rubric 路由

先从用户问题确定一个或多个适用规则，再用标题搜索只读 `editorial-rubric.md` 的 Result contract、Boundaries 和对应规则小节：

| 用户关注 | 读取规则 |
|---|---|
| 前情回顾是否准确 | `structure.recap-consistency` |
| 激发事件及其位置/因果 | `structure.inciting-event` |
| 章节末尾有没有钩子、钩子够不够 | `structure.chapter-hook` |
| 付费节点价值、价格 30 是否重大转折 | `editorial.paid-node-fit` |
| 按钮主动性、承诺和 MC 声音 | `editorial.button-intent` |
| 按钮标点、大小写和强调是否符合语气 | `editorial.button-tone` |
| 游戏黑话或网络用语 | `editorial.button-immersive-language` |
| 关系建立前过早示爱 | `editorial.button-premature-love` |
| 分支合流后的事实与人物状态 | `editorial.branch-merge-consistency` |
| 负面结果中的旁白审判 | `editorial.negative-result-narration` |
| L2 是否升级 L1、是否重复收费 | `editorial.l2-upgrade-value` |
| 付费承诺、即时回报和三个 payoff beats | `editorial.premium-payoff` |
| PO 前是否有换装场景理由 | `editorial.po-scene-reason` |
| PC 属于哪一类（亲密 / 个性塑造 / 信息解锁 / 能力提升） | `classify.pc-category` |
| 指标需要排除捏脸流程 | `classify.customization-flow` |
| 换装选择没被标记短语识别到 | `classify.outfit-choice` |
| 指标需要判断亲密等级 | `classify.intimacy-level` |

用户同时询问几个紧密相关维度时读取对应几个小节；不要因为其中一个按钮问题而加载所有 Editorial 规则。用户要求综合审核时改用完整审核入口。

## 单向数据流

```text
Excel --prepare--> story-bundle/ --Agent reads--> analysis/
                                      |
                                      +--optional metrics--> derived/metrics/<metrics-id>/
                                      \--validate---------> verified references
```

每次 `prepare` 尝试中，Excel 只由 Workbook Adapter 从当次源快照读取和解析一次。成功后，评价所需的正文、选择逻辑和来源映射都必须来自自包含 StoryBundle；不得以“上下文不够”为由重新打开 Excel。冲突处理后重跑 `prepare` 属于新的尝试。

## 渐进读取顺序

1. 只读 `manifest.json`，找到用户指定章节和对应文件路径。
2. 读 `chapter.json` 确认章节元信息；章级 `structure_status` 从 manifest 的章节索引取得，不在 `chapter.json` 中猜测。
3. 读 `choices.json` 找到目标选择组、分支、嵌套关系和合流点，并查看该文件的章级及选择组 `structure_status`。
4. 从 `lines.ndjson` 过滤按钮行、分支正文、前置铺垫和合流后的最小充分上下文。
5. 只有形成正式证据时，才读相关 `source-map.ndjson`。

通常不需要读完整一章。判断跨章连续性时，可以按 manifest 追加相邻章，但不要因此加载全书。

如果 manifest 的诊断可能影响目标选择结构或正文完整性，按诊断指向读取；否则不要展开无关诊断。上下文确实缺失时使用 `information/reminder` 并说明缺什么。

## Notes、Annotations 与 Findings

`analysis/notes/` 保存当前 Agent 的工作分析。按章节或问题拆成小文件，并记录：

- 用户要求和实际检查范围；
- 已读取的选择点与故事区段；
- 支持判断的证据与反例；
- 仍缺少的上下文；
- 对当前适用 Rubric 维度的覆盖。

会被 Metrics 使用的语义标签写入 `analysis/annotations.ndjson`。正式编辑判断写入 `analysis/findings.ndjson`。精确字段以 [findings.md](../../../shared/references/findings.md) 为准；每个物理行必须是一个完整 JSON 对象。

每条 Finding 至少表达：

- Rubric 维度；
- `strength`、`risk`、`suggestion`，或表示证据不足的 `information/reminder`；
- 清楚、可复核的中文判断；
- 对玩家承诺、人物状态或分支体验的具体影响；
- 章节、故事行、选择点或 `branch_path` 形式的直接证据引用；
- 如适用，最小可执行的英文建议稿。

不要把文件路径、Sheet、行号或单元格凭记忆抄进记录；让 source map 与 `validate` 核对。`seq` 不是 Excel 行号，行号只取 source map 的 `excel_row`。

面向编辑的回答**只给 Excel 定位**：路径、Sheet、行号或单元格、英文原文。`line_id`、`group_id`、`branch_id`、`branch_path`、`scope_ref` 只留在 `analysis/` 的 NDJSON 里供 `validate` 核对，不要写进给编辑看的答复。

## 分类

- **strength**：设计有效且值得保留；
- **risk**：可能削弱体验，需要编辑判断；
- **suggestion**：针对已说明问题的最小可执行调整；
- **information/reminder**：当前 Bundle 不足以形成可靠结论；它不是 Editorial Finding。

确定性 Metrics 只能作为证据背景，不能改变 Editorial 分类。没有发现命中时，按 `editor-language.md` 的两句话规则明确写出「这一项查过了，没问题」，并说清查了哪些章节和哪些方面；不要留空，也不要把模型沉默当作确定性证明。

## 使用 Metrics

需要价格、分支数量或间隔作为背景时才运行 `metrics`。始终读取 stdout receipt 指向的 `derived/metrics/<metrics-id>/metrics.json`，并注明使用的口径。Editorial Finding 不得复制、重算或覆盖 Runtime 的数值。

评价只覆盖若干自然章号时，为每章重复传入 `--chapter N` 并直接读取 scoped `summary`；需要全书背景时使用不带 scope 的 Metrics。章节 scope 与整本参数不可混用，也不得手工相加逐章 observations。

只有用户或明确的交付说明已证明当前提交是总章数为 N 的整本，且 manifest 中的章节全部已解析为自然章号、集合恰为 `1..N` 时，才同时传入 `--complete-book --declared-total-chapters N`。“Local Project 全部文件”本身不是整本证明。无证明时省略两个参数，**不得在开始前询问编辑是否整本**；若出现价格 30，保持 `unknown`，在答复的「需要你确认的」一段里写出这一条并紧跟一句缺什么，再按 `editor-language.md` 的结尾可选下一步收尾。

## Validate 与回答

回答用普通人读得懂的中文：状态说「通过 / 不通过 / 无法判断 / 仅供参考」，不说 `pass`/`fail`/`unknown`；检测项目用 [检测项目对照表](../../review-chapters-script/references/report-contract.md) 里的名字，保留 PC、FC、PO、L1、L2 这些编辑行话，不出现规则 ID；每个问题都给 Excel 行号，让编辑能直接翻到那一行。用词以共享 [editor-language.md](../../../shared/references/editor-language.md) 为准。

专项评价只在聊天里回答，不创建 `analysis/audit-report.md`。Validate 成功后按以下四段固定顺序：

1. **一句话结论** —— 直接给出判断，不铺垫。例：「第 3 章那个 30 币的付费点我认为有风险——它承诺的内容在分支里没兑现。」不允许用「已完成评价，详见下文」这类空话开头。编辑一次问了多处时，第一句要给出「有几处要改」这个数。
2. **待改清单** —— 每条按 `editor-language.md` 的清单行形状给出：位置（Excel 文件名 · Sheet · 行号或单元格）、问题、怎么改。问题那一行要说清对玩家承诺、角色状态或分支体验的实际影响，**不要复述规则条文**。怎么改那一行给可直接采用的英文建议稿；需要编辑自己拿主意的写「这条要你定方向，我给不了改法」，不要编一句假建议。按优先级排序，风险和建议在前，值得保留的放在清单之后。
3. **需要你确认的** —— 上下文不足而无法下结论的项，每条紧跟一句缺什么；如有「不确定是否整本」导致的项，在这一段之后给结尾的可选下一步。
4. **值得保留** —— 设计有效、编辑不必动手改的地方，简短列出即可。

同一条判断有多处证据时可以在那一段里列多个位置，但不要为此改成表格。不给总分、综合通过率或「整章合格/不合格」，也不给每条标严重程度。

引用稿件保留英文原文，不翻译；和编辑交流一律用中文。插件的中间目录和文件名一律不出现在答复里。
