---
name: evaluate-chapters-script
description: 对 Chapters 稿件按当前共享规则做专项编辑评价，包括 L2 价值、回报兑现、分支合流、按钮意图/语气、PO 场景理由、前情回顾、激发事件、过早示爱和负面旁白。用户询问单项设计“值不值”“合理吗”“怎么改”时使用；明确要求付费选项分析、付费选项优化或付费结构解析时不使用。
---

# Chapters 编辑评价

依据现有 Editorial Rubric，对指定章节或选择点给出有证据的编辑判断。默认直接在聊天中回答，不生成完整审核报告，也不回写 Excel。

## 执行路径

1. 完整阅读 [evaluation-user-contract.md](references/evaluation-user-contract.md)，先按其中的规则路由确定适用 `rule_id`。从 `../../shared/rules/editorial-rubric.md` 读取开头 Result contract、末尾 Boundaries 和这些规则对应的小节；不要默认加载整份 Rubric。
2. 用 Agent 自带的文件或 Bash 工具建立明确的 `.xlsx` 清单，排除 `chapters-reviews/`、隐藏目录、Office `~$` 临时文件和插件目录。用户已指定文件、章节或选择点时不要再次确认。
3. 解析本 skill 文件的位置以取得 `<plugin-root>`。查看 `python3 <plugin-root>/shared/scripts/chapters.py prepare --help`，再调用 `prepare --project-root <project> --source <xlsx>`；每个 Excel 重复一次 `--source`。Agent 不解析 Excel。若命令非零退出或返回 `status=error`，完整阅读并执行共享 [command-errors.md](../../shared/references/command-errors.md)；只有成功 receipt 才继续。
4. 从 stdout JSON 读取 `manifest_path` 或 `read_first`，首先只读该 `story-bundle/manifest.json`。定位用户指定章节后，先读 `chapter.json` 和 `choices.json`，再从 `lines.ndjson` 筛选判断所需上下文；不要读取无关章节或一次加载整个 Bundle。
5. 用户要求“全部文件”或 receipt 为 `reused` 时，完整阅读 [review-state.md](../../shared/references/review-state.md)。只复用能针对当前 Bundle 验证并覆盖本次规则/范围的记录；需要修改时按活动范围重建 canonical annotations/findings，不向旧 NDJSON 盲目追加。
6. 在同级 `analysis/notes/` 记录已检查范围、候选判断、反例和上下文缺口。按共享 [findings.md](../../shared/references/findings.md) 将适用的语义标签逐行写入 `analysis/annotations.ndjson`，将正式优点、风险和建议逐行写入 `analysis/findings.ndjson`；每条记录携带当前 Editorial Rubric 的 `rubric_version`。
7. 若评价需要分支数、价格或间隔作为事实背景，查看并调用同一脚本的 `metrics --manifest <manifest>`，需要时传 annotations。评价限定若干自然章号时，为每章重复传 `--chapter N` 并使用 scoped `summary`；需要全书背景时运行不带 scope 的 Metrics。只有当用户或明确的交付说明已证明当前提交是总章数为 N 的整本，且 manifest 中的章节全部已解析为自然章号、集合恰为 `1..N` 时，才在不传 `--chapter` 的情况下同时传入 `--complete-book --declared-total-chapters N`；章节 scope 与整本模式不可混用。“Local Project 全部文件”本身不是整本证明；无证明时省略两个整本参数，**不得在开始前询问编辑是否整本**，价格 30 保持 `unknown`，按 `editor-language.md` 写进「需要你确认的」并给结尾的可选下一步。再从 stdout receipt 指向的不可变 Metrics 快照读取所需值。不要手算，也不要把 Metrics 状态写成 Editorial 判断。
8. 只在准备最终证据时读取相关 `source-map.ndjson`。查看并调用 `validate --manifest <manifest>`，并传入本次 annotations、findings 和可选 Metrics 路径。确认结构、故事引用、Excel 追溯及 Metrics 绑定；根据一次返回的全部错误修正 analysis 文件，不回看 Excel。
9. 验证成功后回复前，完整阅读共享 [editor-language.md](../../shared/references/editor-language.md)，按其中的四段顺序、状态念法和清单行形状输出：先一句话结论，再待改清单（位置 / 问题 / 怎么改），然后是需要编辑确认的，最后才是值得保留的；专项评价不创建 `analysis/audit-report.md`。

## 固定边界

- `prepare` 是唯一接触 Excel 内容的操作。成功后，`story-bundle/` 是唯一事实来源且整体只读。
- Runtime 只解析、计算 Metrics 和验证结构，不提出或裁定编辑判断。当前 Agent 直接用 `read`、`rg`、`jq`、`sed` 浏览 Bundle 并写 analysis。
- 正式编辑判断只使用 `strength`、`risk` 或 `suggestion`；证据不足写为 `information/reminder`，不用硬性的通过/不通过语言。
- Agent 使用章节、故事行、选择点和 `branch_path` 记录证据。面向编辑的最终引用必须经 source map/Validate 转为 Excel 相对路径、Sheet、行号或单元格及英文原文。
- 没有足够上下文时明确降级，不补写不存在的情节，也不把“没有提到”说成“没有问题”。
- 不调用其他 skill。用户明确要求付费选项分析、付费选项优化或付费结构解析时，改用 `interactive-fiction-monetization-review`；不扩展为整书改写、一般文笔顾问、数量审计或商业转化率预测。
- 任一 CLI 命令非零退出或返回顶层 `status=error` 时读取 `command-errors.md`，先恢复或停止再继续；不得把 Metrics/Validate 错误归咎于 Excel。

面向编辑的用词、状态念法、清单行形状和版本呈现一律以共享 [editor-language.md](../../shared/references/editor-language.md) 为准：和编辑交流用中文，引用稿件保留英文原文不翻译，具体按钮或台词改写用英文并说明是建议稿，**插件的中间目录和文件名一律不出现在答复里**。

## 按需资源

- [evaluation-user-contract.md](references/evaluation-user-contract.md)：允许评价的范围、渐进读取、Finding 和回答要求。
- `../../shared/references/editor-language.md`：生成任何面向编辑的答复或报错说明前读取。
- `../../shared/references/command-errors.md`：任一 CLI 命令失败时读取并恢复。
- `../../shared/references/review-state.md`：仅在“全部文件”或 receipt 为 `reused` 时读取。
- `../../shared/rules/editorial-rubric.md`：评价标准。
- `../../shared/references/findings.md`：写 annotations/findings 前读取。
- `../../shared/rules/metrics-config.json`：只有确需 Metrics 事实时读取。
