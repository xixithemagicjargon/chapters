---
name: check-chapters-metrics
description: 回答 Chapters .xlsx 中 PC、FC、PO、L1、L2、VIP、捏脸、分支、价格、比例、间隔、行数和机械格式规则等确定性问题。只要问题限定于数量、定价或规格，即使范围是全部文件/章节也使用本 skill；不用于完整 Markdown 报告或付费价值、声音、剧情回报等编辑评价。
---

# Chapters 指标检查

对编辑提出的指标问题给出可追溯答案。默认直接在聊天中回答，不生成完整审核报告，也不修改原 Excel。

## 执行路径

1. 完整阅读 [metrics-user-contract.md](references/metrics-user-contract.md)。
2. 用 Agent 自带的文件或 Bash 工具建立明确的 `.xlsx` 清单。排除 `chapters-reviews/`、隐藏目录、Office `~$` 临时文件和插件目录。用户已指定文件时只使用这些文件。
3. 解析本 skill 文件的位置以取得 `<plugin-root>`。查看 `python3 <plugin-root>/shared/scripts/chapters.py prepare --help`，然后调用 `prepare --project-root <project> --source <xlsx>`；每个 Excel 重复一次 `--source`。Agent 不解析 Excel。若命令非零退出或返回 `status=error`，完整阅读并执行共享 [command-errors.md](../../shared/references/command-errors.md)；只有成功 receipt 才继续。
4. 从 stdout JSON 读取 `manifest_path` 或 `read_first`，首先只读该 `story-bundle/manifest.json`。根据用户问题读取相关章节的 `chapter.json`、`choices.json`，必要时再筛选 `lines.ndjson`；不要一次加载整本 Bundle。
5. 用户要求“全部文件”或 receipt 为 `reused` 时，完整阅读 [review-state.md](../../shared/references/review-state.md)。优先复用通过当前 Bundle/annotations 验证且完整覆盖问题的 Metrics；缺少所需快照时重算。需要写 annotations 时按 canonical 更新规则替换活动范围，绝不向旧 NDJSON 盲目追加。
6. 若所问指标依赖真正的语义分类，先读取共享 [findings.md](../../shared/references/findings.md) 的 Annotation 契约，并按需读取 `../../shared/rules/editorial-rubric.md` 顶部版本及定义该 annotation 的小节：`is_customization` 读 `classify.customization-flow`，`intimacy_level` 读 `classify.intimacy-level`，`is_outfit_choice` 读 `classify.outfit-choice`，价格 30 的 `major_plot_turn` 读 `editorial.paid-node-fit` 中对应段落。再只读 manifest/choices 指向的候选上下文。把必要判断逐行写入同级 `analysis/annotations.ndjson`，每条记录携带当前 `rubric_version`；理由写入 `analysis/notes/`。不要为了得到最终数值而假设没有捏脸、亲密内容或重大转折。
7. 查看 `python3 <plugin-root>/shared/scripts/chapters.py metrics --help` 并调用 `metrics --manifest <manifest>`，需要时传 `--annotations <ndjson>`。用户只问若干自然章号时，为每章重复传 `--chapter N`，直接读取该 scope 的 `summary`，不得自行汇总逐章结果。只有当用户或明确的交付说明已证明当前提交是总章数为 N 的整本，且 manifest 中的章节全部已解析为自然章号、集合恰为 `1..N` 时，才在不传 `--chapter` 的情况下同时传入 `--complete-book --declared-total-chapters N`；章节 scope 与整本模式不可混用。“Local Project 全部文件”只能证明扫描范围，不能证明已是整本；无证明时省略两个整本参数，**不得在开始前询问编辑是否整本**，价格 30 保持 `unknown`，按 `editor-language.md` 写进「需要你确认的」并给结尾的可选下一步。始终从 stdout receipt 取得本次 `metrics.json` 的准确路径，并确认 receipt 的 `chapter_numbers` 与问题范围一致；不要猜测 `<metrics-id>` 或覆盖历史结果。
8. 查看并调用 `validate --manifest <manifest> --metrics <metrics.json>`，需要时同时传 annotations，确认 Metrics 与同一 Bundle/annotations 对应。验证失败时修正 analysis 记录或重新运行 Metrics；不要回看 Excel。
9. 从 receipt 指向的 `derived/metrics/<metrics-id>/metrics.json` 回答。回答前完整阅读共享 [editor-language.md](../../shared/references/editor-language.md)，按其中的四段顺序、状态念法和清单行形状输出；只有用户要求明细时才展开选择组和证据。

## 固定边界

- `prepare` 是唯一接触 Excel 内容的操作。成功后只读自包含 StoryBundle；Agent、`metrics` 和 `validate` 都不得再读取 Excel。
- Runtime 负责归组、计数、价格解析、比例、间隔、行数、格式和阈值比较。Agent 不复制这些算法，也不手工汇总替代 Runtime。
- PC/FC 等“选择点数量”和组内“付费、免费、总分支数量”是不同指标，必须明确命名。
- 缺少语义 annotation 或全书上下文时保留 Runtime 的 raw/unknown 口径，不将未知包装成通过或最终有效数量。
- 只报告确定性指标与相关信息项，不评价付费内容是否值得、剧情是否精彩或按钮声音。
- 不调用其他 skill。只有用户明确改为完整审核时，才改用完整审核入口并生成 Markdown。
- 任一 CLI 命令非零退出或返回顶层 `status=error` 时读取 `command-errors.md`，先恢复或停止再继续；不得把 Metrics/Validate 错误归咎于 Excel。

面向编辑的用词、状态念法、清单形状和版本呈现一律以共享 [editor-language.md](../../shared/references/editor-language.md) 为准：和编辑交流用中文，引用证据保留英文原文，给出编辑自己的 Excel 文件名、Sheet、行号或单元格，**插件的中间目录和文件名一律不出现在答复里**。

## 按需资源

- [metrics-user-contract.md](references/metrics-user-contract.md)：指标口径、渐进读取和聊天展示。
- `../../shared/references/editor-language.md`：生成任何面向编辑的答复或报错说明前读取。
- `../../shared/references/command-errors.md`：任一 CLI 命令失败时读取并恢复。
- `../../shared/references/review-state.md`：仅在“全部文件”或 receipt 为 `reused` 时读取。
- `../../shared/rules/metrics-config.json`：需要解释结构、价格或阈值时读取。
- `../../shared/rules/editorial-rubric.md`：需要写语义 annotation 时，只读定义该 key 的对应小节。
- `../../shared/references/findings.md`：需要写语义 annotations 或解释 Findings 时读取。
