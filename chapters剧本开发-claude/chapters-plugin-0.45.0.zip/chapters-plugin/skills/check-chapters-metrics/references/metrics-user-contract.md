# 指标查询契约

面向编辑的一切用词、状态念法、清单形状和版本呈现，以共享 [editor-language.md](../../../shared/references/editor-language.md) 为准；本文件下面的小节标题和内部术语是给 Agent 看的，不要照搬到答复里。

## 数据来源

一次指标查询的事实流是单向的：

```text
Excel --prepare--> story-bundle/ --metrics--> derived/metrics/<metrics-id>/
                              \--Agent annotations--/
```

Excel 只由 `prepare` 内的 Workbook Adapter 读取。成功后，所有检查、解释、验证和回答都从 receipt 返回的 manifest 开始；不得为核对一个数字重新打开 Excel。

`metrics` 为每组不同的 Bundle、规则、annotations 和整本上下文生成 `<metrics-id>`，并在该目录发布不可变 `metrics.json`；完全相同的输入复用同一已验证快照。Agent 必须使用 stdout receipt 返回的准确路径，不能假设“最新”目录，也不能覆盖旧结果。

## 渐进读取

只问常见汇总时：

1. 读 `manifest.json` 的章节索引与诊断计数；
2. 运行 `metrics`；
3. 读 receipt 指向的 `metrics.json` 汇总部分；
4. 只在解释异常时读取相关 choices、lines、source map 或机械 Findings。

只有指标依赖语义分类时，才在运行 Metrics 前读取相关章节：先 `choices.json`，再从 `lines.ndjson` 筛必要上下文。将判断写入 `analysis/annotations.ndjson`，不要把整本正文加载进上下文。

source map 是证据追溯层，不是日常浏览入口。最终展示某个失败或未知项时才读取对应 `source-map.ndjson`，并交给 `validate` 核对。

## 确定性与语义的边界

Runtime 独立负责：

- Choice 标记解析、选择组与嵌套树；
- 付费/免费/VIP 结构计数；
- 价格字段解析和合法值比较；
- 行数、比例、密度、间隔、格式与阈值；
- 按规则聚合全书和逐章结果。

Agent 只在规则明确要求时标注无法从结构唯一确定的语义，例如一段选择是否属于捏脸流程、某处是否构成重大剧情转折。Metrics 消费 annotations 后重算；Agent 不直接写最终数字或 pass/fail。

缺少必要 annotation 时必须保留 Runtime 的 `raw` 或 `unknown`。不要为了得到确定结论而默认“没有”。

## 整本上下文

用户只问若干自然章号时，给 `metrics` 为每章重复传入 `--chapter N`。章节 scope 是 Metrics 的上下文、identity 和 receipt 的一部分；直接读取 scoped `summary`，不得从逐章 observations 手工相加。`--chapter` 不得与整本参数混用。

只有用户或明确的交付说明给出整本状态和总章数 N，并且 manifest 中的章节全部已解析为自然章号、集合恰为 `1..N` 时，才可在 `metrics` 中同时传入 `--complete-book --declared-total-chapters N`。“Local Project 全部文件”只表示已扫描该目录，不证明稿件已是整本；也不得用最大章号或文件数量反推 N。

无法证明时省略这两个参数并继续其他检查，**不得在开始前询问编辑是否整本**。此时价格 30 的整本规则保持 `unknown`，在答复的「需要你确认的」一段里写出这一条并紧跟一句缺什么，再按 `editor-language.md` 的结尾可选下一步收尾。

## 结构口径

具体算法以当前 `metrics-config.json` 为准；回答时至少保持以下区分：

- **PC 选择点**：含付费分支的选择组；
- **FC 选择点**：没有付费分支的纯免费选择组；
- **L1 / L2**：一级付费选择与嵌套在 L1 分支中的二级付费选择，不作为同层选择点混算；
- **PO**：按规则识别的换装选择；同一次换装中的多件衣服不自动变成多个选择点；
- **VIP**：既保留 VIP 标记，也按规则计入相应付费结构；
- **捏脸**：只有完成所需语义标注后才从 effective 口径排除。

对“有几个 PC/FC”必须分别报告：

1. 选择组数量；
2. 这些组中的付费分支、免费分支和总分支数量。

不能把“一个 PC 组有三个付费分支和一个免费分支”说成“三个 PC 和一个 FC”。

上述数字直接读取全书 `summary.choice_group_branch_counts` 或逐章 `observations.choice_group_branch_counts`：

- `raw`：未应用捏脸排除；
- `after_known_customization`：只排除已明确标注为捏脸的组；
- `effective.status=complete` 时使用 `effective.counts` 作为最终口径；
- `effective.status=unknown` 时不得把中间值包装成最终数量，应同时报告 raw、已知排除后的观察值及 `dependency` 中尚未完成的 annotation coverage。

每个 `FC|PC|PO` 分类已直接提供 `choice_groups`、`premium_branches`、`free_branches` 和 `total_branches`；Agent 不再自行聚合逐组或逐章数据。

## 价格口径

价格只从 Runtime 已识别的选项分支商业字段解析；正文中的数字不是价格。当前允许值和阶梯以 `metrics-config.json` 为准。

回答时分开说明：

- 实际解析到的价格或奖励；
- 规则期望的价格集合/阶梯；
- 无法唯一解析的值；
- 需要全书或语义上下文才能判断的特殊价位。

没有实际价格时可以报告分支结构和期望规则，但实际定价结论必须保持 `unknown`。不得从混合文本里自行抽数字补齐。

## 聊天回答

指标查询默认只在聊天里回答，不生成 `analysis/audit-report.md`。按以下四段固定顺序：

1. **一句话结论** —— 先给编辑所问范围的数，并在同一句里说清有几处要改。例：「第 1、3 章一共 12 个付费选择点、8 个免费选择点。其中 2 处不符合规则，1 处需要你确认。」不允许用「已完成检查，详见下文」这类空话开头。
2. **不符合规则的部分** —— 每条按 `editor-language.md` 的清单行形状给出：位置（Excel 文件名 · Sheet · 行号或单元格）、问题、怎么改。按优先级排序，不给每条标严重程度。
3. **需要你确认的** —— 无法判断的项，每条紧跟一句缺什么；如有「不确定是否整本」导致的项，在这一段之后给结尾的可选下一步。
4. **必要的说明** —— 只在数字容易被误读时补一句怎么算的（例：一个付费选择点里有三个付费分支，不等于三个付费选择点）。编辑没问就不要展开选择组明细。

只有编辑明确要求时才展开逐组明细。展开时同样给出 Excel 文件名、Sheet、行号或单元格和直接相关的英文原文；数出来的结论说明算的范围、实际是多少、规则要求多少。

已经查过且没有问题的检查项，按 `editor-language.md` 的两句话规则明确写出「这一项查过了，没问题」；**不允许留空，也不允许用没展示的关注项暗示「没有问题」**。

插件的中间目录和文件名一律不出现在答复里。
