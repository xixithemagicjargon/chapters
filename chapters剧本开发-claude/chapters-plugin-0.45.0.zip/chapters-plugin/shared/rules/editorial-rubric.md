# Chapters editorial evaluation rubric

Version: `0.44.0`

This file is the single authority for narrative and editorial judgments used by the Chapters audit plugin. Numeric thresholds and pricing belong to `metrics-config.json`; workbook parsing belongs to the StoryBundle implementation. Content compliance is outside the v0.1.0 scope and must not be invented here.

## Result contract

Every editorial Finding must include:

- `rubric_version` exactly matching the `Version` declared above
- `rule_id`
- `classification`: `strength`, `risk`, or `suggestion`
- one valid StoryBundle `scope_ref` plus one or more `line_id`/field evidence references
- the exact English source excerpt supporting the judgment
- a concise rationale tied to the rubric
- `confidence`: `high`, `medium`, or `low`
- any annotation consumed by a deterministic rule

During analysis, use logical IDs and read only the needed chapter/choice/text shards. Once a candidate result is supported, read that chapter's `source-map.ndjson` last and add the project-relative file, Sheet, row and cell range required by the final Finding.

Do not turn an aesthetic judgment into a hard failure. Use `risk` with an explicit confidence level when reasonable editors could disagree. If required context is unavailable, do not invent an editorial conclusion; emit a separate `information/reminder`. If a rule does not apply, record that fact in notes without creating an editorial Finding. A concrete English rewrite may accompany `suggestion`, but it must never be written back to the source workbook automatically.

Tri-state values such as `true|false|unknown` below are semantic annotations consumed by other rules, not Finding classifications.
Every annotation must also include the same exact `rubric_version`; an annotation from an older rubric is not a valid deterministic Metrics input.

## Shared annotation rules

### `classify.customization-flow`

Purpose: identify character-customization choice groups that every choice metric must exclude.

The flow is not tied to a chapter number. It most often sits in chapter 1, but it legitimately appears in chapter 2 or later when the character it belongs to is introduced there. Never mark a group as customization, and never refuse to, on the strength of its chapter alone.

First use deterministic signals in `choices.json`, including button patterns such as `Choose your/his/her [appearance attribute]`, to locate candidates. Then review adjacent groups and their bounded text context as one flow.

A flow **opens** on a group where both of the following hold:

1. Its choices select a character's own appearance attributes such as look, hair, hairstyle, eye color, skin tone, body type, or style.
2. That character's appearance has not already been selected earlier in the submitted material. A character being introduced at or near this group supports this; so does an MC whose look has not been chosen yet even though she has been speaking for some time. Use the `role_id` sequence in `lines.ndjson` as the evidence for when a character enters, and do not treat "has spoken before" as proof that the appearance was already selected.

The flow then **extends** over:

3. A group that directly continues a confirmed customization group without intervening story progression and still operates on appearance rather than story, personality, or relationships.
4. The confirmation or reselect dialog that closes the flow.

Consecutive appearance groups followed by a closing confirmation are the shape to look for, and the three signals reinforce each other: a first-appearance anchor with a run of appearance groups and a confirmation dialog is a clear flow. A lone appearance group with no neighbouring appearance group and no confirmation dialog is weak evidence; prefer `unknown` over marking it.

Changing the look of a character whose appearance is already established is not customization. A selection made for a specific scene belongs to `classify.outfit-choice` instead. An explicit later offer to redo the character's look still qualifies, under 4.

When the submitted material starts mid-story, a character may have first appeared, and had their appearance selected, in a chapter that was not submitted. Return `unknown` in that case; do not read the earliest submitted chapter as the character's first appearance.

For every reviewed group, write one annotation with `key=is_customization`, the group ID as `target_ref`, and `value=true|false|unknown`. `flow_id` and `candidate_reason` may be added as explanatory fields; groups in one flow receive separate records with the same `flow_id`. A targeted review may annotate only candidates, but customization-dependent Metrics must then stay `unknown`. To publish final effective PC/FC/PO counts, cover every choice group explicitly; use `false` for reviewed non-customization groups rather than treating a missing record as false.

If meaning or continuity is ambiguous, return `unknown`; metrics depending on the exclusion must not silently count the group.

### `classify.outfit-choice`

Purpose: supply the Paid Outfit judgment that marker phrases cannot make.

The parser already marks a group as PO when the line immediately before it contains one of the recognized marker phrases (`INSERT OUTFIT CHOICE`, `I'll wear`, `I will wear`, `I'd wear`, `I should wear`). Matching is phrase containment, so an ordinary line of dialogue carrying one of those phrases also produces a PO. That deterministic result stands; this annotation exists to catch the opposite case, where the group is plainly an outfit choice but the wording matches nothing.

Mark a group `true` when both hold:

1. Its branches choose what the MC wears in the upcoming scene: a garment, outfit, look, or accessory selected for a specific occasion.
2. The surrounding text presents it as a wardrobe decision rather than as story action.

Return `false` when the group is not an outfit choice, and `unknown` when the Bundle does not carry enough context. Write the result with `key=is_outfit_choice`, the group ID as `target_ref`, and `value=true|false|unknown`.

`false` records your judgment but does not remove a PO the marker phrases already confirmed; the deterministic signal wins, and a group you believe was wrongly marked belongs in a Finding that names the triggering line, not in an annotation that silently reclassifies it. Omitting the annotation is safe: the marker result simply stands, and no metric becomes `unknown` for the lack of it.

Do not confuse this with `classify.customization-flow`. Customization selects the avatar's lasting appearance attributes such as hair, eye color, or skin tone. An outfit choice selects what the MC wears for a scene while the avatar stays the same.

### `classify.intimacy-level`

Purpose: create the semantic annotation required by the early-intimacy metric.

Assign the highest clearly evidenced level reached by the evaluated PC content:

| Annotation | Meaning |
|---|---|
| `L0` | Time with the LI but no intimate language or physical interaction |
| `L1` | Verbal intimacy or flirting without physical contact |
| `L2` | Nonsexual intimate contact such as holding hands, hugging, or cuddling |
| `L3T6` | Kissing |
| `L7A8` | Manual stimulation |
| `L9A10` | Oral sex |
| `L11A12` | Genital intercourse |
| `L13` | Toys, tools, or BDSM equipment |
| `L14` | Group sex or orgy |
| `L15` | Anal sex |
| `HEA` | MC and LI formally establish their lasting relationship |

Write the result with `key=intimacy_level`, the PC group as `target_ref`, and the selected level as `value`. Return `unknown` rather than extrapolating from implication that does not satisfy a category. The metrics engine treats `L1` through `L15` and `HEA` as intimate; it treats `L0` as non-intimate.

### `classify.pc-category`

Purpose: record what kind of value each Premium Choice sells. Every identified PC group must carry this annotation; deciding that a PC is compliant is not a substitute for tagging it.

The taxonomy has four categories. A PC normally belongs to exactly one.

| Category | Prefix | Scope |
|---|---|---|
| Romance | `{R}` | Romantic interaction with an LI or NPC, verbal or physical |
| Personality shaping | `{P}` | The MC's personality is shaped by taking a certain action, usually a positive one |
| Information unlocking | `{I}` | The MC discovers information about an LI, an NPC, or an event |
| Capability enhancement | `{C}` | The MC acquires a skill or asset that helps them achieve something or defeat someone |

#### Romance subtypes

Reuse the level already assigned by `classify.intimacy-level`; do not re-derive it here. The tag is that level wrapped in the Romance prefix: `{R}[L0]`, `{R}[L1]`, `{R}[L2]`, `{R}[L3T6]`, `{R}[L7A8]`, `{R}[L9A10]`, `{R}[L11A12]`, `{R}[L13]`, `{R}[L14]`, `{R}[L15]`, `{R}[HEA]`.

`{R}[L0]` is a Romance PC for tagging purposes even though the early-intimacy metric treats `L0` as non-intimate. The two judgments are independent; do not adjust one to match the other.

#### Personality shaping subtypes

| Tag | Subtype | Supported when |
|---|---|---|
| `{P}[HCLI]` | Helping/comforting LI | The MC helps or comforts the LI |
| `{P}[HCNPC]` | Helping/comforting NPC | The MC helps or comforts an NPC |
| `{P}[RR]` | Relationship remedy | The MC makes up with someone after a rift |
| `{P}[DY]` | Defend yourself | The MC defends themselves |
| `{P}[SU]` | Stand up for yourself | The MC stands up for an LI, a friend, or another NPC |
| `{P}[SZ]` | Socializing | The MC mingles with others |
| `{P}[TR]` | Taking revenge | The MC takes revenge |
| `{P}[BSTJ]` | Bringing someone to justice | The MC brings someone, usually the antagonist, to justice |
| `{P}[BT]` | Being tactical | The MC makes a smart or diplomatic move to resolve a crisis or escape danger |
| `{P}[SO]` | Saving others | The MC saves an LI or NPC from danger |
| `{P}[BH]` | Being honest | The MC tells others the truth |
| `{P}[AP]` | Adopting a pet for company | The MC takes in a pet for companionship |
| `{P}[PA]` | Parental actions | The MC acts in a parental role |
| `{P}[SES]` | Seeking emotional support | The MC seeks emotional support from an LI or NPC |

#### Information unlocking subtypes

| Tag | Subtype | Supported when |
|---|---|---|
| `{I}[LIB]` | LI's backstory | The unlocked information is the LI's backstory |
| `{I}[NPCB]` | NPC's identity or backstory | The unlocked information is an NPC's identity or backstory |
| `{I}[WW]` | Worldview information | The PC reveals someone's secret, yields a clue toward solving a mystery, or uncovers the MC's own backstory |

#### Capability enhancement subtypes

| Tag | Subtype | Supported when |
|---|---|---|
| `{C}[NS]` | New skills | The MC gains a skill |
| `{C}[NE]` | New equipment | The MC gains equipment |
| `{C}[BP]` | Befriending a pet for a purpose | The MC allies with an animal to serve a specific purpose |

Pet PCs separate on intent, not on subject: companionship is `{P}[AP]`, while an animal acquired to accomplish something is `{C}[BP]`.

#### Tagging rules

- Write one annotation per identified PC group with `key=pc_category`, the PC group ID as `target_ref`, and `value` as a list of tags.
- Normally the list holds exactly one tag. When the PC genuinely satisfies the criteria of two categories, list both rather than forcing a single choice; state in the evidence or rationale which criteria each tag rests on. Do not list two subtypes of the same category, and do not list more than two tags.
- When no subtype fits, use the single value `["unmatched"]` and say in the rationale what the PC sells. Never approximate with the nearest tag.
- When the Bundle does not carry enough context to decide, use the single value `["unknown"]`. `unknown` means undecided; `unmatched` means decided and outside the taxonomy.
- A targeted review may tag only the PC groups it examined. To publish a complete category breakdown, every identified PC group needs its own record; a missing record is not `unmatched`.
- This annotation is a classification, not a judgment. It does not feed any deterministic metric, and it must not be turned into a `strength`, `risk`, or `suggestion` on its own.

## Story and chapter rubrics

### `structure.recap-consistency`

Required context: the current chapter and its actual preceding chapter.

- `strength`: the opening recap accurately represents material events or state from the preceding chapter.
- `suggestion`: a recap is present but contains a concrete mismatch or material omission that makes the continuation misleading.
- Chapter 1: record in notes that the rule does not apply; do not create a Finding.
- Missing preceding chapter or unresolved order: emit `information/reminder` instead of an editorial conclusion.

Evidence must cite both the recap and the corresponding preceding-chapter passage.

### `structure.inciting-event`

This is report-only and always returns `information/report`, not a compliance verdict. Locate every candidate satisfying all four conditions:

1. A concrete event, action, decision, or accident occurs.
2. It materially and nontrivially disrupts the MC's prior equilibrium.
3. The MC initially underestimates the event's impact.
4. It has a supported causal direction toward the chapter or story outcome available in the available Bundle context.

Annotate each event as:

- trigger: `causal` or `coincidental`
- position: `immediate`, `delayed`, or `off_page`
- location and short description

If the available Bundle context does not include enough of the outcome to assess condition 4, record the candidate and make that limitation explicit.

### `structure.chapter-hook`

Required context: the chapter's closing beat, meaning the narrative after the last choice group's merge point through the final line, plus enough of the chapter to tell whether that beat gets resolved before the chapter ends.

A chapter must end on a hook. A closing beat qualifies as a hook when it is one of:

1. **Suspense** — a question, threat, or expectation is raised and left open.
2. **Plot reversal** — an established fact, alliance, or intention turns out to be the opposite of what the chapter had the reader believe.
3. **Sudden event** — an abrupt interruption, arrival, accident, or revelation breaks the scene's trajectory.
4. **Exposed secret** — something the MC or another character was concealing is walked in on or found out.

In every one of the four cases the beat must still be open when the chapter ends. A beat that the same chapter goes on to explain, defuse, or settle is not a hook, however dramatic it was in the moment: nothing is left pulling the reader into the next chapter. For an exposed secret this is the whole point of the category, so state explicitly in the Finding that the chapter does not address the exposure.

- `strength`: the closing beat matches at least one category and is still open at the chapter's end. Name the category and quote the beat.
- `risk`: the chapter closes on a settled or purely transitional beat, so nothing carries into the next chapter.
- `suggestion`: a qualifying beat exists in the chapter but sits before a settled ending, or a closing beat almost qualifies and a concrete repositioning or trim would make it a hook. Say which beat and where it should land.
- The chapter's ending is missing from the submitted material, or its `structure_status` shows the closing beat is incomplete: emit `information/reminder` and name what is missing.

The requirement does not apply to the proven final chapter of a complete book, which is expected to resolve rather than to hook. Without proof that the chapter is the last one, do not treat a resolving ending as a `risk` on the assumption that more chapters follow; emit `information/reminder` and say that final-chapter status is unproven.

Judge the closing beat, not the chapter's overall quality, and do not reuse the `editorial.premium-payoff` or `structure.inciting-event` evidence as a hook by itself.

## Choice-design rubrics

### `editorial.paid-node-fit`

A PC fits when its location clearly matches at least one category:

- `key_plot`: a consequential route decision, reveal, reversal, pivotal clue or character, story-phase transition, or hidden-content opportunity
- `emotion`: a clear positive or negative emotional high point or sharp state change
- `relationship_change`: a material relationship transition, first milestone, betrayal, conflict, reconciliation, alliance, or comparable shift
- `intimacy`: intimate contact, private time, romantic escalation, exclusive attention, jealousy, protectiveness, or comparable LI-focused behavior

Return `strength` with the matched category or categories when the node is supported. Return `risk` when no allowed node is supported, or `suggestion` when the evidence supports a concrete repositioning or payoff change. When price 30 is present, write a separate annotation with `key=major_plot_turn`, the PC group as `target_ref`, and `value=true|false|unknown`; ordinary `key_plot` fit does not automatically mean a major plot turn.

### `editorial.button-intent`

Evaluate the button as the player's intended action, not as a label for an object or scene. Not applicable to PO buttons; see Boundaries.

A button supporting `strength` combines:

- an active intent or action
- a concrete anticipated payoff
- wording plausibly expressible in the MC's voice

Use `suggestion` for a mere object/action label, permission request, or vague promise with no concrete payoff. Do not judge word count here; it belongs to Metrics. The ampersand restriction was withdrawn: `&` in a button is not a defect and no rule evaluates it. Game/internet jargon requires context and is evaluated separately by `editorial.button-immersive-language`.

### `editorial.button-tone`

Not applicable to PO buttons; see Boundaries. Evaluate punctuation, capitalization, and emphasis against evidence of the work's established tone. Comedic romance may support emphasis that a restrained dark romance would not.

- `strength`: emphasis is consistent and not substituting for substance.
- `suggestion`: emphasis is excessive or conflicts with established tone.
- Too little surrounding material to establish tone: emit `information/reminder`.

### `editorial.button-immersive-language`

Not applicable to PO buttons; see Boundaries. Evaluate semantic language restrictions that a lexical script cannot reliably decide.

- `suggestion`: a button uses explicit game/internet jargon (for example combo, critical hit, GG, or boss battle) in place of in-world intent.
- `strength`: the button remains in-world and sells the action without game shorthand.
- A word that is plausible both in-world and as jargon requires local context; if the context does not resolve it, emit `information/reminder` rather than guessing.

The ampersand restriction was withdrawn. A literal `&` in a button is not a defect, there is no deterministic check for it any more, and it must not be raised as an Editorial Finding under this or any other rule.

### `editorial.button-premature-love`

Not applicable to PO buttons; see Boundaries. Required context: the current relationship state and any prior relationship milestone.

- `suggestion`: before formal relationship establishment, the button or paid content reads as an unqualified declaration of love or established commitment.
- `strength`: it stays within attraction, flirtation, interrupted intensity, or a relationship state already established by evidence.
- Prior relationship state unavailable: emit `information/reminder`.

### `editorial.language-fluency`

Required context: the chapter's story text and dialogue as delivered in `content`.

Judge whether the English reads as though it were written in English. The StoryBundle carries one script column and no source-language text, so this rule is about the English on the page and nothing else.

Report a problem under one of these patterns:

1. **Translationese** — grammatical but unidiomatic phrasing that mirrors another language's construction, such as a literal rendering of an idiom, a stacked modifier chain, or a connective used where English would not repeat one.
2. **Register mismatch** — narration or dialogue pitched above or below the scene and speaker, such as formal or bookish vocabulary in a casual exchange.
3. **Awkward or incorrect construction** — article, preposition, number, or tense errors, and run-ons that a native editor would break up.
4. **Unnatural dialogue rhythm** — a line no speaker would say aloud: exposition delivered as speech, or beats that do not land in the mouth.
5. **Inconsistent terminology** — the same place, title, object, or nickname rendered differently within the chapter.

For each pattern reported, quote the exact English excerpt and give a minimal English rewrite marked as a suggestion. Report the pattern, not every occurrence: name it, then cite at most three instances chosen for impact. A long list of individual preferences is not a Finding.

This rule is advisory. Every result it produces is a `suggestion`; it never returns `strength` or `risk`, and a fluency problem never becomes a compliance verdict no matter how widespread it is.

- `suggestion`: one or more reviewed lines read as localized rather than written in English. Cite each cited line's Excel row or cell, the exact English excerpt, the pattern it falls under, and a minimal English rewrite.
- Only part of the chapter is present in the Bundle: emit `information/reminder` and say what was reviewed.
- Nothing to report: emit no Finding. The report states in the chapter's fluency block that no line needed changing; silence in the Bundle is not evidence, so never imply a clean chapter by leaving the block empty.

Results belong at the end of the chapter they came from. They are reported per chapter, after every other judgment for that chapter, and they do not enter the report's cross-chapter priority summary even when there are many of them.

Out of scope for this rule:

- **Translation accuracy.** No source-language text exists in the Bundle. Never claim a line departs from an original, and never infer what the original said.
- Deliberate voice: a character's dialect, slang, verbal tic, broken English, or period diction is characterization, not a fluency defect. Check it against that character's other lines before reporting.
- US versus UK spelling and other house-style preferences, unless the chapter is internally inconsistent, which belongs to pattern 5.
- Buttons of a PO group, which no button-copy rule evaluates, and stage-direction markers. That covers `INSERT OUTFIT CHOICE` and every line whose `special_type` is `Callback`, meaning both a callback's condition line and its `End callback`. The reader never sees these, so their English is not prose; see the Callback region section of `story-bundle.md`.
- Wording that `editorial.button-intent` or `editorial.button-tone` already owns; do not report the same button twice under two rules.

### `editorial.branch-merge-consistency`

Compare every branch's resulting facts and character state at the merge point.

- `strength`: differences are intentionally reconciled or the merged mainline is compatible with every branch.
- `suggestion`: the merged text assumes an action, possession, knowledge, injury, location, relationship state, or other fact that at least one branch did not produce.
- No reliable merge point: emit `information/reminder`.

### `editorial.negative-result-narration`

- `suggestion`: narrator text directly judges the player's taste, intelligence, or morality because of the selected option.
- `strength`: the text reports scene consequences and character reactions without narrator condemnation.

Character criticism inside the story is not automatically narrator judgment; identify the speaker and narrative frame.

### `editorial.l2-upgrade-value`

The structural parentage check belongs to `metrics.l2-parentage`. Evaluate only narrative quality here.

An L2 supports `strength` when all of these are supported:

1. It is prepared within the L1 premium content.
2. It provides value beyond the L1 payoff.
3. It is a strongly related escalation of the same scene rather than a new independent situation.
4. It is not a second charge for choosing a detail of the same already-purchased action.

Use `suggestion` when a condition is disproved and `risk` when the distinction between escalation and double charging is genuinely debatable.

The source also suggests pairing an L2 with every L1 from chapter 2 onward, while its count table does not require that ratio. This is `conflict.l2-pairing-vs-count`; do not issue a finding solely because an L1 lacks L2 until resolved.

### `editorial.premium-payoff`

For each paid branch, identify distinct payoff beats and when they occur.

- `strength`: at least three distinct payoff beats are supported, at least one is immediate, and material promised by the button is delivered.
- `suggestion`: fewer than three are supported, none is immediate, or a material promise is not delivered.
- `risk`: candidate beats are present but their distinctness is debatable.

Do not count synonymous reactions or repeated dialogue as separate payoffs without a distinct effect on action, emotion, relationship, information, or player experience.

### `editorial.po-scene-reason`

This rule is advisory. It only ever returns `suggestion`, never `risk`, and a missing reason is never a compliance verdict.

Look for three things in the text before the outfit choice:

1. **Scene** — where and when this is happening: a date, ceremony, celebration, meeting, task, disguise, infiltration.
2. **Background** — what the occasion is and who will be there, enough that the clothes have an audience.
3. **Motive** — why the MC cares how she looks in this scene.

- `strength`: all three are present and concrete. Name which line carries each.
- `suggestion`: one or more is missing. Say which of the three is absent and where a line would fix it.
- Preceding setup missing from the submitted material: emit `information/reminder`.

Do not evaluate whether the clothes are attractive, and do not judge the wording on the outfit choice's buttons; PO button copy is out of scope for every rule.

## Boundaries

- Content safety, Heat limits, consent, and trigger warnings are outside the v0.1.0 audit scope.
- Body, anatomy, and sexual-organ vocabulary is not evaluated by any rule, at any explicitness level. Do not raise it under `editorial.button-immersive-language`, `editorial.button-intent`, or any other rule.
- PO and customization button copy is not evaluated. `editorial.button-intent`, `editorial.button-tone`, `editorial.button-immersive-language` and `editorial.button-premature-love` all skip every branch of a PO group and of a customization group, and so do the deterministic button checks. Wardrobe buttons name a garment and customization buttons name a look; neither is the MC deciding to do something, so intent, tone and immersion have nothing to judge there, and twelve buttons reading `Choose his look.` is how a look picker is written, not a defect. `editorial.po-scene-reason` still applies: it judges the scene reason before the outfit choice, not the wording on its buttons.
- Counts, thresholds, branch structure, setup rows, and observed prices are governed only by `metrics-config.json`.
- Creative quality outside the explicit rubrics is out of scope. `editorial.language-fluency` covers how natively the English reads and nothing wider; plot merit, prose ambition, and market potential stay out.
- Callback condition lines and `End callback` lines are stage directions the reader never sees. No rule evaluates their wording, and any judgment about what a reader experiences consecutively must follow one display path at a time rather than reading a callback region's mutually exclusive variants as continuous text.
- A literal `&` in a button is not evaluated by any rule. The restriction was withdrawn, so do not report it.
- Translation accuracy is not auditable. The Bundle carries one script column and no source-language text, so no rule may claim a line diverges from an original or infer what an original said.
