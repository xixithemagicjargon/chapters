"""Shared implementation and contracts for the Chapters plugin."""
