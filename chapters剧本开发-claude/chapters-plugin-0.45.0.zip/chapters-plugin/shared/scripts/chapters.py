#!/usr/bin/env python3
"""Small Agent CLI for the Chapters StoryBundle deep module."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Sequence


PLUGIN_ROOT = Path(__file__).resolve().parents[2]
if str(PLUGIN_ROOT) not in sys.path:
    sys.path.insert(0, str(PLUGIN_ROOT))

from shared.runtime.chapters_bundle import (  # noqa: E402
    ChapterConflictError,
    DocxError,
    MetricsError,
    StoryBundleError,
    StoryBundleInputError,
    StoryBundleUsageError,
    build_story_bundle,
    compute_metrics,
    render_editor_docx,
    validate_artifacts,
)


class _CliUsageError(ValueError):
    """An invalid Agent invocation that must use the JSON error boundary."""


class _JsonArgumentParser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        raise _CliUsageError(message)


def _chapter_source(value: str) -> tuple[int, str]:
    chapter_text, separator, candidate_id = value.partition("=")
    try:
        chapter = int(chapter_text)
    except ValueError as error:
        raise argparse.ArgumentTypeError(
            "chapter source must use CHAPTER=CANDIDATE_ID"
        ) from error
    if not separator or chapter < 1 or not candidate_id:
        raise argparse.ArgumentTypeError(
            "chapter source must use CHAPTER=CANDIDATE_ID"
        )
    return chapter, candidate_id


def _parser() -> argparse.ArgumentParser:
    parser = _JsonArgumentParser(
        description="Prepare, measure, or validate a self-contained Chapters StoryBundle."
    )
    commands = parser.add_subparsers(dest="command", required=True)
    prepare = commands.add_parser(
        "prepare",
        help="Parse only the explicitly supplied XLSX sources into a StoryBundle.",
    )
    prepare.add_argument("--project-root", required=True, type=Path)
    prepare.add_argument(
        "--source",
        action="append",
        required=True,
        metavar="XLSX",
        help="Explicit XLSX path, relative to project root or absolute; repeat as needed.",
    )
    prepare.add_argument("--book-title")
    prepare.add_argument(
        "--chapter-source",
        action="append",
        default=[],
        type=_chapter_source,
        metavar="CHAPTER=CANDIDATE_ID",
        help="Resolve a reported chapter conflict with its returned stable candidate ID.",
    )
    metrics = commands.add_parser(
        "metrics",
        help="Calculate deterministic metrics from one ready StoryBundle.",
    )
    metrics.add_argument("--manifest", required=True, type=Path)
    metrics.add_argument("--annotations", type=Path)
    metrics.add_argument(
        "--chapter",
        action="append",
        metavar="N",
        help="Limit Metrics to a resolved natural chapter number; repeat as needed.",
    )
    metrics.add_argument(
        "--complete-book",
        action="store_true",
        help="Assert that the manifest is a proven whole book; requires exact 1..N coverage.",
    )
    metrics.add_argument(
        "--declared-total-chapters",
        type=int,
        metavar="N",
        help="Editor-provided whole-book chapter total; valid only with --complete-book.",
    )
    validate = commands.add_parser(
        "validate",
        help="Validate a StoryBundle and optional Agent-authored artifacts.",
    )
    validate.add_argument("--manifest", required=True, type=Path)
    validate.add_argument("--annotations", type=Path)
    validate.add_argument("--findings", type=Path)
    validate.add_argument("--metrics", type=Path)
    editor_docx = commands.add_parser(
        "editor-docx",
        help="Render the editor's .docx copy from an Agent-authored summary.",
    )
    editor_docx.add_argument("--summary", required=True, type=Path)
    editor_docx.add_argument("--output", required=True, type=Path)
    return parser


def _print_receipt(value: object) -> None:
    payload = value.to_dict()  # type: ignore[attr-defined]
    print(
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    )


def _print_error(
    code: str,
    error: Exception,
    *,
    conflicts: object | None = None,
    issues: object | None = None,
) -> None:
    payload: dict[str, object] = {
        "status": "error",
        "error": code,
        "message": str(error),
    }
    if conflicts is not None:
        payload["conflicts"] = conflicts
    if issues is not None:
        payload["issues"] = issues
    print(
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ),
        file=sys.stderr,
    )


def _bundle_path(manifest_value: Path) -> Path:
    try:
        manifest = manifest_value.resolve(strict=True)
    except FileNotFoundError as error:
        raise StoryBundleUsageError(
            f"StoryBundle manifest does not exist: {manifest_value}"
        ) from error
    if not manifest.is_file() or manifest.name != "manifest.json":
        raise StoryBundleUsageError(
            "--manifest must name a StoryBundle manifest.json file"
        )
    return manifest.parent


def _chapter_sources(values: Sequence[tuple[int, str]]) -> dict[int, str]:
    result: dict[int, str] = {}
    for chapter, candidate_id in values:
        if chapter in result:
            raise _CliUsageError(
                f"Chapter {chapter} was selected more than once"
            )
        result[chapter] = candidate_id
    return result


def _metric_chapter_numbers(values: Sequence[str] | None) -> tuple[int, ...] | None:
    if values is None:
        return None
    result: list[int] = []
    for value in values:
        try:
            result.append(int(value))
        except ValueError as error:
            raise MetricsError(
                "--chapter must name a resolved positive natural chapter number"
            ) from error
    return tuple(result)


def _execute(arguments: argparse.Namespace) -> int:
    if arguments.command == "prepare":
        receipt = build_story_bundle(
            arguments.source,
            project_root=arguments.project_root,
            chapter_sources=_chapter_sources(arguments.chapter_source),
            book_title=arguments.book_title,
        )
        _print_receipt(receipt)
        return 0
    if arguments.command == "metrics":
        receipt = compute_metrics(
            _bundle_path(arguments.manifest),
            annotations_path=arguments.annotations,
            chapter_numbers=_metric_chapter_numbers(arguments.chapter),
            complete_book=arguments.complete_book,
            declared_total_chapters=arguments.declared_total_chapters,
        )
        _print_receipt(receipt)
        return 0
    if arguments.command == "editor-docx":
        receipt = render_editor_docx(arguments.summary, arguments.output)
        _print_receipt(receipt)
        return 0
    if arguments.command == "validate":
        receipt = validate_artifacts(
            _bundle_path(arguments.manifest),
            findings_path=arguments.findings,
            annotations_path=arguments.annotations,
            metrics_path=arguments.metrics,
        )
        _print_receipt(receipt)
        return 0 if receipt.status == "valid" else 1
    raise AssertionError(f"unhandled command: {arguments.command}")


def main(argv: Sequence[str] | None = None) -> int:
    try:
        arguments = _parser().parse_args(argv)
        return _execute(arguments)
    except _CliUsageError as error:
        _print_error("usage_error", error)
    except ChapterConflictError as error:
        _print_error(
            "chapter_conflict",
            error,
            conflicts=[dict(item) for item in error.conflicts],
        )
    except StoryBundleUsageError as error:
        _print_error("usage_error", error)
    except StoryBundleInputError as error:
        _print_error(
            "source_input_error",
            error,
            issues=[dict(item) for item in error.issues],
        )
    except DocxError as error:
        _print_error("docx_error", error)
        return 1
    except MetricsError as error:
        _print_error("metrics_error", error)
    except StoryBundleError as error:
        _print_error("story_bundle_error", error)
    except OSError as error:
        _print_error("io_error", error)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
