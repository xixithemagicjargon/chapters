"""Runtime packages shared by all user-facing Chapters skills."""
