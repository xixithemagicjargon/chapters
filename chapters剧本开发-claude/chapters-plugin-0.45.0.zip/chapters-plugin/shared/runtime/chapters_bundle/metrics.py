"""Deterministic Chapters metrics calculated exclusively from StoryBundle facts."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
from typing import Any, Iterable, Mapping, Sequence

from .bundle import StoryBundle, iter_ndjson, load_story_bundle
from .validate import _validated_annotation_records


METRICS_FORMAT = "chapters.metrics"
METRICS_VERSION = "0.44.0"
_WORD_RE = re.compile(r"[A-Za-z]+(?:['’][A-Za-z]+)*")


class MetricsError(ValueError):
    """The deterministic metrics request or its Bundle input is invalid."""


@dataclass(frozen=True, slots=True)
class MetricsReceipt:
    status: str
    metrics_id: str
    bundle_id: str
    metrics_path: Path
    chapter_numbers: tuple[int, ...] | None
    summary: Mapping[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "metrics_id": self.metrics_id,
            "bundle_id": self.bundle_id,
            "metrics_path": str(self.metrics_path),
            "chapter_numbers": (
                list(self.chapter_numbers)
                if self.chapter_numbers is not None
                else None
            ),
            "summary": dict(self.summary),
            "read_first": str(self.metrics_path),
        }


@dataclass(slots=True)
class _Chapter:
    entry: Mapping[str, Any]
    lines: list[dict[str, Any]]
    choices: Mapping[str, Any]
    line_by_id: dict[str, dict[str, Any]]
    seq_by_id: dict[str, int]
    group_by_id: dict[str, dict[str, Any]]
    branch_by_id: dict[str, dict[str, Any]]

    @property
    def chapter_id(self) -> str:
        return str(self.entry["chapter_id"])

    @property
    def number(self) -> int | str:
        return self.entry["number"]


@dataclass(frozen=True, slots=True)
class _Annotations:
    digest: str | None
    customization: Mapping[str, bool | None]
    intimacy: Mapping[str, str | None]
    major_plot_turn: Mapping[str, bool | None]
    outfit_choice: Mapping[str, bool | None]


def compute_metrics(
    bundle_path: str | os.PathLike[str],
    *,
    annotations_path: str | os.PathLike[str] | None = None,
    chapter_numbers: Sequence[int] | None = None,
    complete_book: bool = False,
    declared_total_chapters: int | None = None,
) -> MetricsReceipt:
    """Compute versioned, immutable metrics without opening any source workbook."""

    if not isinstance(complete_book, bool):
        raise MetricsError("complete_book must be boolean")
    if declared_total_chapters is not None and (
        isinstance(declared_total_chapters, bool)
        or not isinstance(declared_total_chapters, int)
        or declared_total_chapters < 1
    ):
        raise MetricsError("declared_total_chapters must be a positive integer")
    if complete_book and (
        declared_total_chapters is None
    ):
        raise MetricsError("complete_book requires a positive declared_total_chapters")
    if not complete_book and declared_total_chapters is not None:
        raise MetricsError("declared_total_chapters is only valid with complete_book")
    chapter_scope = _normalize_chapter_scope(chapter_numbers)
    if complete_book and chapter_scope is not None:
        raise MetricsError(
            "chapter_numbers cannot be combined with complete_book; "
            "complete-book metrics always use the full Bundle"
        )
    bundle = load_story_bundle(bundle_path)
    config, config_digest = _load_config()
    annotations = _load_annotations(bundle, annotations_path)
    chapters = _select_chapters(_load_chapters(bundle), chapter_scope)
    _apply_outfit_choice_annotations(chapters, annotations)
    if complete_book:
        assert declared_total_chapters is not None
        _validate_complete_book_coverage(chapters, declared_total_chapters)
    context = {
        "complete_book": complete_book,
        "declared_total_chapters": declared_total_chapters,
        "annotations_sha256": annotations.digest,
        "chapter_numbers": list(chapter_scope) if chapter_scope is not None else None,
    }
    metrics_id = _metrics_id(bundle, config_digest, context)
    output = _metrics_directory(bundle, metrics_id)
    metrics_path = output / "metrics.json"
    result = _calculate(
        bundle,
        chapters,
        config,
        config_digest,
        annotations,
        metrics_id,
        chapter_numbers=chapter_scope,
        complete_book=complete_book,
        declared_total_chapters=declared_total_chapters,
    )
    payload = _metrics_payload(result)
    if output.exists():
        try:
            existing_payload = metrics_path.read_bytes()
            json.loads(existing_payload)
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
            raise MetricsError(f"Metrics directory exists but is incomplete: {output}") from error
        if existing_payload != payload:
            raise MetricsError(f"Metrics directory contains a different result: {output}")
        return MetricsReceipt(
            status="reused",
            metrics_id=metrics_id,
            bundle_id=str(bundle.manifest["bundle_id"]),
            metrics_path=metrics_path,
            chapter_numbers=chapter_scope,
            summary=result["summary"],
        )

    publication_status = _publish_metrics(output, payload)
    return MetricsReceipt(
        status=publication_status,
        metrics_id=metrics_id,
        bundle_id=str(bundle.manifest["bundle_id"]),
        metrics_path=metrics_path,
        chapter_numbers=chapter_scope,
        summary=result["summary"],
    )


def verify_metrics(
    metrics_path: str | os.PathLike[str],
    *,
    bundle_path: str | os.PathLike[str],
    annotations_path: str | os.PathLike[str] | None = None,
) -> MetricsReceipt:
    """Recompute and verify one canonical metrics artifact without writing files."""

    try:
        path = Path(metrics_path).resolve(strict=True)
        payload = path.read_bytes()
        existing = json.loads(payload)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise MetricsError(f"Metrics artifact cannot be read: {metrics_path}") from error
    if not path.is_file() or not isinstance(existing, dict):
        raise MetricsError(f"Metrics artifact is not a JSON object: {path}")
    if existing.get("format") != METRICS_FORMAT or existing.get("version") != METRICS_VERSION:
        raise MetricsError("Unsupported metrics artifact")
    context_value = existing.get("context")
    if not isinstance(context_value, Mapping):
        raise MetricsError("Metrics artifact context is missing")
    complete_book = context_value.get("complete_book")
    declared_total_chapters = context_value.get("declared_total_chapters")
    if "chapter_numbers" not in context_value:
        raise MetricsError("Metrics artifact chapter_numbers context is missing")
    chapter_scope = _normalize_chapter_scope(context_value.get("chapter_numbers"))
    if not isinstance(complete_book, bool):
        raise MetricsError("Metrics artifact complete_book context must be boolean")
    if complete_book and chapter_scope is not None:
        raise MetricsError(
            "Metrics artifact cannot combine chapter_numbers with complete_book"
        )
    if complete_book:
        if (
            isinstance(declared_total_chapters, bool)
            or not isinstance(declared_total_chapters, int)
            or declared_total_chapters < 1
        ):
            raise MetricsError(
                "Complete-book metrics require a positive declared_total_chapters"
            )
    elif declared_total_chapters is not None:
        raise MetricsError(
            "Partial-book metrics cannot declare declared_total_chapters"
        )

    bundle = load_story_bundle(bundle_path)
    config, config_digest = _load_config()
    annotations = _load_annotations(bundle, annotations_path)
    if context_value.get("annotations_sha256") != annotations.digest:
        raise MetricsError(
            "Metrics artifact annotations digest does not match the supplied annotations"
        )
    chapters = _select_chapters(_load_chapters(bundle), chapter_scope)
    _apply_outfit_choice_annotations(chapters, annotations)
    if complete_book:
        assert isinstance(declared_total_chapters, int)
        _validate_complete_book_coverage(chapters, declared_total_chapters)
    identity_context = {
        "complete_book": complete_book,
        "declared_total_chapters": declared_total_chapters,
        "annotations_sha256": annotations.digest,
        "chapter_numbers": list(chapter_scope) if chapter_scope is not None else None,
    }
    metrics_id = _metrics_id(bundle, config_digest, identity_context)
    canonical_path = _metrics_directory(bundle, metrics_id) / "metrics.json"
    if path != canonical_path.resolve(strict=False):
        raise MetricsError(
            f"Metrics artifact is not at its canonical path: {canonical_path}"
        )
    expected = _calculate(
        bundle,
        chapters,
        config,
        config_digest,
        annotations,
        metrics_id,
        chapter_numbers=chapter_scope,
        complete_book=complete_book,
        declared_total_chapters=declared_total_chapters,
    )
    if payload != _metrics_payload(expected):
        raise MetricsError(
            "Metrics artifact differs from the deterministic Bundle/config/context result"
        )
    return MetricsReceipt(
        status="verified",
        metrics_id=metrics_id,
        bundle_id=str(bundle.manifest["bundle_id"]),
        metrics_path=path,
        chapter_numbers=chapter_scope,
        summary=expected["summary"],
    )


def _calculate(
    bundle: StoryBundle,
    chapters: Sequence[_Chapter],
    config: Mapping[str, Any],
    config_digest: str,
    annotations: _Annotations,
    metrics_id: str,
    *,
    chapter_numbers: tuple[int, ...] | None,
    complete_book: bool,
    declared_total_chapters: int | None,
) -> dict[str, Any]:
    all_groups = [
        group
        for chapter in chapters
        for group in chapter.choices["groups"]
    ]
    customization_complete = _customization_coverage(
        all_groups,
        annotations,
    )
    choice_group_branch_counts = _choice_group_branch_counts(
        all_groups,
        annotations,
        customization_complete=customization_complete,
    )

    conditional_price = int(config["rules"]["pricing.price-30-ending"]["price"])
    price_30: list[tuple[_Chapter, Mapping[str, Any], Mapping[str, Any]]] = []
    for chapter in chapters:
        for group in chapter.choices["groups"]:
            if annotations.customization.get(group["group_id"]) is True:
                continue
            for branch in group["branches"]:
                if any(
                    term.get("kind") == "price"
                    and term.get("parse_status") == "parsed"
                    and term.get("amount") == conditional_price
                    for term in branch["commercial_terms"]
                ):
                    price_30.append((chapter, group, branch))

    chapter_results = [
        _chapter_metrics(
            chapter,
            config,
            annotations,
            customization_complete=_customization_coverage(
                chapter.choices["groups"], annotations
            ),
            complete_book=complete_book,
            declared_total_chapters=declared_total_chapters,
            price_30_count=len(price_30),
        )
        for chapter in chapters
    ]
    raw_counts = Counter(
        _raw_group_class(group)
        for chapter in chapters
        for group in chapter.choices["groups"]
    )
    effective_counts = Counter(
        _raw_group_class(group)
        for chapter in chapters
        for group in chapter.choices["groups"]
        if annotations.customization.get(group["group_id"]) is not True
    )
    parsed_prices = Counter(
        int(term["amount"])
        for chapter in chapters
        for group in chapter.choices["groups"]
        for branch in group["branches"]
        for term in branch["commercial_terms"]
        if term.get("kind") == "price" and term.get("parse_status") == "parsed"
    )
    all_checks = [
        check
        for chapter in chapter_results
        for check in chapter["checks"]
    ]
    status_counts = Counter(check["classification"] for check in all_checks)
    book_checks = _book_checks(
        chapters,
        config,
        annotations,
        scope_ref=str(bundle.manifest["bundle_id"]),
    )
    status_counts.update(check["classification"] for check in book_checks)
    rule_counts = Counter(
        check["rule_id"] for check in [*all_checks, *book_checks]
    )
    rule_coverage = {
        rule_id: {
            "status": "emitted" if rule_counts[rule_id] else "not_applicable",
            "check_count": rule_counts[rule_id],
        }
        for rule_id in sorted(config["rules"])
    }
    reminders = [
        check
        for check in [*all_checks, *book_checks]
        if check["kind"] == "information" and check["classification"] == "reminder"
    ]
    return {
        "format": METRICS_FORMAT,
        "version": METRICS_VERSION,
        "metrics_id": metrics_id,
        "bundle_id": bundle.manifest["bundle_id"],
        "config": {
            "format": config["format"],
            "version": config["version"],
            "sha256": config_digest,
        },
        "context": {
            "complete_book": complete_book,
            "declared_total_chapters": declared_total_chapters,
            "annotations_sha256": annotations.digest,
            "chapter_numbers": (
                list(chapter_numbers) if chapter_numbers is not None else None
            ),
            "customization_coverage_complete": customization_complete,
        },
        "rule_coverage": rule_coverage,
        "summary": {
            "chapter_count": len(chapters),
            "line_count": sum(len(chapter.lines) for chapter in chapters),
            "choice_groups_raw": dict(sorted(raw_counts.items())),
            "choice_groups_after_known_customization": dict(sorted(effective_counts.items())),
            "choice_group_branch_counts": choice_group_branch_counts,
            "customization_groups_confirmed": sum(
                annotations.customization.get(str(group["group_id"])) is True
                for group in all_groups
            ),
            "prices": {str(key): value for key, value in sorted(parsed_prices.items())},
            "check_statuses": dict(sorted(status_counts.items())),
            "reminder_count": len(reminders),
        },
        "chapters": chapter_results,
        "book_checks": book_checks,
        "attention": _attention_index(chapter_results, book_checks),
        "reminders": reminders,
    }


def _attention_index(
    chapter_results: Sequence[Mapping[str, Any]],
    book_checks: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """A short list of everything that is not a plain pass.

    The full checks live under `chapters[].checks`, one entry per branch per
    rule, which on a whole book is thousands of entries and megabytes of
    text. Almost all of them pass and carry no news. This index holds the
    handful that need a decision, so the reader can start there and open the
    per-chapter detail only for the chapters it names.
    """
    failed: list[dict[str, Any]] = []
    flagged: list[dict[str, Any]] = []
    undecided: Counter[str] = Counter()
    for chapter in chapter_results:
        number = chapter.get("number")
        for check in chapter["checks"]:
            classification = check["classification"]
            if classification == "pass" or classification == "report":
                continue
            if classification == "unknown":
                undecided[str(check["rule_id"])] += 1
                continue
            entry = {
                "chapter": number,
                "rule_id": check["rule_id"],
                "scope_ref": check["scope_ref"],
                "observed": check.get("observed"),
                "expected": check.get("expected"),
            }
            (failed if classification == "fail" else flagged).append(entry)
    for check in book_checks:
        classification = check["classification"]
        if classification == "unknown":
            undecided[str(check["rule_id"])] += 1
        elif classification in {"fail", "reminder"}:
            entry = {
                "chapter": None,
                "rule_id": check["rule_id"],
                "scope_ref": check["scope_ref"],
                "observed": check.get("observed"),
                "expected": check.get("expected"),
            }
            (failed if classification == "fail" else flagged).append(entry)
    return {
        "failed": failed,
        "flagged_for_review": flagged,
        "undecided_counts_by_rule": dict(sorted(undecided.items())),
        "chapters_with_failures": sorted(
            {entry["chapter"] for entry in failed if entry["chapter"] is not None},
            key=lambda value: (0, value, "") if isinstance(value, int) else (1, 0, str(value)),
        ),
    }


def _chapter_metrics(
    chapter: _Chapter,
    config: Mapping[str, Any],
    annotations: _Annotations,
    *,
    customization_complete: bool,
    complete_book: bool,
    declared_total_chapters: int | None,
    price_30_count: int,
) -> dict[str, Any]:
    rules = config["rules"]
    groups = chapter.choices["groups"]
    raw_class = {group["group_id"]: _raw_group_class(group) for group in groups}
    retained_groups = [
        group
        for group in groups
        if annotations.customization.get(group["group_id"]) is not True
    ]
    class_counts = Counter(raw_class[group["group_id"]] for group in groups)
    retained_counts = Counter(raw_class[group["group_id"]] for group in retained_groups)
    choice_group_branch_counts = _choice_group_branch_counts(
        groups,
        annotations,
        customization_complete=customization_complete,
    )
    branch_counts = Counter()
    for group in groups:
        classification = raw_class[group["group_id"]]
        for branch in group["branches"]:
            branch_counts[f"{classification}_premium" if branch["premium"] else f"{classification}_free"] += 1

    non_title_blurb = [
        line
        for line in chapter.lines
        if line.get("metadata_type") not in {"title", "blurb"}
    ]
    # Both totals count the written manuscript: a row whose Script cell is
    # empty is not a line, however its Dialogue Type is filled in.
    written = [line for line in non_title_blurb if _has_script(line)]
    word_count = sum(
        len(_WORD_RE.findall(str(line["fields"].get("content") or "")))
        for line in written
    )
    row_count = len(written)
    backgrounds = sorted(
        {
            str(line["fields"]["background_id"])
            for line in chapter.lines
            if line["fields"].get("background_id") not in (None, "")
        }
    )
    max_speaker_run, speaker_run = _max_speaker_run(chapter.lines)
    checks: list[dict[str, Any]] = []

    minimum_words = int(rules["metrics.chapter-word-count"]["suggested_minimum"])
    checks.append(
        _check(
            "metrics.chapter-word-count",
            "reminder" if word_count < minimum_words else "report",
            chapter.chapter_id,
            kind="information",
            observed={"words": word_count},
            expected={"suggested_minimum": minimum_words},
            reason=(
                "The chapter runs shorter than the suggested minimum; this "
                "needs editor review and receives no pass or fail verdict."
                if word_count < minimum_words
                else None
            ),
        )
    )
    checks.append(
        _row_count_check(
            chapter,
            row_count,
            rules["metrics.chapter-row-count"],
        )
    )
    checks.append(_premium_line_share_check(chapter, groups))
    checks.append(
        _check(
            "metrics.scene-count",
            "report",
            chapter.chapter_id,
            kind="information",
            observed={"distinct_backgrounds": len(backgrounds), "background_ids": backgrounds},
            expected={
                "suggested_minimum": rules["metrics.scene-count"]["suggested_minimum"],
                "suggested_maximum": rules["metrics.scene-count"]["suggested_maximum"],
            },
        )
    )
    max_allowed_run = int(
        rules["metrics.consecutive-speaker-lines"]["suggested_maximum"]
    )
    over_run = max_speaker_run > max_allowed_run
    checks.append(
        _check(
            "metrics.consecutive-speaker-lines",
            "reminder" if over_run else "report",
            chapter.chapter_id,
            kind="information",
            observed={"maximum_run": max_speaker_run, "line_ids": speaker_run},
            expected={"suggested_maximum": max_allowed_run},
            evidence_refs=speaker_run if over_run else [],
            reason=(
                "One speaker runs longer than the suggested maximum without "
                "anyone else speaking; this needs editor review and receives "
                "no pass or fail verdict."
                if over_run
                else None
            ),
        )
    )

    denominator = sum(retained_counts[name] for name in ("PC", "FC", "PO"))
    premium_share = (
        100.0 * (retained_counts["PC"] + retained_counts["PO"]) / denominator
        if denominator
        else None
    )
    share_rule = rules["metrics.premium-choice-share"]
    share_status = "unknown"
    share_reason = "customization annotations are incomplete"
    if customization_complete and premium_share is not None:
        share_status = (
            "pass"
            if share_rule["minimum_percent"] <= premium_share <= share_rule["maximum_percent"]
            else "fail"
        )
        share_reason = None
    checks.append(
        _check(
            "metrics.premium-choice-share",
            share_status,
            chapter.chapter_id,
            observed={"percent": premium_share, "numerator": retained_counts["PC"] + retained_counts["PO"], "denominator": denominator},
            expected={"minimum_percent": share_rule["minimum_percent"], "maximum_percent": share_rule["maximum_percent"]},
            reason=share_reason,
        )
    )

    checks.extend(
        _button_checks(
            chapter,
            groups,
            annotations,
            rules,
            customization_complete=customization_complete,
        )
    )
    checks.append(
        _choice_density_check(
            chapter,
            retained_groups,
            rules["metrics.choice-density"],
            customization_complete=customization_complete,
        )
    )
    checks.append(
        _pc_count_check(
            chapter,
            retained_groups,
            rules["metrics.pc-count"],
            customization_complete=customization_complete,
        )
    )
    checks.append(
        _l1_pc_ceiling_check(
            chapter,
            retained_groups,
            rules["metrics.l1-pc-ceiling"],
            customization_complete=customization_complete,
        )
    )
    checks.extend(_l2_parentage_checks(chapter, groups, annotations))
    checks.extend(_branch_and_return_checks(chapter, groups, raw_class, annotations, rules))
    checks.extend(
        _premium_setup_checks(chapter, groups, raw_class, annotations, rules)
    )
    checks.extend(_thought_bubble_checks(chapter, groups, raw_class, annotations, rules))
    checks.append(
        _chapter_opening_choice_check(
            chapter,
            retained_groups,
            rules["metrics.chapter-opening-choice"],
            customization_complete=customization_complete,
        )
    )
    lead_in = _premium_lead_in_check(
        chapter,
        retained_groups,
        [str(line["line_id"]) for line in non_title_blurb],
        rules["metrics.premium-lead-in"],
        customization_complete=customization_complete,
    )
    if lead_in is not None:
        checks.append(lead_in)
    checks.append(
        _fc_spacing_check(
            chapter,
            retained_groups,
            rules["metrics.fc-spacing"],
            customization_complete=customization_complete,
        )
    )
    checks.extend(_free_branch_marker_checks(chapter, groups))
    branch_by_line = {
        str(branch["button_line_id"]): str(branch["branch_id"])
        for group in groups
        for branch in group["branches"]
    }
    checks.extend(_duplicate_button_row_checks(chapter, branch_by_line))
    checks.extend(_sub_choice_marker_checks(chapter, groups))
    po_count = retained_counts["PO"]
    po_max = int(rules["metrics.po-count"]["per_chapter_maximum"])
    checks.append(
        _check(
            "metrics.po-count",
            "unknown" if not customization_complete else ("pass" if po_count <= po_max else "fail"),
            chapter.chapter_id,
            observed={"po_groups": po_count},
            expected={"per_chapter_maximum": po_max},
            reason=None if customization_complete else "customization annotations are incomplete",
        )
    )
    checks.extend(
        _pricing_checks(
            chapter,
            groups,
            raw_class,
            annotations,
            config,
            complete_book=complete_book,
            declared_total_chapters=declared_total_chapters,
            price_30_count=price_30_count,
        )
    )

    prices = Counter(
        int(term["amount"])
        for group in groups
        for branch in group["branches"]
        for term in branch["commercial_terms"]
        if term.get("kind") == "price" and term.get("parse_status") == "parsed"
    )
    return {
        "chapter_id": chapter.chapter_id,
        "number": chapter.number,
        "observations": {
            "rows": row_count,
            "words": word_count,
            "scenes": len(backgrounds),
            "choice_groups_raw": dict(sorted(class_counts.items())),
            "choice_groups_after_known_customization": dict(sorted(retained_counts.items())),
            "choice_group_branch_counts": choice_group_branch_counts,
            "branch_counts": dict(sorted(branch_counts.items())),
            "vip_groups": sum(group["signals"]["has_vip_branch"] for group in groups),
            "prices": {str(key): value for key, value in sorted(prices.items())},
        },
        "groups": [
            _group_summary(group, raw_class[group["group_id"]], annotations)
            for group in groups
        ],
        "checks": checks,
    }


def _has_script(line: Mapping[str, Any]) -> bool:
    """Whether this row carries anything in the Script column.

    A row with a Dialogue Type and an empty Script is where the script has
    ended -- writers drag the type column to the bottom of the sheet. It is
    not a line of the story, so it counts towards no length, no word total
    and no gap between choices.
    """

    return bool(str(line["fields"].get("content") or "").strip())


def _written_line_ids(chapter: _Chapter) -> set[str]:
    """The lines that are actually manuscript.

    A row carrying only a Dialogue Type and no Script is where the script has
    ended -- writers drag the type column to the bottom of the sheet, and one
    book arrived with 3016 such rows across five chapters. They are not part
    of what was written, so they stay out of both sides of any share.
    """

    return {
        str(line["line_id"])
        for line in chapter.lines
        if line.get("metadata_type") not in {"title", "blurb"} and _has_script(line)
    }


def _paid_line_ids(chapter: _Chapter, groups: Sequence[Mapping[str, Any]]) -> set[str]:
    """Every line a reader reaches only by paying.

    Counted raw, once each: the question is how much paid script exists, not
    what one reader sees, so every callback variant and every nested branch
    under a paid button counts. A free option nested inside a paid branch is
    paid content too -- it cannot be reached without paying the parent.
    """

    groups_by_id = {str(group["group_id"]): group for group in groups}

    def descend(branch: Mapping[str, Any], seen: frozenset[str]) -> set[str]:
        ids = {str(value) for value in branch.get("content_line_ids", ()) or ()}
        for child_id in branch.get("child_group_ids", ()) or ():
            key = str(child_id)
            if key in seen or key not in groups_by_id:
                continue
            child = groups_by_id[key]
            for child_branch in child["branches"]:
                ids.add(str(child_branch["button_line_id"]))
                ids |= descend(child_branch, seen | {key})
        return ids

    paid: set[str] = set()
    for group in groups:
        for branch in group["branches"]:
            if branch.get("premium"):
                paid.add(str(branch["button_line_id"]))
                paid |= descend(branch, frozenset({str(group["group_id"])}))
    return paid


def _premium_line_share_check(
    chapter: _Chapter,
    groups: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    written = _written_line_ids(chapter)
    paid = _paid_line_ids(chapter, groups) & written
    percent = 100.0 * len(paid) / len(written) if written else None
    return _check(
        "metrics.premium-line-share",
        "report",
        chapter.chapter_id,
        kind="information",
        observed={
            "paid_lines": len(paid),
            "written_lines": len(written),
            "percent": percent,
        },
        expected={"threshold": None},
    )


def _row_count_check(
    chapter: _Chapter,
    row_count: int,
    rule: Mapping[str, Any],
) -> dict[str, Any]:
    """One minimum for every chapter and no upper bound.

    The threshold no longer depends on the chapter number or on whether the
    chapter is the proven final one, so a chapter whose number never resolved
    still gets a real verdict instead of `unknown`.
    """
    minimum = int(rule["minimum"])
    return _check(
        "metrics.chapter-row-count",
        "pass" if row_count >= minimum else "fail",
        chapter.chapter_id,
        observed={"rows": row_count},
        expected={"minimum": minimum, "maximum": rule["maximum"]},
    )


def _button_checks(
    chapter: _Chapter,
    groups: Sequence[Mapping[str, Any]],
    annotations: _Annotations,
    rules: Mapping[str, Any],
    *,
    customization_complete: bool,
) -> list[dict[str, Any]]:
    word_rule = rules["metrics.button-word-count"]
    minimum_words = int(word_rule["suggested_minimum"])
    maximum_words = int(word_rule["suggested_maximum"])
    all_buttons: list[str] = []
    for group in groups:
        customization = annotations.customization.get(group["group_id"])
        if customization is True:
            continue
        # Only a PC group's paid buttons are in population. PO button copy is
        # out of scope for every button-copy rule, and free or sub-choice
        # buttons are commonly short reactive lines.
        if _raw_group_class(group) != "PC":
            continue
        for branch in group["branches"]:
            if branch["premium"]:
                all_buttons.append(branch["button_line_id"])
    counts = {
        line_id: len(
            _WORD_RE.findall(
                str(chapter.line_by_id[line_id]["fields"].get("content", ""))
            )
        )
        for line_id in all_buttons
    }
    # Bounds are inclusive: 8 and 12 both pass.
    offenders = {
        line_id: value
        for line_id, value in counts.items()
        if not minimum_words <= value <= maximum_words
    }
    # Advisory only: a paid button outside the range is surfaced for the
    # editor to judge, never as a pass or fail verdict.
    return [
        _check(
            "metrics.button-word-count",
            "reminder" if offenders else "report",
            chapter.chapter_id,
            kind="information",
            observed={
                "paid_buttons_checked": len(counts),
                "out_of_range": offenders,
                "word_counts": counts,
            },
            expected={
                "suggested_minimum": minimum_words,
                "suggested_maximum": maximum_words,
                "bounds": word_rule["bounds"],
            },
            evidence_refs=sorted(offenders),
            reason=(
                "Paid buttons outside the suggested 8-12 word range need "
                "editor review and receive no pass or fail verdict."
                if offenders
                else None
            ),
        ),
    ]


def _choice_density_check(
    chapter: _Chapter,
    groups: Sequence[Mapping[str, Any]],
    rule: Mapping[str, Any],
    *,
    customization_complete: bool,
) -> dict[str, Any]:
    reset_positions = {
        min(chapter.seq_by_id[branch["button_line_id"]] for branch in group["branches"])
        for group in groups
        if group["branches"] and group["depth"] == 1
    }
    current = 0
    maximum = 0
    maximum_lines: list[str] = []
    window: list[str] = []
    # Not a return measurement, so each callback region contributes its
    # longest variant.
    for line in _display_path_lines(chapter.lines, mode="longest"):
        if line["seq"] in reset_positions:
            current = 0
            window = []
        if (
            not line["branch_path"]
            and _normalized(line["fields"].get("dialogue_type")) == "text"
            and _has_script(line)
        ):
            current += 1
            window.append(line["line_id"])
            if current > maximum:
                maximum = current
                maximum_lines = list(window)
    limit = int(rule["suggested_maximum_text_lines_without_choice"])
    # Without full customization coverage the stretch can only be too long,
    # never too short, so hold back the reminder rather than risk a false one.
    over = customization_complete and maximum > limit
    # Advisory only: a long stretch without a choice is surfaced for the
    # editor to judge, never as a pass or fail verdict.
    if not customization_complete:
        reason: str | None = (
            "customization annotations are incomplete, so the stretch may "
            "include groups that would have reset it"
        )
    elif over:
        reason = (
            "A mainline stretch runs longer than the suggested maximum "
            "without offering a choice; this needs editor review and "
            "receives no pass or fail verdict."
        )
    else:
        reason = None
    return _check(
        "metrics.choice-density",
        "reminder" if over else "report",
        chapter.chapter_id,
        kind="information",
        observed={"maximum_mainline_text_gap": maximum},
        expected={"suggested_maximum": limit},
        evidence_refs=maximum_lines if over else [],
        reason=reason,
    )


def _l1_pc_ceiling_check(
    chapter: _Chapter,
    groups: Sequence[Mapping[str, Any]],
    rule: Mapping[str, Any],
    *,
    customization_complete: bool,
) -> dict[str, Any]:
    """Advisory ceiling on how many L1 paid choices one chapter carries.

    The hard per-chapter counts live in metrics.pc-count; this only flags a
    chapter that stacks up more paid first-level choices than the suggested
    maximum, and never returns a verdict.
    """
    maximum = int(rule["suggested_maximum"])
    l1 = sum(
        _raw_group_class(group) == "PC" and group["depth"] == 1 for group in groups
    )
    over = customization_complete and l1 > maximum
    return _check(
        "metrics.l1-pc-ceiling",
        "reminder" if over else "report",
        chapter.chapter_id,
        kind="information",
        observed={"l1_pc_groups": l1},
        expected={"suggested_maximum": maximum},
        reason=(
            "The chapter carries more L1 paid choices than the suggested "
            "maximum; this needs editor review and receives no pass or fail "
            "verdict."
            if over
            else (
                None
                if customization_complete
                else "customization annotations are incomplete"
            )
        ),
    )


def _pc_count_check(
    chapter: _Chapter,
    groups: Sequence[Mapping[str, Any]],
    rule: Mapping[str, Any],
    *,
    customization_complete: bool,
) -> dict[str, Any]:
    l1 = sum(_raw_group_class(group) == "PC" and group["depth"] == 1 for group in groups)
    l2 = sum(_raw_group_class(group) == "PC" and group["depth"] == 2 for group in groups)
    if not customization_complete or not isinstance(chapter.number, int):
        status = "unknown"
        reason = "customization coverage or chapter number is incomplete"
        expected: Mapping[str, Any] = {}
    else:
        expected = rule["variants"]["chapter_1" if chapter.number == 1 else "chapter_2_or_later"]
        if chapter.number == 1:
            passed = (
                expected["l1_minimum"] <= l1 <= expected["l1_maximum"]
                and expected["l2_minimum"] <= l2 <= expected["l2_maximum"]
            )
        else:
            passed = l1 >= expected["l1_minimum"] and l2 >= expected["l2_minimum"]
        status, reason = ("pass" if passed else "fail"), None
    return _check(
        "metrics.pc-count",
        status,
        chapter.chapter_id,
        observed={"l1_pc_groups": l1, "l2_pc_groups": l2},
        expected=expected,
        reason=reason,
    )


def _l2_parentage_checks(
    chapter: _Chapter,
    groups: Sequence[Mapping[str, Any]],
    annotations: _Annotations,
) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    for group in groups:
        if group["depth"] <= 1 or _raw_group_class(group) != "PC":
            continue
        if annotations.customization.get(group["group_id"]) is True:
            continue
        parent = chapter.branch_by_id.get(group["parent_branch_id"])
        if parent is None:
            status = "unknown"
            reason = "the nested choice parent branch is unresolved"
        else:
            status = "pass" if bool(parent["premium"]) else "fail"
            reason = None
        results.append(
            _check(
                "metrics.l2-parentage",
                status,
                group["group_id"],
                observed={"parent_branch_id": group["parent_branch_id"], "parent_is_premium": bool(parent and parent["premium"])},
                expected={"premium_parent": True},
                evidence_refs=[branch["button_line_id"] for branch in group["branches"][:1]],
                reason=reason,
            )
        )
    return results


def _branch_and_return_checks(
    chapter: _Chapter,
    groups: Sequence[Mapping[str, Any]],
    raw_class: Mapping[str, str],
    annotations: _Annotations,
    rules: Mapping[str, Any],
) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    groups_by_id = {str(item["group_id"]): item for item in groups}
    for group in groups:
        if annotations.customization.get(group["group_id"]) is True:
            continue
        classification = raw_class[group["group_id"]]
        branches = group["branches"]
        if classification == "PC":
            rule = rules["metrics.pc-branch-count"]
            count = len(branches)
            results.append(
                _check(
                    "metrics.pc-branch-count",
                    "pass" if count >= rule["minimum"] else "fail",
                    group["group_id"],
                    observed={"branches": count},
                    expected={"minimum": rule["minimum"], "ideal": rule["ideal"]},
                    evidence_refs=[branch["button_line_id"] for branch in branches],
                )
            )
            if count > rule["advisory_above"]:
                results.append(
                    _check(
                        "metrics.pc-branch-count",
                        "reminder",
                        group["group_id"],
                        kind="information",
                        observed={"branches": count},
                        expected={"advisory_above": rule["advisory_above"]},
                        reason="The group exceeds the advisory branch count.",
                    )
                )
        if classification == "FC":
            rule = rules["metrics.fc-branch-count"]
            free = [branch for branch in branches if not branch["premium"]]
            customization_known = annotations.customization.get(group["group_id"]) is False
            results.append(
                _check(
                    "metrics.fc-branch-count",
                    (
                        "unknown"
                        if not customization_known
                        else ("pass" if len(free) >= rule["minimum"] else "fail")
                    ),
                    group["group_id"],
                    observed={"free_branches": len(free)},
                    expected={"minimum": rule["minimum"], "ideal": rule["ideal"]},
                    evidence_refs=[branch["button_line_id"] for branch in free],
                    reason=(
                        None
                        if customization_known
                        else "customization annotation is unavailable"
                    ),
                )
            )
            if customization_known and len(free) > rule["advisory_above"]:
                results.append(
                    _check(
                        "metrics.fc-branch-count",
                        "reminder",
                        group["group_id"],
                        kind="information",
                        observed={"free_branches": len(free)},
                        expected={"advisory_above": rule["advisory_above"]},
                        reason="The group exceeds the advisory free-branch count.",
                    )
                )
            minimum_return = int(rules["metrics.fc-return-lines"]["minimum"])
            for branch in free:
                # Return content is what the reader is guaranteed to get, so a
                # callback region contributes its shortest variant.
                return_ids = _effective_return_line_ids(
                    chapter, branch, groups_by_id, mode="shortest"
                )
                count = len(return_ids)
                results.append(
                    _check(
                        "metrics.fc-return-lines",
                        (
                            "unknown"
                            if not customization_known
                            else ("pass" if count >= minimum_return else "fail")
                        ),
                        branch["branch_id"],
                        observed={"return_lines": count},
                        expected={"minimum": minimum_return},
                        evidence_refs=_length_evidence(
                            branch,
                            return_ids,
                            (
                                "unknown"
                                if not customization_known
                                else ("pass" if count >= minimum_return else "fail")
                            ),
                        ),
                        reason=(
                            None
                            if customization_known
                            else "customization annotation is unavailable"
                        ),
                    )
                )
        if classification == "PC" and group["depth"] == 1:
            minimum_return = int(rules["metrics.l1-return-lines"]["minimum"])
            for branch in branches:
                if branch["premium"]:
                    # Return content is what the reader is guaranteed to get,
                    # so a callback region contributes its shortest variant.
                    return_ids = _effective_return_line_ids(
                        chapter, branch, groups_by_id, mode="shortest"
                    )
                    count = len(return_ids)
                    results.append(
                        _check(
                            "metrics.l1-return-lines",
                            "pass" if count >= minimum_return else "fail",
                            branch["branch_id"],
                            observed={"return_lines": count},
                            expected={"minimum": minimum_return},
                            evidence_refs=_length_evidence(
                                branch,
                                return_ids,
                                "pass" if count >= minimum_return else "fail",
                            ),
                        )
                    )
                    results.append(
                        _l1_return_words_check(chapter, branch, return_ids, rules)
                    )
        if classification == "PC" and group["depth"] == 2:
            minimum_return = int(rules["metrics.l2-return-lines"]["minimum"])
            for branch in branches:
                if branch["premium"]:
                    return_ids = _effective_return_line_ids(
                        chapter, branch, groups_by_id, mode="shortest"
                    )
                    count = len(return_ids)
                    results.append(
                        _check(
                            "metrics.l2-return-lines",
                            "pass" if count >= minimum_return else "fail",
                            branch["branch_id"],
                            observed={"return_lines": count},
                            expected={"minimum": minimum_return},
                            evidence_refs=_length_evidence(
                                branch,
                                return_ids,
                                "pass" if count >= minimum_return else "fail",
                            ),
                        )
                    )
    return results


def _l1_return_words_check(
    chapter: _Chapter,
    branch: Mapping[str, Any],
    return_ids: Sequence[str],
    rules: Mapping[str, Any],
) -> dict[str, Any]:
    """Total words an L1 paid branch is guaranteed to return.

    L1 branches carry both floors, ten lines and a hundred words; an L2
    branch is held to its ten lines only. Counted over the same effective
    path as the return-line rules, so a callback region contributes its
    shortest variant and a nested choice group its shortest option. Buttons
    are not dialogue and never count.
    """
    rule = rules["metrics.l1-return-words"]
    minimum = int(rule["minimum"])
    words = sum(
        len(_WORD_RE.findall(str(chapter.line_by_id[line_id]["fields"].get("content", ""))))
        for line_id in return_ids
        if line_id in chapter.line_by_id
    )
    return _check(
        "metrics.l1-return-words",
        "pass" if words >= minimum else "fail",
        branch["branch_id"],
        observed={"return_words": words, "return_lines": len(return_ids)},
        expected={"minimum": minimum},
        evidence_refs=_length_evidence(
            branch, return_ids, "pass" if words >= minimum else "fail"
        ),
    )


def _thought_bubble_checks(
    chapter: _Chapter,
    groups: Sequence[Mapping[str, Any]],
    raw_class: Mapping[str, str],
    annotations: _Annotations,
    rules: Mapping[str, Any],
) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    lookback = int(rules["metrics.pre-pc-thought-bubble"]["lookback_lines"])
    for group in groups:
        if raw_class[group["group_id"]] != "PC" or group["depth"] != 1:
            continue
        if annotations.customization.get(group["group_id"]) is True or not group["branches"]:
            continue
        first = min(chapter.seq_by_id[branch["button_line_id"]] for branch in group["branches"])
        previous = chapter.lines[max(0, first - lookback - 1) : first - 1]
        qualifying = [
            line["line_id"]
            for line in previous
            if _normalized(line["fields"].get("thought_bubble")) == "yes"
        ]
        results.append(
            _check(
                "metrics.pre-pc-thought-bubble",
                "pass" if qualifying else "fail",
                group["group_id"],
                observed={"qualifying_lines": len(qualifying), "lookback": lookback},
                expected={"minimum_qualifying_lines": 1},
                evidence_refs=[line["line_id"] for line in previous],
            )
        )
    return results


def _premium_setup_checks(
    chapter: _Chapter,
    groups: Sequence[Mapping[str, Any]],
    raw_class: Mapping[str, str],
    annotations: _Annotations,
    rules: Mapping[str, Any],
) -> list[dict[str, Any]]:
    rule = rules["metrics.premium-setup-lines"]
    results: list[dict[str, Any]] = []
    for group in groups:
        group_id = str(group["group_id"])
        depth = int(group["depth"])
        if (
            raw_class[group_id] != "PC"
            or depth not in {1, 2}
            or annotations.customization.get(group_id) is True
        ):
            continue
        setup_ids, question_line_id, boundary_reasons = _setup_line_ids(
            chapter, group, groups
        )
        # A minimum is only meaningful at the amount every reader is
        # guaranteed, so a callback region contributes its shortest variant
        # here, the same way the return-length floors do.
        setup_set = {str(value) for value in setup_ids}
        if setup_set:
            setup_ids = [
                str(line["line_id"])
                for line in _display_path_lines(
                    chapter.lines,
                    mode="shortest",
                    keep=lambda line: str(line["line_id"]) in setup_set,
                )
            ]
        reasons = list(boundary_reasons)
        if annotations.customization.get(group_id) is None:
            reasons.append("customization annotation is unavailable")
        if question_line_id is None:
            reasons.append("the direct choice question line is unavailable")
        minimum = int(rule["l1_minimum" if depth == 1 else "l2_minimum"])
        status = (
            "unknown"
            if reasons
            else ("pass" if len(setup_ids) >= minimum else "fail")
        )
        first_button = min(
            (
                branch["button_line_id"]
                for branch in group["branches"]
                if branch["button_line_id"] in chapter.seq_by_id
            ),
            key=chapter.seq_by_id.__getitem__,
            default=None,
        )
        evidence = [*setup_ids]
        if question_line_id is not None:
            evidence.append(question_line_id)
        if first_button is not None:
            evidence.append(first_button)
        results.append(
            _check(
                "metrics.premium-setup-lines",
                status,
                group_id,
                observed={
                    "available_direct_setup_lines_before_question": len(setup_ids),
                    "question_line_id": question_line_id,
                    "boundary": (
                        "before_last_direct_text_line_preceding_first_choice_button"
                        if depth == 1
                        else "before_last_direct_parent_branch_line_preceding_first_choice_button"
                    ),
                },
                expected={"minimum": minimum},
                evidence_refs=evidence,
                reason="; ".join(dict.fromkeys(reasons)) if reasons else None,
            )
        )
    return results


def _setup_line_ids(
    chapter: _Chapter,
    group: Mapping[str, Any],
    groups: Sequence[Mapping[str, Any]],
) -> tuple[list[str], str | None, list[str]]:
    reasons: list[str] = []
    button_positions = [
        chapter.seq_by_id[branch["button_line_id"]]
        for branch in group.get("branches", [])
        if branch.get("button_line_id") in chapter.seq_by_id
    ]
    if not button_positions:
        return [], None, ["the choice has no resolvable first button"]
    first_position = min(button_positions)
    siblings = [
        candidate
        for candidate in groups
        if candidate.get("depth") == group.get("depth")
        and candidate.get("parent_branch_id") == group.get("parent_branch_id")
        and int(candidate.get("order", 0)) < int(group.get("order", 0))
    ]
    start_position = 1
    if siblings:
        previous = max(siblings, key=lambda candidate: int(candidate.get("order", 0)))
        previous_positions = _group_positions(chapter, previous)
        if previous_positions:
            start_position = max(previous_positions) + 1
        else:
            reasons.append("the preceding sibling choice boundary is unavailable")
        if previous.get("structure_status") == "uncertain":
            reasons.append("the preceding sibling choice boundary is uncertain")

    parent_branch_id = group.get("parent_branch_id")
    if int(group["depth"]) == 1:
        direct_path: list[str] = []
    elif isinstance(parent_branch_id, str) and parent_branch_id in chapter.branch_by_id:
        direct_path = [parent_branch_id]
    else:
        direct_path = []
        reasons.append("the direct parent branch is unavailable")
    candidates = [
        line
        for line in chapter.lines
        if start_position <= int(line["seq"]) < first_position
        and line.get("metadata_type") is None
        and line.get("kind") != "choice_button"
        and line.get("branch_path") == direct_path
    ]
    if int(group["depth"]) == 1:
        questions = [
            line
            for line in candidates
            if _normalized(line.get("fields", {}).get("dialogue_type")) == "text"
        ]
        question = questions[-1] if questions else None
    else:
        question = candidates[-1] if candidates else None
    if question is None:
        return [str(line["line_id"]) for line in candidates], None, reasons
    question_seq = int(question["seq"])
    return (
        [
            str(line["line_id"])
            for line in candidates
            if int(line["seq"]) < question_seq
        ],
        str(question["line_id"]),
        reasons,
    )


def _group_positions(
    chapter: _Chapter,
    group: Mapping[str, Any],
    *,
    seen: set[str] | None = None,
) -> set[int]:
    visited = set() if seen is None else seen
    group_id = str(group["group_id"])
    if group_id in visited:
        return set()
    visited.add(group_id)
    positions: set[int] = set()
    for branch in group.get("branches", []):
        for line_id in [branch.get("button_line_id"), *branch.get("content_line_ids", [])]:
            if line_id in chapter.seq_by_id:
                positions.add(chapter.seq_by_id[line_id])
        for child_id in branch.get("child_group_ids", []):
            child = chapter.group_by_id.get(child_id)
            if child is not None:
                positions.update(_group_positions(chapter, child, seen=visited))
    return positions


def _chapter_opening_choice_check(
    chapter: _Chapter,
    retained_groups: Sequence[Mapping[str, Any]],
    rule: Mapping[str, Any],
    *,
    customization_complete: bool,
) -> dict[str, Any]:
    premium_types = set(rule["premium_group_types"])
    if not customization_complete:
        return _check(
            "metrics.chapter-opening-choice",
            "unknown",
            chapter.chapter_id,
            expected={"first_group_must_not_be": sorted(premium_types)},
            reason="customization annotations are incomplete",
        )
    root = [group for group in retained_groups if int(group["depth"]) == 1]
    if not root:
        return _check(
            "metrics.chapter-opening-choice",
            "unknown",
            chapter.chapter_id,
            expected={"first_group_must_not_be": sorted(premium_types)},
            reason="The chapter has no non-customization root choice group.",
        )
    first = root[0]
    classification = _raw_group_class(first)
    return _check(
        "metrics.chapter-opening-choice",
        "fail" if classification in premium_types else "pass",
        first["group_id"],
        observed={"first_root_group_class": classification},
        expected={"first_group_must_not_be": sorted(premium_types)},
        evidence_refs=[
            branch["button_line_id"] for branch in first["branches"]
        ],
    )


def _premium_lead_in_check(
    chapter: _Chapter,
    retained_groups: Sequence[Mapping[str, Any]],
    counted_line_ids: Sequence[str],
    rule: Mapping[str, Any],
    *,
    customization_complete: bool,
) -> dict[str, Any] | None:
    premium_types = set(rule["premium_group_types"])
    forbidden = int(rule["forbidden_leading_lines"])
    expected = {"first_premium_button_after_line": forbidden}
    if not isinstance(chapter.number, int):
        return _check(
            "metrics.premium-lead-in",
            "unknown",
            chapter.chapter_id,
            expected=expected,
            reason="The chapter number is unresolved, so chapter 1 cannot be ruled out.",
        )
    if chapter.number not in rule["chapters"]:
        return None
    if not customization_complete:
        return _check(
            "metrics.premium-lead-in",
            "unknown",
            chapter.chapter_id,
            expected=expected,
            reason="customization annotations are incomplete",
        )
    position_by_line = {line_id: index for index, line_id in enumerate(counted_line_ids, 1)}
    earliest: tuple[int, str, str] | None = None
    for group in retained_groups:
        if _raw_group_class(group) not in premium_types:
            continue
        for branch in group["branches"]:
            if not branch["premium"]:
                continue
            button_line_id = str(branch["button_line_id"])
            position = position_by_line.get(button_line_id)
            if position is None:
                continue
            if earliest is None or position < earliest[0]:
                earliest = (position, str(branch["branch_id"]), button_line_id)
    if earliest is None:
        return _check(
            "metrics.premium-lead-in",
            "pass",
            chapter.chapter_id,
            observed={"first_premium_button_line": None},
            expected=expected,
        )
    position, branch_id, button_line_id = earliest
    return _check(
        "metrics.premium-lead-in",
        "fail" if position <= forbidden else "pass",
        branch_id,
        observed={"first_premium_button_line": position},
        expected=expected,
        evidence_refs=[button_line_id],
    )


_SUB_LABEL_RE = re.compile(r"^([a-z]{2,})\s*[-–—]")


def _duplicate_button_row_checks(
    chapter: _Chapter,
    branch_by_line: Mapping[str, str],
) -> list[dict[str, Any]]:
    """A button row copied verbatim from the row above it.

    The copy is read as a second choice group holding one branch, so the
    branch-count and branch-structure checks fire on a group that does not
    exist. Reporting only those would send the editor off to add a branch;
    what they need to know is that one of the two rows is surplus.

    The two rows must be adjacent in the sheet. The same button text under
    two different parents is ordinary mirroring -- one book repeats a whole
    `ac-free` branch 67 rows later, once under branch a and once under branch
    b -- and comparing each button to the previous *button* rather than the
    previous *row* reported that as a duplicate.
    """

    checks: list[dict[str, Any]] = []
    previous: tuple[tuple[str, str, str], dict[str, Any]] | None = None
    for line in chapter.lines:
        fields = line["fields"]
        key = (
            str(fields.get("dialogue_type") or ""),
            str(fields.get("line") or ""),
            str(fields.get("content") or ""),
        )
        if not key[1].strip():
            # Only button rows carry a branch label; a payoff row repeating
            # its neighbour is ordinary writing.
            previous = None
            continue
        if previous is not None and previous[0] == key and key[2]:
            line_id = str(line["line_id"])
            checks.append(
                _check(
                    "metrics.duplicate-button-row",
                    "fail",
                    branch_by_line.get(line_id, line_id),
                    observed={
                        "same_as_line_above": True,
                        "dialogue_type": key[0],
                        "price_cell": key[1],
                    },
                    expected={"same_as_line_above": False},
                    evidence_refs=[str(previous[1]["line_id"]), line_id],
                )
            )
        previous = (key, line)
    return checks


def _sub_choice_marker_checks(
    chapter: _Chapter,
    groups: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """A two-letter price label means a nested branch, and must say Sub.

    `ab-17` is branch b of the group nested under branch a. Typing that row
    `Premium Choice 2` instead of `Premium Sub Choice 2` makes the parent
    group absorb it: the real nested group is left holding one branch, and
    the branch letters after it no longer line up, so the neighbouring price
    cells cannot be read at all. One missing word, three checks derailed.
    """

    checks: list[dict[str, Any]] = []
    for group in groups:
        for branch in group["branches"]:
            line = chapter.line_by_id.get(str(branch["button_line_id"]))
            if line is None:
                continue
            raw = str(line["fields"].get("line") or "").strip().casefold()
            match = _SUB_LABEL_RE.match(raw)
            if match is None:
                continue
            declared = str(line["fields"].get("dialogue_type") or "")
            checks.append(
                _check(
                    "metrics.sub-choice-marker",
                    "pass" if "sub" in declared.casefold() else "fail",
                    branch["branch_id"],
                    observed={
                        "dialogue_type": declared,
                        "price_cell": line["fields"].get("line"),
                        "branch_label": match.group(1),
                    },
                    expected={"dialogue_type": "must contain Sub"},
                    evidence_refs=[branch["button_line_id"]],
                )
            )
    return checks


def _free_branch_marker_checks(
    chapter: _Chapter,
    groups: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """A branch that costs nothing must not be typed Premium.

    The house rule is that a free option does not say Premium. Writing
    `Premium Choice 3` above `c-free` is a formatting mistake: the price cell
    still decides -- the branch is read as free either way -- but anyone who
    checks the type instead of the price reads it as paid, which is exactly
    what happened the first time this book was audited.
    """

    checks: list[dict[str, Any]] = []
    for group in groups:
        for branch in group["branches"]:
            if not any(
                term.get("kind") == "free"
                for term in branch.get("commercial_terms", ()) or ()
            ):
                continue
            line = chapter.line_by_id.get(str(branch["button_line_id"]))
            declared = str((line or {}).get("fields", {}).get("dialogue_type") or "")
            marked = "premium" in declared.casefold() or "vip" in declared.casefold()
            checks.append(
                _check(
                    "metrics.free-branch-marker",
                    "fail" if marked else "pass",
                    branch["branch_id"],
                    observed={
                        "dialogue_type": declared,
                        "price_cell": (line or {}).get("fields", {}).get("line"),
                    },
                    expected={"dialogue_type": "no Premium or VIP marker on a free branch"},
                    evidence_refs=[branch["button_line_id"]],
                )
            )
    return checks


def _fc_spacing_check(
    chapter: _Chapter,
    groups: Sequence[Mapping[str, Any]],
    rule: Mapping[str, Any],
    *,
    customization_complete: bool,
) -> dict[str, Any]:
    if not customization_complete or not isinstance(chapter.number, int):
        return _check(
            "metrics.fc-spacing",
            "unknown",
            chapter.chapter_id,
            reason="customization coverage or chapter number is incomplete",
        )
    root = [group for group in groups if group["depth"] == 1]
    intervals: list[int] = []
    count = 0
    for group in root:
        classification = _raw_group_class(group)
        if classification == "FC":
            count += 1
        elif classification == "PC":
            intervals.append(count)
            count = 0
    lead_in = int(rule["chapter_1_lead_in"])
    low = int(rule["interval_minimum"])
    high = int(rule["interval_maximum"])
    expected: dict[str, Any] = {
        "between_consecutive_l1_pc": {"minimum": low, "maximum": high}
    }
    if chapter.number == 1:
        expected["chapter_1_before_first_l1_pc"] = {"minimum": lead_in}
    if not intervals:
        return _check(
            "metrics.fc-spacing",
            "unknown",
            chapter.chapter_id,
            observed={"intervals": []},
            expected=expected,
            reason="No L1 PC interval was available.",
        )
    # Chapter 1 opens on at least three narrative FC groups -- a longer free
    # run before the first paid choice is a deliberate choice, not a defect.
    # Every other interval, in chapter 1 and in every later chapter, holds one
    # or two; the minimum of one stops two L1 PC groups sitting back to back.
    failing: list[dict[str, Any]] = []
    for position, value in enumerate(intervals):
        label = (
            "before_first_l1_pc"
            if position == 0
            else f"between_l1_pc_{position}_and_{position + 1}"
        )
        if position == 0 and chapter.number == 1:
            if value < lead_in:
                failing.append(
                    {
                        "interval": label,
                        "observed": value,
                        "expected": {"minimum": lead_in},
                    }
                )
            continue
        if not low <= value <= high:
            failing.append(
                {
                    "interval": label,
                    "observed": value,
                    "expected": {"minimum": low, "maximum": high},
                }
            )
    return _check(
        "metrics.fc-spacing",
        "fail" if failing else "pass",
        chapter.chapter_id,
        observed={
            "fc_groups_before_and_between_l1_pc": intervals,
            "failing_intervals": failing,
        },
        expected=expected,
    )


def _pricing_checks(
    chapter: _Chapter,
    groups: Sequence[Mapping[str, Any]],
    raw_class: Mapping[str, str],
    annotations: _Annotations,
    config: Mapping[str, Any],
    *,
    complete_book: bool,
    declared_total_chapters: int | None,
    price_30_count: int,
) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    allowed = set(config["pricing"]["allowed"])
    standard = set(config["pricing"]["standard"])
    reminder_prices = set(config["pricing"]["reminder"])
    conditional_prices = set(config["pricing"]["conditional"])
    ladders = config["pricing"]["ladders"]
    for group in groups:
        classification = raw_class[group["group_id"]]
        if classification not in {"PC", "PO"} or annotations.customization.get(group["group_id"]) is True:
            continue
        branches = group["branches"]
        premium = [branch for branch in branches if branch["premium"]]
        free = [branch for branch in branches if not branch["premium"]]
        results.append(
            _check(
                "pricing.pc-po-branch-structure",
                "pass" if len(free) == 1 and len(premium) == len(branches) - 1 else "fail",
                group["group_id"],
                observed={"total": len(branches), "premium": len(premium), "free": len(free)},
                expected={"free": 1, "premium": len(branches) - 1},
                evidence_refs=[branch["button_line_id"] for branch in branches],
            )
        )
        observed_prices: list[int] = []
        ladder_unknown = False
        exception = False
        for branch in premium:
            terms = branch["commercial_terms"]
            parsed = [
                term
                for term in terms
                if term.get("kind") == "price" and term.get("parse_status") == "parsed"
            ]
            if len(parsed) != 1:
                ladder_unknown = True
                results.append(
                    _check(
                        "pricing.allowed-price",
                        "unknown",
                        branch["branch_id"],
                        observed={"commercial_terms": terms},
                        expected={"allowed": sorted(allowed)},
                        evidence_refs=[branch["button_line_id"]],
                        reason="The premium branch price is missing or cannot be parsed.",
                    )
                )
                continue
            amount = int(parsed[0]["amount"])
            observed_prices.append(amount)
            if amount in standard:
                results.append(
                    _check(
                        "pricing.allowed-price",
                        "pass",
                        branch["branch_id"],
                        observed={"price": amount},
                        expected={"standard": sorted(standard)},
                        evidence_refs=[branch["button_line_id"]],
                    )
                )
            elif amount in reminder_prices:
                exception = True
                results.append(
                    _check(
                        "pricing.price-22-report",
                        "reminder",
                        branch["branch_id"],
                        kind="information",
                        observed={"price": amount},
                        evidence_refs=[branch["button_line_id"]],
                        reason="Price 22 receives editor review, not a pass/fail verdict.",
                    )
                )
            elif amount in conditional_prices:
                exception = True
                status, reason = _price_30_status(
                    chapter,
                    group,
                    classification,
                    annotations,
                    complete_book=complete_book,
                    declared_total_chapters=declared_total_chapters,
                    price_30_count=price_30_count,
                )
                results.append(
                    _check(
                        "pricing.price-30-ending",
                        status,
                        group["group_id"],
                        observed={"price": amount, "book_occurrences": price_30_count},
                        expected={"only_once": True, "final_chapter": True, "group_class": "PC", "major_plot_turn": True},
                        evidence_refs=[branch["button_line_id"]],
                        reason=reason,
                    )
                )
                if status == "unknown":
                    results.append(
                        _check(
                            "pricing.price-30-ending",
                            "reminder",
                            group["group_id"],
                            kind="information",
                            observed={"price": amount},
                            evidence_refs=[branch["button_line_id"]],
                            reason="Confirm at final review that this is the only price-30 branch and a major-turn PC in the proven final chapter.",
                        )
                    )
            else:
                results.append(
                    _check(
                        "pricing.allowed-price",
                        "fail",
                        branch["branch_id"],
                        observed={"price": amount},
                        expected={"allowed": sorted(allowed)},
                        evidence_refs=[branch["button_line_id"]],
                    )
                )
        expected_ladder = ladders.get(str(len(branches)))
        if expected_ladder is None:
            results.append(
                _check(
                    "pricing.pc-po-ladder",
                    "unknown",
                    group["group_id"],
                    observed={"total_branches": len(branches), "prices": observed_prices},
                    reason="No price ladder is defined for this total branch count.",
                )
            )
            unsupported = config["unsupported_branch_counts"]
            if (
                unsupported["emit_final_reminder"]
                and len(branches) >= unsupported["total_branch_count_minimum"]
            ):
                results.append(
                    _check(
                        "pricing.pc-po-ladder",
                        "reminder",
                        group["group_id"],
                        kind="information",
                        observed={"total_branches": len(branches)},
                        expected={
                            "supported_total_branch_counts": sorted(
                                int(value) for value in ladders
                            )
                        },
                        reason="No approved price ladder exists for this branch count; flag it for final editor review.",
                    )
                )
        elif exception:
            results.append(
                _check(
                    "pricing.pc-po-ladder",
                    "unknown",
                    group["group_id"],
                    observed={"prices": observed_prices},
                    expected={"standard_ladder": expected_ladder},
                    reason="The group contains a 21 or 30 exception price.",
                )
            )
        elif ladder_unknown or len(observed_prices) != len(premium):
            results.append(
                _check(
                    "pricing.pc-po-ladder",
                    "unknown",
                    group["group_id"],
                    observed={"prices": observed_prices},
                    expected={"price_multiset": expected_ladder},
                    reason="At least one premium branch price is missing or unparsed.",
                )
            )
        else:
            results.append(
                _check(
                    "pricing.pc-po-ladder",
                    "pass" if sorted(observed_prices) == sorted(expected_ladder) else "fail",
                    group["group_id"],
                    observed={"price_multiset": sorted(observed_prices)},
                    expected={"price_multiset": sorted(expected_ladder)},
                    evidence_refs=[branch["button_line_id"] for branch in premium],
                )
            )
        results.append(
            _price_order_check(
                group,
                premium,
                observed_prices,
                config["rules"]["pricing.pc-po-price-order"],
                ladder_unknown=ladder_unknown or len(observed_prices) != len(premium),
                exception=exception,
            )
        )
    return results


def _price_order_check(
    group: Mapping[str, Any],
    premium: Sequence[Mapping[str, Any]],
    observed_prices: Sequence[int],
    rule: Mapping[str, Any],
    *,
    ladder_unknown: bool,
    exception: bool,
) -> dict[str, Any]:
    expected = {"requirement": rule["requirement"], "ties_allowed": rule["ties_allowed"]}
    if ladder_unknown:
        return _check(
            "pricing.pc-po-price-order",
            "unknown",
            group["group_id"],
            observed={"prices_in_branch_order": list(observed_prices)},
            expected=expected,
            reason="At least one premium branch price is missing or unparsed.",
        )
    if exception:
        return _check(
            "pricing.pc-po-price-order",
            "unknown",
            group["group_id"],
            observed={"prices_in_branch_order": list(observed_prices)},
            expected=expected,
            reason="The group contains a 21 or 30 exception price.",
        )
    non_increasing = all(
        earlier >= later
        for earlier, later in zip(observed_prices, observed_prices[1:])
    )
    return _check(
        "pricing.pc-po-price-order",
        "pass" if non_increasing else "fail",
        group["group_id"],
        observed={"prices_in_branch_order": list(observed_prices)},
        expected=expected,
        evidence_refs=[branch["button_line_id"] for branch in premium],
    )


def _price_30_status(
    chapter: _Chapter,
    group: Mapping[str, Any],
    classification: str,
    annotations: _Annotations,
    *,
    complete_book: bool,
    declared_total_chapters: int | None,
    price_30_count: int,
) -> tuple[str, str | None]:
    if not complete_book:
        return (
            "unknown",
            "complete-book chapter coverage and price inventory are unavailable",
        )
    disproven: list[str] = []
    missing: list[str] = []
    if classification != "PC":
        disproven.append("group is not PC")
    if isinstance(chapter.number, int) and declared_total_chapters is not None:
        if chapter.number != declared_total_chapters:
            disproven.append("chapter is not final")
    else:
        missing.append("final chapter is not proven")
    if price_30_count > 1:
        disproven.append("price 30 occurs more than once")
    major = annotations.major_plot_turn.get(group["group_id"])
    if major is False:
        disproven.append("paid node is not a major plot turn")
    elif major is not True:
        missing.append("major plot turn annotation is unavailable")
    if disproven:
        return "fail", "; ".join(disproven)
    if missing:
        return "unknown", "; ".join(missing)
    return "pass", None


def _book_checks(
    chapters: Sequence[_Chapter],
    config: Mapping[str, Any],
    annotations: _Annotations,
    *,
    scope_ref: str,
) -> list[dict[str, Any]]:
    checks: list[dict[str, Any]] = []
    first_ten = [
        chapter
        for chapter in chapters
        if isinstance(chapter.number, int) and 1 <= chapter.number <= 10
    ]
    observed_numbers = {chapter.number for chapter in first_ten}
    po_count = sum(
        _raw_group_class(group) == "PO"
        and annotations.customization.get(group["group_id"]) is not True
        for chapter in first_ten
        for group in chapter.choices["groups"]
    )
    maximum = int(config["rules"]["metrics.po-count"]["first_ten_maximum"])
    coverage = observed_numbers == set(range(1, 11))
    first_ten_customization_complete = _customization_coverage(
        (
            group
            for chapter in first_ten
            for group in chapter.choices["groups"]
        ),
        annotations,
    )
    if not first_ten_customization_complete or not coverage:
        status = "unknown"
        reason = "complete chapters 1-10 and customization coverage are required"
    else:
        status = "pass" if po_count <= maximum else "fail"
        reason = None
    checks.append(
        _check(
            "metrics.po-count",
            status,
            scope_ref,
            observed={"first_ten_po_groups": po_count, "covered_chapters": sorted(observed_numbers)},
            expected={"maximum": maximum, "required_chapters": list(range(1, 11))},
            reason=reason,
        )
    )
    # How much of the submitted script sits behind a paywall, over everything
    # submitted rather than per chapter.
    paid_total = 0
    written_total = 0
    for chapter in chapters:
        written = _written_line_ids(chapter)
        paid_total += len(_paid_line_ids(chapter, chapter.choices["groups"]) & written)
        written_total += len(written)
    checks.append(
        _check(
            "metrics.premium-line-share",
            "report",
            scope_ref,
            kind="information",
            observed={
                "paid_lines": paid_total,
                "written_lines": written_total,
                "percent": (
                    100.0 * paid_total / written_total if written_total else None
                ),
                "covered_chapters": [chapter.number for chapter in chapters],
            },
            expected={"threshold": None},
        )
    )
    intimacy_rule = config["rules"]["metrics.early-intimacy-share"]
    early_chapters = [chapter for chapter in chapters if chapter.number in {1, 2, 3}]
    early_groups = [
        group
        for chapter in early_chapters
        for group in chapter.choices["groups"]
        if annotations.customization.get(group["group_id"]) is not True
    ]
    denominator = len(early_groups)
    early_customization_complete = _customization_coverage(
        (
            group
            for chapter in early_chapters
            for group in chapter.choices["groups"]
        ),
        annotations,
    )
    pc_groups = [group for group in early_groups if _raw_group_class(group) == "PC"]
    intimacy_complete = all(group["group_id"] in annotations.intimacy and annotations.intimacy[group["group_id"]] is not None for group in pc_groups)
    intimate_levels = {"L1", "L2", "L3T6", "L7A8", "L9A10", "L11A12", "L13", "L14", "L15", "HEA"}
    numerator = sum(annotations.intimacy.get(group["group_id"]) in intimate_levels for group in pc_groups)
    percent = 100.0 * numerator / denominator if denominator else None
    early_coverage = {chapter.number for chapter in early_chapters} == {1, 2, 3}
    if not (
        early_customization_complete
        and early_coverage
        and intimacy_complete
        and denominator
    ):
        status = "unknown"
        reason = "chapters 1-3, customization, and intimacy annotations must all be complete"
    else:
        status = "pass" if percent is not None and percent < intimacy_rule["maximum_exclusive_percent"] else "fail"
        reason = None
    checks.append(
        _check(
            "metrics.early-intimacy-share",
            status,
            scope_ref,
            observed={"percent": percent, "numerator": numerator, "denominator": denominator},
            expected={"maximum_exclusive_percent": intimacy_rule["maximum_exclusive_percent"]},
            reason=reason,
        )
    )
    return checks


def _customization_coverage(
    groups: Iterable[Mapping[str, Any]], annotations: _Annotations
) -> bool:
    group_ids = [str(group["group_id"]) for group in groups]
    return all(
        group_id in annotations.customization
        and annotations.customization[group_id] is not None
        for group_id in group_ids
    )


def _choice_group_branch_counts(
    groups: Iterable[Mapping[str, Any]],
    annotations: _Annotations,
    *,
    customization_complete: bool,
) -> dict[str, Any]:
    group_list = list(groups)
    raw = _choice_group_branch_totals(group_list)
    retained = [
        group
        for group in group_list
        if annotations.customization.get(str(group["group_id"])) is not True
    ]
    after_known_customization = _choice_group_branch_totals(retained)
    resolved = sum(
        str(group["group_id"]) in annotations.customization
        and annotations.customization[str(group["group_id"])] is not None
        for group in group_list
    )
    dependency = {
        "annotation_key": "is_customization",
        "coverage_complete": customization_complete,
        "choice_groups_total": len(group_list),
        "choice_groups_resolved": resolved,
        "choice_groups_unresolved": len(group_list) - resolved,
    }
    return {
        "raw": raw,
        "after_known_customization": after_known_customization,
        "effective": {
            "status": "complete" if customization_complete else "unknown",
            "counts": after_known_customization if customization_complete else None,
            "dependency": dependency,
        },
    }


def _choice_group_branch_totals(
    groups: Iterable[Mapping[str, Any]],
) -> dict[str, dict[str, int]]:
    totals = {
        classification: {
            "choice_groups": 0,
            "premium_branches": 0,
            "free_branches": 0,
            "total_branches": 0,
        }
        for classification in ("FC", "PC", "PO")
    }
    for group in groups:
        classification = _raw_group_class(group)
        summary = totals[classification]
        premium = sum(bool(branch["premium"]) for branch in group["branches"])
        free = sum(not bool(branch["premium"]) for branch in group["branches"])
        summary["choice_groups"] += 1
        summary["premium_branches"] += premium
        summary["free_branches"] += free
        summary["total_branches"] += premium + free
    return totals


def _is_callback_marker(line: Mapping[str, Any]) -> bool:
    """A callback condition line or its `End callback`, per story-bundle.md.

    These are stage directions the reader never sees, so they neither count as
    story lines nor break or extend a run of same-speaker lines.
    """
    return _normalized(line["fields"].get("special_type")) == "callback"


def _display_units(
    lines: Sequence[Mapping[str, Any]],
) -> list[list[list[Mapping[str, Any]]]]:
    """Split a chapter into units, each a list of mutually exclusive variants.

    A plain stretch of story is one unit with a single variant. A callback
    region becomes one unit holding one variant per condition line, because a
    reader sees exactly one of them. `End callback` closes the region.
    """
    units: list[list[list[Mapping[str, Any]]]] = []
    plain: list[Mapping[str, Any]] = []
    variants: list[list[Mapping[str, Any]]] | None = None
    for line in lines:
        if not _is_callback_marker(line):
            if variants is None:
                plain.append(line)
            else:
                variants[-1].append(line)
            continue
        content = _normalized(line["fields"].get("content"))
        if content == "end callback":
            if variants is not None:
                units.append(variants)
                variants = None
            continue
        if variants is None:
            if plain:
                units.append([plain])
                plain = []
            variants = [[]]
        else:
            variants.append([])
    if variants is not None:
        # An unterminated region still contributes its variants as alternatives.
        units.append(variants)
    elif plain:
        units.append([plain])
    return units


def _length_evidence(
    branch: Mapping[str, Any],
    line_ids: Sequence[str],
    classification: str,
) -> list[str]:
    """Evidence for a length check: every line only when it did not pass.

    A passing branch needs no line-by-line evidence -- "returns 120 lines,
    requirement 10" is the whole story, and listing 120 ids per check was the
    single largest thing in metrics.json. A branch that failed or could not be
    judged still carries every line, because that is what the editor opens.
    """
    button = [str(branch["button_line_id"])]
    if classification == "pass":
        return button
    return button + [str(value) for value in line_ids]


def _pick_variant(
    variants: Sequence[Sequence[Mapping[str, Any]]],
    mode: str,
    keep,
) -> list[Mapping[str, Any]]:
    """Choose the one variant that stands for this region.

    A variant holding none of the measured lines is not an alternative for
    this measurement: a callback region can enclose whole choice groups, so a
    paid branch often exists inside exactly one variant. Counting the empty
    ones would report a branch that returns 18 lines as returning 0. Only
    when every variant is empty does the region contribute nothing.
    """
    scored = [[line for line in variant if keep(line)] for variant in variants]
    candidates = [variant for variant in scored if variant]
    if not candidates:
        return []
    chooser = min if mode == "shortest" else max
    return list(chooser(candidates, key=len))


def _display_path_lines(
    lines: Sequence[Mapping[str, Any]],
    *,
    mode: str,
    keep=None,
) -> list[Mapping[str, Any]]:
    """Lines along a single display path through every callback region.

    A region contributes exactly one variant, never zero and never all of
    them: the shortest when measuring what a paid branch is guaranteed to
    return, the longest everywhere else. Marker lines sit on no display path
    and are dropped. Chapter row and word totals deliberately do not use
    this; those stay on the raw sheet accounting, markers and every variant
    included.
    """
    if keep is None:
        def keep(_line: Mapping[str, Any]) -> bool:
            return True

    out: list[Mapping[str, Any]] = []
    variants: list[list[Mapping[str, Any]]] | None = None
    for line in lines:
        if not _is_callback_marker(line):
            if variants is None:
                if keep(line):
                    out.append(line)
            else:
                variants[-1].append(line)
            continue
        if _normalized(line["fields"].get("content")) == "end callback":
            if variants is not None:
                out.extend(_pick_variant(variants, mode, keep))
                variants = None
            continue
        if variants is None:
            variants = [[]]
        else:
            variants.append([])
    if variants is not None:
        out.extend(_pick_variant(variants, mode, keep))
    return out


def _branch_path_line_ids(
    chapter: _Chapter,
    branch: Mapping[str, Any],
    *,
    mode: str,
) -> list[str]:
    ids = {str(value) for value in branch.get("content_line_ids", ())}
    if not ids:
        return []
    selected = _display_path_lines(
        chapter.lines,
        mode=mode,
        keep=lambda line: str(line["line_id"]) in ids,
    )
    return [str(line["line_id"]) for line in selected]


def _effective_return_line_ids(
    chapter: _Chapter,
    branch: Mapping[str, Any],
    groups_by_id: Mapping[str, Mapping[str, Any]],
    *,
    mode: str,
    seen: frozenset[str] = frozenset(),
) -> list[str]:
    """Line ids a reader is guaranteed to see after taking this branch.

    Direct content counts as written. A nested choice group is an
    alternative, paid or free alike, so it folds in at the length of its
    shortest option; that option's own nesting folds in the same way. A
    callback region inside the content behaves the same, one variant only.
    Choice buttons are not dialogue and never count.
    """
    ids = _branch_path_line_ids(chapter, branch, mode=mode)
    for child_id in branch.get("child_group_ids", ()) or ():
        key = str(child_id)
        if key in seen or key not in groups_by_id:
            continue
        child = groups_by_id[key]
        options = [
            _effective_return_line_ids(
                chapter,
                child_branch,
                groups_by_id,
                mode=mode,
                seen=seen | {key},
            )
            for child_branch in child["branches"]
        ]
        if not options:
            continue
        chooser = min if mode == "shortest" else max
        ids.extend(chooser(options, key=len))
    return ids


def _feed_run(
    state: tuple[str | None, tuple[str, ...]],
    lines: Sequence[Mapping[str, Any]],
) -> tuple[tuple[str | None, tuple[str, ...]], int, tuple[str, ...]]:
    role, ids = state
    best = 0
    best_ids: tuple[str, ...] = ()
    for line in lines:
        fields = line["fields"]
        if _normalized(fields.get("dialogue_type")) != "text":
            role, ids = None, ()
            continue
        current = _normalized(fields.get("role_id"))
        if current and current == role:
            ids = ids + (str(line["line_id"]),)
        else:
            role = current
            ids = (str(line["line_id"]),)
        if len(ids) > best:
            best, best_ids = len(ids), ids
    return (role, ids), best, best_ids


def _max_speaker_run(lines: Sequence[Mapping[str, Any]]) -> tuple[int, list[str]]:
    """Longest same-speaker run any single reader can see.

    A callback region's variants are alternatives, never continuous text, so
    the run is computed along one display path at a time and the worst path
    wins. Marker lines are skipped rather than treated as narration.
    """
    maximum = 0
    maximum_ids: tuple[str, ...] = ()
    states: dict[tuple[str | None, int], tuple[str | None, tuple[str, ...]]] = {
        (None, 0): (None, ())
    }
    for variants in _display_units(lines):
        next_states: dict[
            tuple[str | None, int], tuple[str | None, tuple[str, ...]]
        ] = {}
        for state in states.values():
            for variant in variants:
                carried, best, best_ids = _feed_run(state, variant)
                if best > maximum:
                    maximum, maximum_ids = best, best_ids
                next_states.setdefault((carried[0], len(carried[1])), carried)
        states = next_states or states
    return maximum, list(maximum_ids)


def _group_summary(
    group: Mapping[str, Any], classification: str, annotations: _Annotations
) -> dict[str, Any]:
    prices = [
        term
        for branch in group["branches"]
        for term in branch["commercial_terms"]
    ]
    return {
        "group_id": group["group_id"],
        "depth": group["depth"],
        "classification": classification,
        "customization": annotations.customization.get(group["group_id"]),
        "vip": group["signals"]["has_vip_branch"],
        "structure_status": group["structure_status"],
        "branch_count": len(group["branches"]),
        "premium_branches": sum(branch["premium"] for branch in group["branches"]),
        "free_branches": sum(not branch["premium"] for branch in group["branches"]),
        "commercial_terms": prices,
        "button_line_ids": [branch["button_line_id"] for branch in group["branches"]],
    }


def _apply_outfit_choice_annotations(
    chapters: Sequence[_Chapter],
    annotations: _Annotations,
) -> None:
    """Overlay is_outfit_choice onto the in-memory groups before classification.

    The annotation can only add a PO the marker phrases missed; it can never
    take away one the parser already confirmed, so a semantic judgment cannot
    overturn a deterministic result. Nothing is written back to the Bundle.
    """
    for chapter in chapters:
        for group in chapter.choices["groups"]:
            annotated = annotations.outfit_choice.get(group["group_id"])
            group["signals"]["outfit_choice_annotation"] = annotated


def _raw_group_class(group: Mapping[str, Any]) -> str:
    if group["signals"].get("outfit_marker_line_id") is not None:
        return "PO"
    if group["signals"].get("outfit_choice_annotation") is True:
        return "PO"
    if group["signals"].get("has_premium_branch"):
        return "PC"
    return "FC"


def _check(
    rule_id: str,
    classification: str,
    scope_ref: str,
    *,
    kind: str = "hard_check",
    observed: Any = None,
    expected: Any = None,
    evidence_refs: Sequence[str] = (),
    reason: str | None = None,
) -> dict[str, Any]:
    value: dict[str, Any] = {
        "rule_id": rule_id,
        "kind": kind,
        "classification": classification,
        "scope_ref": scope_ref,
        "evidence_refs": list(evidence_refs),
    }
    if observed is not None:
        value["observed"] = observed
    if expected is not None:
        value["expected"] = expected
    if reason is not None:
        value["reason"] = reason
    return value


def _load_chapters(bundle: StoryBundle) -> list[_Chapter]:
    result: list[_Chapter] = []
    for entry in bundle.manifest["chapters"]:
        files = entry["files"]
        lines = list(iter_ndjson(bundle.path / files["lines"]["path"]))
        choices = json.loads(
            (bundle.path / files["choices"]["path"]).read_text(encoding="utf-8")
        )
        groups = choices["groups"]
        result.append(
            _Chapter(
                entry=entry,
                lines=lines,
                choices=choices,
                line_by_id={line["line_id"]: line for line in lines},
                seq_by_id={line["line_id"]: line["seq"] for line in lines},
                group_by_id={group["group_id"]: group for group in groups},
                branch_by_id={
                    branch["branch_id"]: branch
                    for group in groups
                    for branch in group["branches"]
                },
            )
        )
    return result


def _normalize_chapter_scope(
    chapter_numbers: Sequence[int] | None,
) -> tuple[int, ...] | None:
    if chapter_numbers is None:
        return None
    if isinstance(chapter_numbers, (str, bytes)) or not isinstance(
        chapter_numbers, Sequence
    ):
        raise MetricsError(
            "chapter_numbers must contain resolved positive natural chapter numbers"
        )
    values = list(chapter_numbers)
    if not values:
        raise MetricsError("chapter_numbers must not be empty when supplied")
    for number in values:
        if isinstance(number, bool) or not isinstance(number, int) or number < 1:
            raise MetricsError(
                "chapter_numbers must contain resolved positive natural chapter numbers"
            )
    if len(values) != len(set(values)):
        raise MetricsError("chapter_numbers must not contain duplicates")
    return tuple(sorted(values))


def _select_chapters(
    chapters: Sequence[_Chapter],
    chapter_scope: tuple[int, ...] | None,
) -> list[_Chapter]:
    if chapter_scope is None:
        return list(chapters)
    resolved = {
        chapter.number: chapter
        for chapter in chapters
        if isinstance(chapter.number, int) and not isinstance(chapter.number, bool)
    }
    missing = [number for number in chapter_scope if number not in resolved]
    if missing:
        rendered = ", ".join(str(number) for number in missing)
        raise MetricsError(
            "chapter_numbers contain missing or unresolved natural chapter "
            f"number(s): {rendered}"
        )
    return [resolved[number] for number in chapter_scope]


def _validate_complete_book_coverage(
    chapters: Sequence[_Chapter], declared_total_chapters: int
) -> None:
    numbers = [chapter.number for chapter in chapters]
    if any(
        isinstance(number, bool) or not isinstance(number, int) or number < 1
        for number in numbers
    ):
        valid_coverage = False
    else:
        resolved = [int(number) for number in numbers]
        unique = set(resolved)
        valid_coverage = (
            len(resolved) == declared_total_chapters
            and len(unique) == declared_total_chapters
            and min(unique, default=0) == 1
            and max(unique, default=0) == declared_total_chapters
        )
    if not valid_coverage:
        raise MetricsError(
            "complete_book chapter coverage must contain each resolved chapter "
            f"1..{declared_total_chapters} exactly once; observed {numbers!r}"
        )


def _load_config() -> tuple[dict[str, Any], str]:
    path = Path(__file__).resolve().parents[2] / "rules" / "metrics-config.json"
    try:
        payload = path.read_bytes()
        value = json.loads(payload)
    except (OSError, json.JSONDecodeError) as error:
        raise MetricsError(f"Metrics configuration cannot be read: {path}") from error
    if value.get("format") != "chapters.metrics-config" or value.get("version") != "0.44.0":
        raise MetricsError("Unsupported metrics configuration")
    return value, sha256(payload).hexdigest()


def _load_annotations(
    bundle: StoryBundle, path_value: str | os.PathLike[str] | None
) -> _Annotations:
    if path_value is None:
        return _Annotations(None, {}, {}, {}, {})
    path = Path(path_value).resolve(strict=True)
    payload = path.read_bytes()
    records, validation_errors = _validated_annotation_records(
        bundle,
        payload,
        source=str(path),
    )
    if validation_errors:
        raise MetricsError("Invalid annotations: " + "; ".join(validation_errors))
    customization: dict[str, bool | None] = {}
    intimacy: dict[str, str | None] = {}
    major: dict[str, bool | None] = {}
    outfit: dict[str, bool | None] = {}
    for item in records:
        key = item["key"]
        target = item["target_ref"]
        value = item.get("value")
        if key == "is_customization":
            customization[target] = value if isinstance(value, bool) else None
        elif key == "intimacy_level":
            intimacy[target] = (
                value if isinstance(value, str) and value != "unknown" else None
            )
        elif key == "major_plot_turn":
            major[target] = value if isinstance(value, bool) else None
        elif key == "is_outfit_choice":
            outfit[target] = value if isinstance(value, bool) else None
    return _Annotations(
        sha256(payload).hexdigest(), customization, intimacy, major, outfit
    )


def _publish_metrics(output: Path, payload: bytes) -> str:
    output.parent.mkdir(parents=True, exist_ok=True)
    working = Path(
        tempfile.mkdtemp(prefix=".metrics-build-", dir=output.parent)
    )
    try:
        _write_metrics_payload(working / "metrics.json", payload)
        if output.exists():
            existing_path = output / "metrics.json"
            try:
                existing_payload = existing_path.read_bytes()
            except OSError as error:
                raise MetricsError(
                    f"Metrics directory appeared but is incomplete: {output}"
                ) from error
            if existing_payload == payload:
                return "reused"
            raise MetricsError(
                f"Metrics directory appeared with a different result: {output}"
            )
        os.replace(working, output)
        return "created"
    finally:
        if working.exists():
            shutil.rmtree(working, ignore_errors=True)


def _write_metrics_payload(path: Path, payload: bytes) -> None:
    with path.open("xb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


def _metrics_directory(bundle: StoryBundle, metrics_id: str) -> Path:
    return bundle.path.parent / "derived" / "metrics" / metrics_id


def _json_digest(value: Any) -> str:
    return sha256(
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    ).hexdigest()


def _metrics_id(
    bundle: StoryBundle, config_digest: str, context: Mapping[str, Any]
) -> str:
    return "mx-" + _json_digest(
        {
            "bundle_id": bundle.manifest["bundle_id"],
            "metrics_version": METRICS_VERSION,
            "config_sha256": config_digest,
            "context": context,
        }
    )[:16]


def _metrics_payload(result: Mapping[str, Any]) -> bytes:
    return (
        json.dumps(
            result,
            ensure_ascii=False,
            sort_keys=True,
            indent=2,
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def _normalized(value: Any) -> str:
    return str(value).strip().casefold().replace("_", " ") if value is not None else ""
