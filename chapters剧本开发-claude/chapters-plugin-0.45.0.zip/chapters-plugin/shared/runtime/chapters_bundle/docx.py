"""Render the editor-facing summary as a .docx file.

The plugin ships with no third-party dependencies, and a .docx is a ZIP of
XML parts, so this module writes the few parts Word needs and nothing else.

The split of work is deliberate. This module knows about paragraphs, tables
and ZIP layout; it knows nothing about rules, chapters or thresholds. The
Agent decides *what belongs in front of an editor* and hands it over as a
small JSON document; this module only turns that into a file the editor can
open and forward. Keeping rule knowledge out means the Chinese check names
stay in one place, the report contract, instead of being duplicated here.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import tempfile
from typing import Any, Mapping, Sequence
from xml.sax.saxutils import escape
import zipfile

_CONTENT_TYPES = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
    '<Default Extension="rels"'
    ' ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
    '<Default Extension="xml" ContentType="application/xml"/>'
    '<Override PartName="/word/document.xml"'
    ' ContentType="application/vnd.openxmlformats-officedocument'
    '.wordprocessingml.document.main+xml"/>'
    '<Override PartName="/word/styles.xml"'
    ' ContentType="application/vnd.openxmlformats-officedocument'
    '.wordprocessingml.styles+xml"/>'
    "</Types>"
)

_ROOT_RELS = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    '<Relationship Id="rId1"'
    ' Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"'
    ' Target="word/document.xml"/>'
    "</Relationships>"
)

_DOCUMENT_RELS = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    '<Relationship Id="rId1"'
    ' Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles"'
    ' Target="styles.xml"/>'
    "</Relationships>"
)

_W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

_STYLES = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    f'<w:styles xmlns:w="{_W}">'
    "<w:docDefaults><w:rPrDefault><w:rPr>"
    '<w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Microsoft YaHei"/>'
    '<w:sz w:val="21"/>'
    "</w:rPr></w:rPrDefault></w:docDefaults>"
    '<w:style w:type="paragraph" w:styleId="Title">'
    '<w:name w:val="Title"/><w:pPr><w:spacing w:after="240"/></w:pPr>'
    '<w:rPr><w:b/><w:sz w:val="36"/></w:rPr></w:style>'
    '<w:style w:type="paragraph" w:styleId="Heading1">'
    '<w:name w:val="heading 1"/><w:pPr><w:spacing w:before="240" w:after="120"/></w:pPr>'
    '<w:rPr><w:b/><w:sz w:val="28"/></w:rPr></w:style>'
    '<w:style w:type="paragraph" w:styleId="Heading2">'
    '<w:name w:val="heading 2"/><w:pPr><w:spacing w:before="180" w:after="100"/></w:pPr>'
    '<w:rPr><w:b/><w:sz w:val="24"/></w:rPr></w:style>'
    "</w:styles>"
)


class DocxError(ValueError):
    """The editor summary cannot be rendered as a .docx."""


@dataclass(frozen=True, slots=True)
class DocxReceipt:
    status: str
    output_path: str
    chapters: int
    problem_rows: int
    option_optimizations: int
    option_additions: int
    suggestions: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "output_path": self.output_path,
            "chapters": self.chapters,
            "problem_rows": self.problem_rows,
            "option_optimizations": self.option_optimizations,
            "option_additions": self.option_additions,
            "suggestions": self.suggestions,
        }


def _text(value: Any, *, field: str) -> str:
    if value is None:
        return ""
    if not isinstance(value, str):
        raise DocxError(f"{field} must be a string")
    if len(value) > 20000:
        raise DocxError(f"{field} is too long to render")
    return value


def _required_text(value: Any, *, field: str) -> str:
    result = _text(value, field=field)
    if not result.strip():
        raise DocxError(f"{field} must not be empty")
    return result


def _paragraph(text: str, *, style: str | None = None, bold: bool = False) -> str:
    properties = f'<w:pPr><w:pStyle w:val="{style}"/></w:pPr>' if style else ""
    run_properties = "<w:rPr><w:b/></w:rPr>" if bold else ""
    if not text:
        return f"<w:p>{properties}</w:p>"
    body = escape(text).replace("\n", "</w:t></w:r><w:r><w:br/><w:t xml:space='preserve'>")
    return (
        f"<w:p>{properties}<w:r>{run_properties}"
        f'<w:t xml:space="preserve">{body}</w:t></w:r></w:p>'
    )


def _cell(text: str, *, bold: bool = False, width: int = 2200) -> str:
    return (
        f'<w:tc><w:tcPr><w:tcW w:w="{width}" w:type="dxa"/></w:tcPr>'
        f"{_paragraph(text, bold=bold)}</w:tc>"
    )


def _table(
    headers: Sequence[str],
    rows: Sequence[Sequence[str]],
    *,
    widths: Sequence[int] | None = None,
) -> str:
    if not rows:
        return ""
    columns = len(headers)
    column_widths = (
        list(widths)
        if widths is not None
        else [max(1200, 9360 // max(columns, 1))] * columns
    )
    if len(column_widths) != columns:
        raise AssertionError("table widths must match the number of columns")
    table_width = sum(column_widths)
    layout = '<w:tblLayout w:type="fixed"/>' if widths is not None else ""
    borders = "".join(
        f'<w:{edge} w:val="single" w:sz="4" w:color="BFBFBF"/>'
        for edge in ("top", "left", "bottom", "right", "insideH", "insideV")
    )
    parts = [
        f'<w:tbl><w:tblPr><w:tblW w:w="{table_width}" w:type="dxa"/>{layout}'
        f"<w:tblBorders>{borders}</w:tblBorders></w:tblPr>",
        "<w:tr>"
        + "".join(
            _cell(header, bold=True, width=column_widths[index])
            for index, header in enumerate(headers)
        )
        + "</w:tr>",
    ]
    for row in rows:
        cells = list(row)[:columns]
        cells += [""] * (columns - len(cells))
        parts.append(
            "<w:tr>"
            + "".join(
                _cell(value, width=column_widths[index])
                for index, value in enumerate(cells)
            )
            + "</w:tr>"
        )
    parts.append("</w:tbl>")
    parts.append(_paragraph(""))
    return "".join(parts)


def _require_list(value: Any, *, field: str) -> list[Any]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise DocxError(f"{field} must be a list")
    return value


def _build_document(summary: Mapping[str, Any]) -> tuple[str, int, int, int, int, int]:
    title = _text(summary.get("title"), field="title") or "Chapters 稿件审核摘要"
    overview = _require_list(summary.get("overview"), field="overview")
    chapters = _require_list(summary.get("chapters"), field="chapters")

    body: list[str] = [_paragraph(title, style="Title")]

    body.append(_paragraph("全书大概问题点", style="Heading1"))
    if overview:
        for line in overview:
            body.append(_paragraph("· " + _text(line, field="overview entry")))
    else:
        body.append(_paragraph("本次没有需要整体说明的问题。"))

    problem_rows = 0
    option_optimizations = 0
    option_additions = 0
    suggestions = 0
    for chapter in chapters:
        if not isinstance(chapter, Mapping):
            raise DocxError("each chapter must be an object")
        label = _text(chapter.get("label"), field="chapter label")
        if not label:
            raise DocxError("each chapter needs a label")
        problems = _require_list(chapter.get("problems"), field="problems")
        optimizations = _require_list(
            chapter.get("option_optimizations"), field="option_optimizations"
        )
        additions = _require_list(
            chapter.get("option_additions"), field="option_additions"
        )
        advice = _require_list(chapter.get("suggestions"), field="suggestions")
        if not problems and not optimizations and not additions and not advice:
            # A clean chapter is not in the editor's copy at all: this file
            # exists to list what needs changing.
            continue
        body.append(_paragraph(label, style="Heading1"))
        if problems:
            rows = []
            for problem in problems:
                if not isinstance(problem, Mapping):
                    raise DocxError("each problem must be an object")
                rows.append(
                    [
                        _text(problem.get("check"), field="check"),
                        _text(problem.get("checks_what"), field="checks_what"),
                        _text(problem.get("result"), field="result"),
                        _text(problem.get("advice"), field="advice"),
                    ]
                )
            problem_rows += len(rows)
            body.append(
                _table(["检测点", "检测内容", "检测结果", "建议"], rows)
            )
        if optimizations:
            rows = []
            for optimization in optimizations:
                if not isinstance(optimization, Mapping):
                    raise DocxError("each option optimization must be an object")
                rows.append(
                    [
                        _required_text(
                            optimization.get("location"),
                            field="option optimization location",
                        ),
                        _required_text(
                            optimization.get("current_option_and_price"),
                            field="option optimization current_option_and_price",
                        ),
                        _required_text(
                            optimization.get("action_and_type"),
                            field="option optimization action_and_type",
                        ),
                        _required_text(
                            optimization.get("direction_and_motivation"),
                            field="option optimization direction_and_motivation",
                        ),
                        _required_text(
                            optimization.get("recommended_premium_option_and_price"),
                            field=(
                                "option optimization "
                                "recommended_premium_option_and_price"
                            ),
                        ),
                        _required_text(
                            optimization.get("reason"),
                            field="option optimization reason",
                        ),
                        _required_text(
                            optimization.get("plan"),
                            field="option optimization plan",
                        ),
                    ]
                )
            option_optimizations += len(rows)
            body.append(_paragraph("选项优化", style="Heading2"))
            body.append(
                _table(
                    [
                        "位置",
                        "现有选项与价格",
                        "处理动作与类型",
                        "方案方向/付费动机",
                        "建议 Premium 选项与价格",
                        "优化理由",
                        "具体调整方案",
                    ],
                    rows,
                    widths=[1500, 1900, 1700, 2000, 2300, 2000, 2900],
                )
            )
        if additions:
            rows = []
            for addition in additions:
                if not isinstance(addition, Mapping):
                    raise DocxError("each option addition must be an object")
                rows.append(
                    [
                        _required_text(
                            addition.get("location"), field="option addition location"
                        ),
                        _required_text(
                            addition.get("type"), field="option addition type"
                        ),
                        _required_text(
                            addition.get("direction_and_motivation"),
                            field="option addition direction_and_motivation",
                        ),
                        _required_text(
                            addition.get("recommended_premium_option_and_price"),
                            field=(
                                "option addition recommended_premium_option_and_price"
                            ),
                        ),
                        _required_text(
                            addition.get("content_plan"),
                            field="option addition content_plan",
                        ),
                        _required_text(
                            addition.get("reason"), field="option addition reason"
                        ),
                    ]
                )
            option_additions += len(rows)
            body.append(_paragraph("选项新增", style="Heading2"))
            body.append(
                _table(
                    [
                        "位置",
                        "类型",
                        "方案方向/付费动机",
                        "建议 Premium 选项与价格",
                        "内容方案",
                        "新增理由",
                    ],
                    rows,
                    widths=[1500, 1700, 2200, 2600, 3500, 2800],
                )
            )
        if advice:
            body.append(_paragraph("本章建议", style="Heading2"))
            for line in advice:
                body.append(_paragraph("· " + _text(line, field="suggestion entry")))
            suggestions += len(advice)

    # Base summaries keep the legacy page settings. Option-only fragments may
    # use a wider canvas; insertion fits them to the completed base Word.
    page_settings = (
        '<w:pgSz w:w="11906" w:h="16838"/>'
        '<w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134"/>'
    )
    if option_optimizations or option_additions:
        page_settings = (
            '<w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/>'
            '<w:pgMar w:top="900" w:right="900" w:bottom="900" w:left="900"/>'
        )

    document = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<w:document xmlns:w="{_W}"><w:body>'
        + "".join(body)
        + "<w:sectPr>" + page_settings + "</w:sectPr></w:body></w:document>"
    )
    return (
        document,
        len(chapters),
        problem_rows,
        option_optimizations,
        option_additions,
        suggestions,
    )


def render_editor_docx(
    summary_path: str | os.PathLike[str],
    output_path: str | os.PathLike[str],
) -> DocxReceipt:
    """Write the editor's copy of the audit summary as a .docx file."""
    source = Path(summary_path).resolve(strict=True)
    try:
        summary = json.loads(source.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise DocxError(f"Editor summary cannot be read: {source}") from error
    if not isinstance(summary, Mapping):
        raise DocxError("Editor summary must be a JSON object")

    (
        document,
        chapter_count,
        problem_rows,
        option_optimizations,
        option_additions,
        suggestions,
    ) = _build_document(summary)

    target = Path(output_path)
    if target.suffix.lower() != ".docx":
        raise DocxError("Output path must end in .docx")
    target.parent.mkdir(parents=True, exist_ok=True)

    handle, temporary = tempfile.mkstemp(
        prefix=".docx-build-", dir=str(target.parent)
    )
    os.close(handle)
    try:
        with zipfile.ZipFile(
            temporary, "w", compression=zipfile.ZIP_DEFLATED
        ) as archive:
            # Written in the order Word expects to find them.
            archive.writestr("[Content_Types].xml", _CONTENT_TYPES)
            archive.writestr("_rels/.rels", _ROOT_RELS)
            archive.writestr("word/document.xml", document)
            archive.writestr("word/_rels/document.xml.rels", _DOCUMENT_RELS)
            archive.writestr("word/styles.xml", _STYLES)
        os.replace(temporary, target)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise

    return DocxReceipt(
        status="created",
        output_path=str(target.resolve()),
        chapters=chapter_count,
        problem_rows=problem_rows,
        option_optimizations=option_optimizations,
        option_additions=option_additions,
        suggestions=suggestions,
    )


__all__ = ["DocxError", "DocxReceipt", "render_editor_docx"]
