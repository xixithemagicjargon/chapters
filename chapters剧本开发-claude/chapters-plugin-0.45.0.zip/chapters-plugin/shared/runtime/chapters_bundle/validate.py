"""Validate Agent-authored annotations and findings against a StoryBundle."""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
from typing import Any, Mapping

from .bundle import StoryBundle, iter_ndjson, load_story_bundle


_FINDING_RULE_IDS = frozenset(
    {
        "structure.recap-consistency",
        "structure.inciting-event",
        "structure.chapter-hook",
        "editorial.paid-node-fit",
        "editorial.button-intent",
        "editorial.button-tone",
        "editorial.button-immersive-language",
        "editorial.button-premature-love",
        "editorial.language-fluency",
        "editorial.branch-merge-consistency",
        "editorial.negative-result-narration",
        "editorial.l2-upgrade-value",
        "editorial.premium-payoff",
        "editorial.po-scene-reason",
    }
)
_INTIMACY_LEVELS = (
    "L0",
    "L1",
    "L2",
    "L3T6",
    "L7A8",
    "L9A10",
    "L11A12",
    "L13",
    "L14",
    "L15",
    "HEA",
)
_PC_CATEGORY_TAGS = frozenset(
    [f"{{R}}[{level}]" for level in _INTIMACY_LEVELS]
    + [
        "{P}[HCLI]",
        "{P}[HCNPC]",
        "{P}[RR]",
        "{P}[DY]",
        "{P}[SU]",
        "{P}[SZ]",
        "{P}[TR]",
        "{P}[BSTJ]",
        "{P}[BT]",
        "{P}[SO]",
        "{P}[BH]",
        "{P}[AP]",
        "{P}[PA]",
        "{P}[SES]",
        "{I}[LIB]",
        "{I}[NPCB]",
        "{I}[WW]",
        "{C}[NS]",
        "{C}[NE]",
        "{C}[BP]",
    ]
)
_PC_CATEGORY_SOLE_VALUES = frozenset({"unmatched", "unknown"})


def _pc_category_prefix(tag: str) -> str:
    return tag[: tag.index("}") + 1] if "}" in tag else tag


_RUBRIC_VERSION_RE = re.compile(r"^Version:\s*`([^`]+)`\s*$", re.MULTILINE)


@dataclass(frozen=True, slots=True)
class ArtifactValidationReceipt:
    status: str
    bundle_id: str
    checked: Mapping[str, int]
    errors: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "bundle_id": self.bundle_id,
            "checked": dict(self.checked),
            "errors": list(self.errors),
        }


@dataclass(frozen=True, slots=True)
class _EvidenceTarget:
    value: Any
    source_path: str
    sheet: str
    row: int
    cell: str


def validate_artifacts(
    bundle_path: str | os.PathLike[str],
    *,
    metrics_path: str | os.PathLike[str] | None = None,
    findings_path: str | os.PathLike[str] | None = None,
    annotations_path: str | os.PathLike[str] | None = None,
) -> ArtifactValidationReceipt:
    """Return every reference/shape error at once; never consult source XLSX."""

    bundle = load_story_bundle(bundle_path)
    targets, scope_kinds = _bundle_index(bundle)
    errors: list[str] = []
    checked = {
        "bundle_chapters": len(bundle.manifest["chapters"]),
        "metrics": 0,
        "findings": 0,
        "annotations": 0,
    }
    rubric_version: str | None = None
    if findings_path is not None or annotations_path is not None:
        try:
            rubric_version = _current_editorial_rubric_version()
        except (OSError, ValueError) as error:
            errors.append(f"editorial rubric version is unavailable: {error}")
    if findings_path is not None:
        findings = _records(Path(findings_path), "finding", errors)
        checked["findings"] = len(findings)
        for index, finding in enumerate(findings, 1):
            _validate_finding(
                finding,
                index,
                targets,
                scope_kinds,
                rubric_version,
                errors,
            )
    if annotations_path is not None:
        annotations = _records(Path(annotations_path), "annotation", errors)
        checked["annotations"] = len(annotations)
        _validate_annotation_records(
            annotations,
            targets,
            scope_kinds,
            rubric_version,
            errors,
        )
    if metrics_path is not None:
        try:
            # Imported lazily because Metrics uses this validator for its
            # semantic-annotation input.  The inner annotations-only call has
            # no metrics_path, so this does not recurse.
            from .metrics import verify_metrics

            verify_metrics(
                metrics_path,
                bundle_path=bundle.path,
                annotations_path=annotations_path,
            )
            checked["metrics"] = 1
        except (OSError, ValueError) as error:
            errors.append(f"metrics artifact is invalid: {error}")
    return ArtifactValidationReceipt(
        status="valid" if not errors else "invalid",
        bundle_id=str(bundle.manifest["bundle_id"]),
        checked=checked,
        errors=tuple(errors),
    )


def _current_editorial_rubric_version() -> str:
    path = Path(__file__).resolve().parents[2] / "rules" / "editorial-rubric.md"
    text = path.read_text(encoding="utf-8")
    match = _RUBRIC_VERSION_RE.search(text)
    if match is None or not match.group(1).strip():
        raise ValueError(f"Version header is missing from {path}")
    return match.group(1).strip()


def _validate_rubric_version(
    value: Mapping[str, Any],
    prefix: str,
    expected: str | None,
    errors: list[str],
) -> None:
    actual = value.get("rubric_version")
    if not isinstance(actual, str) or not actual.strip():
        errors.append(f"{prefix}: rubric_version must be a non-empty string")
    elif expected is not None and actual != expected:
        errors.append(
            f"{prefix}: rubric_version {actual!r} does not match the current "
            f"editorial rubric version {expected!r}"
        )


def _bundle_index(
    bundle: StoryBundle,
) -> tuple[dict[tuple[str, str], _EvidenceTarget], dict[str, str]]:
    sources = {
        item["source_id"]: item["path"] for item in bundle.manifest["sources"]
    }
    targets: dict[tuple[str, str], _EvidenceTarget] = {}
    scope_kinds: dict[str, str] = {
        str(bundle.manifest["bundle_id"]): "bundle",
    }
    for entry in bundle.manifest["chapters"]:
        chapter_id = str(entry["chapter_id"])
        scope_kinds[chapter_id] = "chapter"
        files = entry["files"]
        lines = list(iter_ndjson(bundle.path / files["lines"]["path"]))
        source_map = {
            item["line_id"]: item
            for item in iter_ndjson(bundle.path / files["source_map"]["path"])
        }
        choices = json.loads(
            (bundle.path / files["choices"]["path"]).read_text(encoding="utf-8")
        )
        for group in choices["groups"]:
            scope_kinds[group["group_id"]] = "group"
            for branch in group["branches"]:
                scope_kinds[branch["branch_id"]] = "branch"
        for line in lines:
            line_id = str(line["line_id"])
            scope_kinds[line_id] = "line"
            mapping = source_map[line_id]
            for field, value in line.get("fields", {}).items():
                cell = mapping.get("cells", {}).get(field)
                if not isinstance(cell, str):
                    continue
                targets[(line_id, field)] = _EvidenceTarget(
                    value=value,
                    source_path=sources[entry["source_id"]],
                    sheet=str(entry["sheet"]),
                    row=int(mapping["excel_row"]),
                    cell=cell,
                )
    return targets, scope_kinds


def _records(path: Path, label: str, errors: list[str]) -> list[dict[str, Any]]:
    try:
        payload = path.read_bytes()
    except OSError as error:
        errors.append(f"{label} file cannot be read: {error}")
        return []
    return _records_from_payload(payload, label, str(path), errors)


def _records_from_payload(
    payload: bytes,
    label: str,
    source: str,
    errors: list[str],
) -> list[dict[str, Any]]:
    try:
        text = payload.decode("utf-8")
        records: list[dict[str, Any]] = []
        for physical_line, raw in enumerate(text.splitlines(), 1):
            if not raw.strip():
                raise ValueError(f"blank record at line {physical_line}")
            value = json.loads(raw)
            if not isinstance(value, dict):
                raise ValueError(f"record at line {physical_line} is not an object")
            records.append(value)
        return records
    except (UnicodeDecodeError, ValueError) as error:
        errors.append(f"{label} file cannot be read: invalid NDJSON in {source}: {error}")
        return []


def _validated_annotation_records(
    bundle: StoryBundle,
    payload: bytes,
    *,
    source: str,
) -> tuple[tuple[dict[str, Any], ...], tuple[str, ...]]:
    """Validate and return the exact annotation byte snapshot used by Metrics."""

    errors: list[str] = []
    records = _records_from_payload(payload, "annotation", source, errors)
    rubric_version: str | None = None
    try:
        rubric_version = _current_editorial_rubric_version()
    except (OSError, ValueError) as error:
        errors.append(f"editorial rubric version is unavailable: {error}")
    if not errors:
        targets, scope_kinds = _bundle_index(bundle)
        _validate_annotation_records(
            records,
            targets,
            scope_kinds,
            rubric_version,
            errors,
        )
    return tuple(records), tuple(errors)


def _validate_annotation_records(
    annotations: list[dict[str, Any]],
    targets: Mapping[tuple[str, str], _EvidenceTarget],
    scope_kinds: Mapping[str, str],
    rubric_version: str | None,
    errors: list[str],
) -> None:
    seen_annotations: set[tuple[str, str]] = set()
    for index, annotation in enumerate(annotations, 1):
        _validate_annotation(
            annotation,
            index,
            targets,
            scope_kinds,
            rubric_version,
            errors,
        )
        identity = (annotation.get("key"), annotation.get("target_ref"))
        if all(isinstance(item, str) for item in identity):
            if identity in seen_annotations:
                errors.append(
                    f"annotation {index}: key/target_ref duplicates an earlier annotation"
                )
            seen_annotations.add(identity)


def _validate_finding(
    value: Mapping[str, Any],
    index: int,
    targets: Mapping[tuple[str, str], _EvidenceTarget],
    scope_kinds: Mapping[str, str],
    rubric_version: str | None,
    errors: list[str],
) -> None:
    prefix = f"finding {index}"
    _validate_rubric_version(value, prefix, rubric_version, errors)
    for field in ("rule_id", "kind", "classification", "analysis_zh"):
        if not isinstance(value.get(field), str) or not str(value[field]).strip():
            errors.append(f"{prefix}: {field} must be a non-empty string")
    allowed = {
        "editorial": {"strength", "risk", "suggestion"},
        "information": {"report", "reminder"},
    }
    kind = value.get("kind")
    classification = value.get("classification")
    rule_id = value.get("rule_id")
    if isinstance(rule_id, str) and rule_id not in _FINDING_RULE_IDS:
        errors.append(f"{prefix}: rule_id is not defined by the editorial rubric")
    if isinstance(kind, str) and kind not in allowed:
        errors.append(f"{prefix}: kind is not part of the Findings contract")
    elif isinstance(kind, str) and isinstance(classification, str):
        if classification not in allowed[kind]:
            errors.append(f"{prefix}: classification does not match kind={kind}")
    if kind == "editorial" and value.get("confidence") not in {"high", "medium", "low"}:
        errors.append(f"{prefix}: editorial findings require confidence=high|medium|low")
    scope = value.get("scope_ref")
    if not isinstance(scope, str) or scope not in scope_kinds:
        errors.append(f"{prefix}: scope_ref does not resolve inside the StoryBundle")
    evidence = value.get("evidence")
    if not isinstance(evidence, list) or not evidence:
        errors.append(f"{prefix}: evidence must contain at least one reference")
        return
    for evidence_index, item in enumerate(evidence, 1):
        _validate_evidence(
            item,
            f"{prefix} evidence {evidence_index}",
            targets,
            errors,
            require_source=True,
        )


def _validate_pc_category_value(
    value: Any,
    prefix: str,
    errors: list[str],
) -> None:
    if not isinstance(value, list) or not value:
        errors.append(f"{prefix}: pc_category value must be a non-empty list of tags")
        return
    if len(value) > 2:
        errors.append(f"{prefix}: pc_category value must not carry more than two tags")
        return
    if any(not isinstance(tag, str) for tag in value):
        errors.append(f"{prefix}: pc_category tags must be strings")
        return
    if len(set(value)) != len(value):
        errors.append(f"{prefix}: pc_category value repeats a tag")
        return
    sole = [tag for tag in value if tag in _PC_CATEGORY_SOLE_VALUES]
    if sole:
        if len(value) != 1:
            errors.append(
                f"{prefix}: pc_category {sole[0]!r} must be the only value"
            )
        return
    unknown = [tag for tag in value if tag not in _PC_CATEGORY_TAGS]
    if unknown:
        errors.append(
            f"{prefix}: pc_category tag {unknown[0]!r} is not defined by the rubric"
        )
        return
    prefixes = {_pc_category_prefix(tag) for tag in value}
    if len(prefixes) != len(value):
        errors.append(
            f"{prefix}: pc_category tags must come from two different categories"
        )


def _validate_annotation(
    value: Mapping[str, Any],
    index: int,
    targets: Mapping[tuple[str, str], _EvidenceTarget],
    scope_kinds: Mapping[str, str],
    rubric_version: str | None,
    errors: list[str],
) -> None:
    prefix = f"annotation {index}"
    _validate_rubric_version(value, prefix, rubric_version, errors)
    supported_keys = {
        "is_customization",
        "intimacy_level",
        "major_plot_turn",
        "pc_category",
        "is_outfit_choice",
    }
    if not isinstance(value.get("key"), str) or not str(value["key"]).strip():
        errors.append(f"{prefix}: key must be a non-empty string")
    key = value.get("key")
    if isinstance(key, str) and key not in supported_keys:
        errors.append(f"{prefix}: key is not part of the annotation contract")
    annotation_value = value.get("value")
    if key in {"is_customization", "major_plot_turn", "is_outfit_choice"} and not (
        isinstance(annotation_value, bool) or annotation_value == "unknown"
    ):
        errors.append(f"{prefix}: {key} value must be true, false, or unknown")
    if key == "intimacy_level" and annotation_value not in {
        "L0",
        "L1",
        "L2",
        "L3T6",
        "L7A8",
        "L9A10",
        "L11A12",
        "L13",
        "L14",
        "L15",
        "HEA",
        "unknown",
    }:
        errors.append(f"{prefix}: intimacy_level value is not defined by the rubric")
    if key == "pc_category":
        _validate_pc_category_value(annotation_value, prefix, errors)
    target = value.get("target_ref")
    if not isinstance(target, str) or target not in scope_kinds:
        errors.append(f"{prefix}: target_ref does not resolve inside the StoryBundle")
    elif scope_kinds[target] != "group":
        errors.append(f"{prefix}: target_ref must identify a choice group")
    evidence = value.get("evidence")
    if not isinstance(evidence, list) or not evidence:
        errors.append(f"{prefix}: evidence must contain at least one reference")
        return
    for evidence_index, item in enumerate(evidence, 1):
        _validate_evidence(
            item,
            f"{prefix} evidence {evidence_index}",
            targets,
            errors,
        )


def _validate_evidence(
    value: Any,
    prefix: str,
    targets: Mapping[tuple[str, str], _EvidenceTarget],
    errors: list[str],
    *,
    require_source: bool = False,
) -> None:
    if not isinstance(value, Mapping):
        errors.append(f"{prefix}: reference must be an object")
        return
    line_id = value.get("line_id")
    field = value.get("field")
    target = targets.get((line_id, field)) if isinstance(line_id, str) and isinstance(field, str) else None
    if target is None:
        errors.append(f"{prefix}: line_id/field does not resolve to a populated Bundle field")
        return
    if "excerpt" not in value:
        errors.append(f"{prefix}: excerpt is required")
    elif value["excerpt"] != target.value:
        errors.append(f"{prefix}: excerpt does not exactly match the StoryBundle value")
    source = value.get("source")
    if source is None and require_source:
        errors.append(f"{prefix}: source citation is required for a published finding")
    elif source is not None:
        if not isinstance(source, Mapping):
            errors.append(f"{prefix}: source must be an object when supplied")
        else:
            expected = {
                "path": target.source_path,
                "sheet": target.sheet,
                "row": target.row,
                "cell": target.cell,
            }
            if dict(source) != expected:
                errors.append(f"{prefix}: source citation does not match the StoryBundle source map")
