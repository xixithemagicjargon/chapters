"""Self-contained Chapters StoryBundle runtime.

The public surface is deliberately small: build a StoryBundle, calculate
deterministic metrics from that bundle, and validate bundle-linked artifacts.
Excel is an input adapter for ``build_story_bundle`` only.
"""

from .bundle import (
    BundleBuildReceipt,
    ChapterConflictError,
    StoryBundleError,
    StoryBundleInputError,
    StoryBundleUsageError,
    build_story_bundle,
    load_story_bundle,
    verify_story_bundle,
)
from .docx import DocxError, DocxReceipt, render_editor_docx
from .validate import ArtifactValidationReceipt, validate_artifacts
from .metrics import MetricsError, MetricsReceipt, compute_metrics, verify_metrics

__all__ = [
    "BundleBuildReceipt",
    "ChapterConflictError",
    "StoryBundleError",
    "StoryBundleInputError",
    "StoryBundleUsageError",
    "MetricsError",
    "MetricsReceipt",
    "ArtifactValidationReceipt",
    "DocxError",
    "DocxReceipt",
    "render_editor_docx",
    "build_story_bundle",
    "compute_metrics",
    "load_story_bundle",
    "validate_artifacts",
    "verify_story_bundle",
    "verify_metrics",
]
