"""Private, read-only OOXML snapshot reader for Chapters workbooks.

The adapter deliberately accepts an in-memory byte snapshot rather than a path.
Its caller owns opening the source exactly once.  This module never discovers,
opens, updates, or saves an Excel file.
"""

from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
import math
import posixpath
import re
from typing import TypeAlias
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET
from zipfile import BadZipFile, ZipFile, ZipInfo


CellValue: TypeAlias = str | int | float | bool | None

_MAX_ARCHIVE_BYTES = 128 * 1024 * 1024
_MAX_ZIP_MEMBERS = 512
_MAX_ZIP_MEMBER_BYTES = 64 * 1024 * 1024
_MAX_ZIP_TOTAL_BYTES = 256 * 1024 * 1024
_MAX_RELATIONSHIPS_PER_PART = 2_048
_MAX_SHARED_STRINGS = 100_000
_MAX_WORKBOOK_SHEETS = 256
_MAX_WORKBOOK_CELLS = 2_000_000
_MAX_CELL_TEXT_BYTES = 1 * 1024 * 1024
_MAX_EXCEL_ROW = 1_048_576
_MAX_EXCEL_COLUMN = 16_384

_A1_RE = re.compile(r"^([A-Za-z]{1,3})([1-9][0-9]{0,6})$")
_INTEGER_RE = re.compile(r"^[+-]?[0-9]+$")
_DRIVE_RE = re.compile(r"^[A-Za-z]:")


class XlsxSnapshotError(ValueError):
    """The byte snapshot is not a safe, supported XLSX package."""

    def __init__(
        self,
        message: str,
        *,
        code: str = "workbook.invalid-xlsx",
        sheet: str | None = None,
        row: int | None = None,
        cell: str | None = None,
        observed: object | None = None,
        expected: object | None = None,
        remediation: str | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.sheet = sheet
        self.row = row
        self.cell = cell
        self.observed = observed
        self.expected = expected
        self.remediation = remediation

    def add_location(
        self,
        *,
        sheet: str | None = None,
        row: int | None = None,
        cell: str | None = None,
    ) -> XlsxSnapshotError:
        """Attach location known by an outer OOXML reader without losing the cause."""

        if self.sheet is None:
            self.sheet = sheet
        if self.row is None:
            self.row = row
        if self.cell is None:
            self.cell = cell
        return self


@dataclass(frozen=True, slots=True)
class CellSnapshot:
    sheet_name: str
    coordinate: str
    row: int
    column: int
    value: CellValue
    raw_value: str | None
    data_type: str | None
    formula: str | None


@dataclass(frozen=True, slots=True)
class SheetSnapshot:
    name: str
    state: str
    cells: tuple[CellSnapshot, ...]


@dataclass(frozen=True, slots=True)
class WorkbookSnapshot:
    sheets: tuple[SheetSnapshot, ...]


@dataclass(frozen=True, slots=True)
class _Relationship:
    relationship_id: str
    kind: str
    target: str
    external: bool


class _Package:
    """Bounded access to validated in-memory ZIP members."""

    def __init__(self, archive: ZipFile) -> None:
        infos = archive.infolist()
        if len(infos) > _MAX_ZIP_MEMBERS:
            raise XlsxSnapshotError(
                f"XLSX has too many ZIP members ({len(infos)} > {_MAX_ZIP_MEMBERS})"
            )

        members: dict[str, ZipInfo] = {}
        total_bytes = 0
        for info in infos:
            name = _validated_member_name(info.filename)
            if name in members:
                raise XlsxSnapshotError(f"XLSX has a duplicate ZIP member: {name!r}")
            if info.flag_bits & 0x1:
                raise XlsxSnapshotError(f"Encrypted ZIP member is unsupported: {name!r}")
            if info.file_size < 0 or info.file_size > _MAX_ZIP_MEMBER_BYTES:
                raise XlsxSnapshotError(
                    f"XLSX member is too large: {name!r} ({info.file_size} bytes)"
                )
            total_bytes += info.file_size
            if total_bytes > _MAX_ZIP_TOTAL_BYTES:
                raise XlsxSnapshotError(
                    "XLSX uncompressed content exceeds the safety limit"
                )
            members[name] = info

        self._archive = archive
        self._members = members

    def contains(self, name: str) -> bool:
        return name in self._members

    def read(self, name: str) -> bytes:
        info = self._members.get(name)
        if info is None:
            raise XlsxSnapshotError(f"XLSX package member is missing: {name!r}")
        try:
            with self._archive.open(info, mode="r") as handle:
                payload = handle.read(_MAX_ZIP_MEMBER_BYTES + 1)
        except (BadZipFile, OSError, RuntimeError) as error:
            raise XlsxSnapshotError(
                f"Cannot read XLSX package member {name!r}: {error}"
            ) from error
        if len(payload) > _MAX_ZIP_MEMBER_BYTES or len(payload) != info.file_size:
            raise XlsxSnapshotError(
                f"XLSX member size is invalid for {name!r}"
            )
        return payload


def read_xlsx_snapshot(payload: bytes) -> WorkbookSnapshot:
    """Decode a complete XLSX byte snapshot without accessing the filesystem."""

    if not isinstance(payload, bytes):
        raise TypeError("payload must be bytes")
    if not payload:
        raise XlsxSnapshotError(
            "XLSX snapshot is empty",
            code="workbook.empty",
            observed={"bytes": 0},
            expected={"container": "non-empty OOXML ZIP package"},
            remediation="Replace the empty file with an exported .xlsx workbook.",
        )
    if len(payload) > _MAX_ARCHIVE_BYTES:
        raise XlsxSnapshotError("XLSX snapshot exceeds the archive safety limit")

    try:
        with ZipFile(BytesIO(payload), mode="r") as archive:
            package = _Package(archive)
            workbook_part = _workbook_part(package)
            workbook_relationships = _read_relationships(
                package,
                source_part=workbook_part,
                relationships_part=_relationships_part(workbook_part),
            )
            shared_strings = _read_shared_strings(
                package, workbook_part, workbook_relationships
            )
            sheets = _read_workbook_sheets(
                package,
                workbook_part,
                workbook_relationships,
                shared_strings,
            )
            return WorkbookSnapshot(sheets=tuple(sheets))
    except XlsxSnapshotError:
        raise
    except (BadZipFile, ET.ParseError, OSError, RuntimeError, ValueError) as error:
        raise XlsxSnapshotError(f"Invalid or unreadable XLSX snapshot: {error}") from error


def _validated_member_name(raw_name: str) -> str:
    if not isinstance(raw_name, str) or not raw_name:
        raise XlsxSnapshotError("XLSX contains an empty ZIP member name")
    if (
        "\\" in raw_name
        or "\x00" in raw_name
        or raw_name.startswith("/")
        or _DRIVE_RE.match(raw_name)
    ):
        raise XlsxSnapshotError(f"Unsafe XLSX ZIP member name: {raw_name!r}")
    normalized = posixpath.normpath(raw_name)
    if normalized in {"", ".", ".."} or normalized.startswith("../"):
        raise XlsxSnapshotError(f"Unsafe XLSX ZIP member name: {raw_name!r}")
    if normalized != raw_name.rstrip("/"):
        raise XlsxSnapshotError(f"Non-canonical XLSX ZIP member name: {raw_name!r}")
    return normalized


def _workbook_part(package: _Package) -> str:
    relationships = _read_relationships(
        package,
        source_part="",
        relationships_part="_rels/.rels",
    )
    office_documents = [
        relationship
        for relationship in relationships.values()
        if relationship.kind == "officeDocument"
    ]
    if len(office_documents) != 1:
        raise XlsxSnapshotError(
            "XLSX package must contain exactly one officeDocument relationship"
        )
    relationship = office_documents[0]
    if relationship.external:
        raise XlsxSnapshotError("External workbook relationships are unsupported")
    workbook_part = _resolve_part("", relationship.target)
    if not package.contains(workbook_part):
        raise XlsxSnapshotError("The workbook relationship target is missing")
    return workbook_part


def _read_relationships(
    package: _Package,
    *,
    source_part: str,
    relationships_part: str,
) -> dict[str, _Relationship]:
    root = _read_xml(package, relationships_part)
    relationships: dict[str, _Relationship] = {}
    for element in root.iter():
        if _local_name(element.tag) != "Relationship":
            continue
        relationship_id = element.attrib.get("Id")
        relationship_type = element.attrib.get("Type")
        target = element.attrib.get("Target")
        if not relationship_id or not relationship_type or not target:
            raise XlsxSnapshotError(
                f"Malformed relationship in {relationships_part!r}"
            )
        if relationship_id in relationships:
            raise XlsxSnapshotError(
                f"Duplicate relationship ID {relationship_id!r} in {relationships_part!r}"
            )
        if len(relationships) >= _MAX_RELATIONSHIPS_PER_PART:
            raise XlsxSnapshotError(
                f"Too many relationships in {relationships_part!r}"
            )
        external = element.attrib.get("TargetMode", "Internal").casefold() == "external"
        if not external:
            # Validate the target now, even if its relationship kind is unused.
            _resolve_part(source_part, target)
        relationships[relationship_id] = _Relationship(
            relationship_id=relationship_id,
            kind=relationship_type.rstrip("/").rsplit("/", 1)[-1],
            target=target,
            external=external,
        )
    return relationships


def _read_shared_strings(
    package: _Package,
    workbook_part: str,
    relationships: dict[str, _Relationship],
) -> tuple[str, ...]:
    candidates = [
        relationship
        for relationship in relationships.values()
        if relationship.kind == "sharedStrings" and not relationship.external
    ]
    if len(candidates) > 1:
        raise XlsxSnapshotError("Workbook has multiple sharedStrings relationships")
    if not candidates:
        return ()
    shared_part = _resolve_part(workbook_part, candidates[0].target)
    root = _read_xml(package, shared_part)
    values: list[str] = []
    for element in root.iter():
        if _local_name(element.tag) != "si":
            continue
        if len(values) >= _MAX_SHARED_STRINGS:
            raise XlsxSnapshotError("Shared string count exceeds the safety limit")
        value = _rich_text(element)
        _validate_text_size(value, "shared string")
        values.append(value)
    return tuple(values)


def _read_workbook_sheets(
    package: _Package,
    workbook_part: str,
    relationships: dict[str, _Relationship],
    shared_strings: tuple[str, ...],
) -> list[SheetSnapshot]:
    root = _read_xml(package, workbook_part)
    declarations = [
        element for element in root.iter() if _local_name(element.tag) == "sheet"
    ]
    if not declarations:
        raise XlsxSnapshotError("Workbook contains no sheets")
    if len(declarations) > _MAX_WORKBOOK_SHEETS:
        raise XlsxSnapshotError("Workbook sheet count exceeds the safety limit")

    names: set[str] = set()
    snapshots: list[SheetSnapshot] = []
    total_cells = 0
    for declaration in declarations:
        name = declaration.attrib.get("name")
        relationship_id = _attribute_by_local_name(declaration, "id")
        state = declaration.attrib.get("state", "visible")
        if not name or not relationship_id:
            raise XlsxSnapshotError("Workbook has a malformed sheet declaration")
        if name in names:
            raise XlsxSnapshotError(f"Workbook has a duplicate sheet name: {name!r}")
        if state not in {"visible", "hidden", "veryHidden"}:
            raise XlsxSnapshotError(f"Workbook sheet {name!r} has invalid state {state!r}")
        names.add(name)
        relationship = relationships.get(relationship_id)
        if relationship is None:
            raise XlsxSnapshotError(
                f"Workbook sheet {name!r} references an unknown relationship"
            )
        if relationship.external or relationship.kind != "worksheet":
            raise XlsxSnapshotError(
                f"Workbook sheet {name!r} is not an internal worksheet"
            )
        sheet_part = _resolve_part(workbook_part, relationship.target)
        cells = _read_worksheet_cells(
            package,
            sheet_part,
            sheet_name=name,
            shared_strings=shared_strings,
            remaining_cell_budget=_MAX_WORKBOOK_CELLS - total_cells,
        )
        total_cells += len(cells)
        snapshots.append(SheetSnapshot(name=name, state=state, cells=tuple(cells)))
    return snapshots


def _read_worksheet_cells(
    package: _Package,
    sheet_part: str,
    *,
    sheet_name: str,
    shared_strings: tuple[str, ...],
    remaining_cell_budget: int,
) -> list[CellSnapshot]:
    payload = package.read(sheet_part)
    _reject_unsafe_xml(payload, sheet_part)
    cells: list[CellSnapshot] = []
    previous_row = 0
    try:
        iterator = ET.iterparse(BytesIO(payload), events=("end",))
        for _event, element in iterator:
            if _local_name(element.tag) != "row":
                continue
            row_number = _positive_int(element.attrib.get("r"), "worksheet row")
            if row_number is None:
                row_number = previous_row + 1
            if not 1 <= row_number <= _MAX_EXCEL_ROW:
                raise XlsxSnapshotError(f"Worksheet row is outside Excel limits: {row_number}")
            if row_number <= previous_row:
                raise XlsxSnapshotError("Worksheet rows are not in strictly increasing order")
            previous_row = row_number
            previous_column = 0
            for cell_element in element:
                if _local_name(cell_element.tag) != "c":
                    continue
                raw_coordinate = cell_element.attrib.get("r")
                if raw_coordinate is None:
                    column = previous_column + 1
                    coordinate = f"{_column_letters(column)}{row_number}"
                else:
                    parsed_row, column, coordinate = _parse_coordinate(raw_coordinate)
                    if parsed_row != row_number:
                        raise XlsxSnapshotError(
                            f"Cell {coordinate!r} conflicts with its row declaration"
                        )
                if column <= previous_column:
                    raise XlsxSnapshotError(
                        f"Worksheet cells are not ordered in row {row_number}"
                    )
                previous_column = column
                # Rows and columns are both validated as strictly increasing
                # above, so no two cells can share a coordinate; the former
                # duplicate set held one string per cell for nothing.
                if len(cell_element) == 0:
                    # A cell with no child element carries no value, no
                    # formula and no inline text, so there is nothing to
                    # snapshot. Excel writes one of these for every styled
                    # but empty cell: 580,491 of them against 3,303 real
                    # ones in a single HMQ sheet, and every consumer filters
                    # them out again through _meaningful() or _story_value().
                    # Skipping them is what makes prepare 6x faster.
                    continue
                if len(cells) >= remaining_cell_budget:
                    raise XlsxSnapshotError("Workbook cell count exceeds the safety limit")
                try:
                    decoded = _decode_cell(
                        cell_element,
                        sheet_name=sheet_name,
                        coordinate=coordinate,
                        row=row_number,
                        column=column,
                        shared_strings=shared_strings,
                    )
                except XlsxSnapshotError as error:
                    error.add_location(sheet=sheet_name, row=row_number, cell=coordinate)
                    raise
                cells.append(decoded)
            element.clear()
    except XlsxSnapshotError as error:
        error.add_location(sheet=sheet_name)
        raise
    except ET.ParseError as error:
        raise XlsxSnapshotError(
            f"Invalid XML in worksheet {sheet_part!r}: {error}",
            sheet=sheet_name,
        ) from error
    return cells


def _decode_cell(
    element: ET.Element,
    *,
    sheet_name: str,
    coordinate: str,
    row: int,
    column: int,
    shared_strings: tuple[str, ...],
) -> CellSnapshot:
    data_type = element.attrib.get("t")
    if data_type not in {None, "n", "s", "b", "str", "inlineStr", "e", "d"}:
        raise XlsxSnapshotError(
            f"Cell {coordinate!r} has unsupported data type {data_type!r}"
        )
    formula_element = None
    value_element = None
    inline_element = None
    for child in element:
        name = _local_name(child.tag)
        if name == "v":
            if value_element is None:
                value_element = child
        elif name == "f":
            if formula_element is None:
                formula_element = child
        elif name == "is":
            if inline_element is None:
                inline_element = child
    formula = None if formula_element is None else (formula_element.text or "")

    if data_type == "inlineStr":
        value = _rich_text(inline_element) if inline_element is not None else ""
        raw_value = value
    else:
        raw_value = value_element.text if value_element is not None else None
        value = _decode_value(
            raw_value,
            data_type=data_type,
            coordinate=coordinate,
            shared_strings=shared_strings,
        )
    if isinstance(value, str):
        _validate_text_size(value, f"cell {coordinate}")
    if formula is not None:
        _validate_text_size(formula, f"formula {coordinate}")
    return CellSnapshot(
        sheet_name=sheet_name,
        coordinate=coordinate,
        row=row,
        column=column,
        value=value,
        raw_value=raw_value,
        data_type=data_type,
        formula=formula,
    )


def _decode_value(
    raw_value: str | None,
    *,
    data_type: str | None,
    coordinate: str,
    shared_strings: tuple[str, ...],
) -> CellValue:
    if raw_value is None:
        return None
    if data_type == "s":
        try:
            index = int(raw_value)
        except ValueError as error:
            raise XlsxSnapshotError(
                f"Cell {coordinate!r} has an invalid shared-string index"
            ) from error
        if index < 0 or index >= len(shared_strings):
            raise XlsxSnapshotError(
                f"Cell {coordinate!r} references a missing shared string"
            )
        return shared_strings[index]
    if data_type == "b":
        if raw_value == "0":
            return False
        if raw_value == "1":
            return True
        raise XlsxSnapshotError(f"Cell {coordinate!r} has an invalid Boolean value")
    if data_type in {"str", "e", "d"}:
        return raw_value
    if raw_value == "":
        return None
    if _INTEGER_RE.fullmatch(raw_value):
        try:
            return int(raw_value)
        except ValueError as error:
            raise XlsxSnapshotError(
                f"Cell {coordinate!r} has an invalid numeric value"
            ) from error
    try:
        number = float(raw_value)
    except ValueError as error:
        raise XlsxSnapshotError(
            f"Cell {coordinate!r} has an invalid numeric value"
        ) from error
    if not math.isfinite(number):
        raise XlsxSnapshotError(f"Cell {coordinate!r} has a non-finite number")
    return number


def _read_xml(package: _Package, member: str) -> ET.Element:
    payload = package.read(member)
    _reject_unsafe_xml(payload, member)
    try:
        return ET.fromstring(payload)
    except ET.ParseError as error:
        raise XlsxSnapshotError(f"Invalid XML in {member!r}: {error}") from error


def _reject_unsafe_xml(payload: bytes, member: str) -> None:
    upper = payload.upper()
    if b"<!DOCTYPE" in upper or b"<!ENTITY" in upper:
        raise XlsxSnapshotError(f"DTD/entity declarations are forbidden in {member!r}")


def _resolve_part(source_part: str, raw_target: str) -> str:
    if not raw_target or "\\" in raw_target or "\x00" in raw_target:
        raise XlsxSnapshotError(f"Unsafe internal relationship target: {raw_target!r}")
    parsed = urlsplit(raw_target)
    if parsed.scheme or parsed.netloc or parsed.query or parsed.fragment:
        raise XlsxSnapshotError(f"Unsafe internal relationship target: {raw_target!r}")
    target = unquote(parsed.path)
    if not target or "\\" in target or "\x00" in target or _DRIVE_RE.match(target):
        raise XlsxSnapshotError(f"Unsafe internal relationship target: {raw_target!r}")
    if target.startswith("/"):
        combined = target[1:]
    else:
        combined = posixpath.join(posixpath.dirname(source_part), target)
    normalized = posixpath.normpath(combined)
    if (
        normalized in {"", ".", ".."}
        or normalized.startswith("../")
        or normalized.startswith("/")
    ):
        raise XlsxSnapshotError(
            f"Internal relationship target escapes the package: {raw_target!r}"
        )
    return normalized


def _relationships_part(source_part: str) -> str:
    directory = posixpath.dirname(source_part)
    filename = posixpath.basename(source_part)
    return posixpath.join(directory, "_rels", f"{filename}.rels")


def _parse_coordinate(coordinate: str) -> tuple[int, int, str]:
    # Hand-rolled rather than regex: this runs once per cell, so on a full
    # book it ran over a million times. Behaviour matches _A1_RE exactly,
    # including the uppercase normalisation of the column letters.
    column = 0
    index = 0
    length = len(coordinate)
    while index < length:
        character = coordinate[index]
        if "A" <= character <= "Z":
            column = column * 26 + (ord(character) - 64)
        elif "a" <= character <= "z":
            column = column * 26 + (ord(character) - 96)
        else:
            break
        index += 1
    if column == 0 or index == length:
        raise XlsxSnapshotError(f"Invalid worksheet cell coordinate: {coordinate!r}")
    row = 0
    while index < length:
        character = coordinate[index]
        if not "0" <= character <= "9":
            raise XlsxSnapshotError(f"Invalid worksheet cell coordinate: {coordinate!r}")
        row = row * 10 + (ord(character) - 48)
        index += 1
    if row == 0:
        raise XlsxSnapshotError(f"Invalid worksheet cell coordinate: {coordinate!r}")
    if row > _MAX_EXCEL_ROW or column > _MAX_EXCEL_COLUMN:
        raise XlsxSnapshotError(f"Cell coordinate is outside Excel limits: {coordinate!r}")
    return row, column, f"{_column_letters(column)}{row}"


def _column_letters(column: int) -> str:
    if not 1 <= column <= _MAX_EXCEL_COLUMN:
        raise XlsxSnapshotError(f"Worksheet column is outside Excel limits: {column}")
    result: list[str] = []
    while column:
        column, remainder = divmod(column - 1, 26)
        result.append(chr(ord("A") + remainder))
    return "".join(reversed(result))


def _positive_int(raw: str | None, label: str) -> int | None:
    if raw is None:
        return None
    if not raw.isdigit() or raw.startswith("0"):
        raise XlsxSnapshotError(f"Invalid {label}: {raw!r}")
    value = int(raw)
    if value < 1:
        raise XlsxSnapshotError(f"Invalid {label}: {raw!r}")
    return value


def _rich_text(element: ET.Element | None) -> str:
    if element is None:
        return ""
    parts: list[str] = []

    def visit(node: ET.Element) -> None:
        name = _local_name(node.tag)
        if name == "rPh":
            return
        if name == "t":
            parts.append(node.text or "")
            return
        for child in node:
            visit(child)

    visit(element)
    return "".join(parts)


def _validate_text_size(value: str, label: str) -> None:
    if len(value.encode("utf-8")) > _MAX_CELL_TEXT_BYTES:
        raise XlsxSnapshotError(f"{label} exceeds the text safety limit")


def _first_child(element: ET.Element, local_name: str) -> ET.Element | None:
    for child in element:
        if _local_name(child.tag) == local_name:
            return child
    return None


def _attribute_by_local_name(element: ET.Element, local_name: str) -> str | None:
    for qualified_name, value in element.attrib.items():
        if _local_name(qualified_name) == local_name:
            return value
    return None


_LOCAL_NAME_CACHE: dict[str, str] = {}


def _local_name(qualified_name: str) -> str:
    cached = _LOCAL_NAME_CACHE.get(qualified_name)
    if cached is None:
        cached = qualified_name.rsplit("}", 1)[-1]
        _LOCAL_NAME_CACHE[qualified_name] = cached
    return cached


__all__ = [
    "CellSnapshot",
    "SheetSnapshot",
    "WorkbookSnapshot",
    "XlsxSnapshotError",
    "read_xlsx_snapshot",
]
