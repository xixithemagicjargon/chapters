"""Build and load the immutable, self-contained Chapters StoryBundle.

This module owns the one-way ingestion seam from XLSX snapshots to files that
an Agent can navigate with ordinary read/search/shell tools.  Downstream code
never receives an XLSX path and never needs the source workbooks to exist.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import tempfile
from typing import Any, Iterable, Mapping, Sequence
import unicodedata

from ._xlsx import (
    CellSnapshot,
    SheetSnapshot,
    WorkbookSnapshot,
    XlsxSnapshotError,
    read_xlsx_snapshot,
)


FORMAT = "chapters.story-bundle"
FORMAT_VERSION = "0.1.0"
PARSER_NAME = "chapters-xlsx"
PARSER_VERSION = "0.1.0"
XLSX_MEDIA_TYPE = (
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
)

_CANONICAL_FIELDS = (
    "dialogue_type",
    "line",
    "special_type",
    "role_id",
    "content",
    "face_id",
    "background_id",
    "thought_bubble",
    "clothing",
    "font",
    "background_music",
    "background_panning",
    "sound_effects",
    "animation",
    "notes",
)
_HEADER_ALIASES: Mapping[str, tuple[str, ...]] = {
    "dialogue_type": ("dialogue_type", "dialogue type", "id", "类型", "对话类型"),
    "line": ("line",),
    "special_type": ("special_type", "special type", "text_type", "text type", "特殊类型"),
    "role_id": (
        "role_id",
        "role id",
        "character_id",
        "character id",
        "character",
        "角色名",
    ),
    "content": ("content", "script", "对话内容"),
    "face_id": ("face_id", "face id", "emotion", "emotions", "表情"),
    "background_id": (
        "background_id",
        "background id",
        "background",
        "backgrounds",
        "背景",
    ),
    "thought_bubble": ("thought_bubble", "thought bubble", "是否想象"),
    "clothing": ("clothing", "动态形象"),
    "font": ("font", "字体"),
    "background_music": ("background_music", "background music", "bgm", "背景音乐"),
    "background_panning": (
        "background_panning",
        "background panning",
        "panning",
        "是否开启场景环绕",
    ),
    "sound_effects": (
        "sound_effects",
        "sound effects",
        "sound_effect",
        "sound effect",
        "sfx",
        "音效",
    ),
    "animation": ("animation", "背景特效"),
    "notes": ("notes", "note", "备注"),
}
_HEADER_NOTE_RE = re.compile(r"[（(][^（()）]*[)）]")
_HEADER_BLOCK_SPAN = 4
_ALIAS_TO_FIELD: dict[str, str] = {}
_REQUIRED_FIELDS = frozenset(("dialogue_type", "line", "content"))
# The words a Dialogue Type cell holds when it is not a Choice marker.  Used
# to recognize the column by its contents, and to confirm the labelled one.
_DIALOGUE_TYPE_WORDS = frozenset(
    ("text", "title", "blurb", "direction", "stage direction", "transition")
)
# Below this many story rows a sheet is too small to read a column's shape
# from: a handful of rows can look like anything.
_PROFILE_MINIMUM_ROWS = 20
_TYPE_COLUMN_FILLED = 0.5
_TYPE_COLUMN_WORDS = 0.5
_TYPE_COLUMN_WORDS_TO_INFER = 0.8
# How much of a sheet the script column covers varies by house style: HMQ
# fills it on every row, RKS on 43-51% because half its rows only change a
# background or a track.  So the script column is recognized by being far
# wordier than its neighbours, never by how much of the sheet it fills and
# never by an absolute length -- a chapter of terse lines is still a chapter.
# Coverage is only used to keep sparse columns out of the comparison.
_CONTENT_COLUMN_FILLED = 0.25
_CONTENT_COLUMN_EMPTY = 0.05
_CONTENT_COLUMN_MARGIN = 2.0
_CONTENT_COLUMN_OUTCLASSED = 3.0
_LINE_COLUMN_LONGEST = 32
_LINE_COLUMN_ON_CHOICES = 0.5
_LINE_COLUMN_ON_CHOICES_TO_WARN = 0.2
_AUXILIARY_SHEETS = frozenset(("option", "options", "template", "templates", "选项"))
_METADATA_TYPES = {
    "title": "title",
    "blurb": "blurb",
    "trigger warning": "trigger_warning",
    "trigger_warning": "trigger_warning",
    "stats": "stats",
}
_CHOICE_RE = re.compile(
    r"^\s*(?P<vip>VIP\s+)?(?P<premium>Premium\s+)?"
    r"(?P<subs>(?:Sub\s+)*)Choice\s+(?P<index>[1-9]\d*)\s*$",
    re.IGNORECASE,
)
_SHEET_CHAPTER_RE = re.compile(
    r"(?i)(?:chapter|ch\.?)[\s_-]*(?P<number>[1-9]\d*)"
)
_BARE_SHEET_CHAPTER_RE = re.compile(
    r"(?i)^\s*(?:copy\s+of\s+)?(?P<number>[1-9]\d*)\s*$"
)
_FILE_RANGE_RE = re.compile(
    r"(?<!\d)(?P<start>[1-9]\d*)\s*[-–—_]\s*(?P<end>[1-9]\d*)(?!\d)"
)
_FILE_SINGLE_RE = re.compile(r"(?<!\d)(?P<number>[1-9]\d*)(?!\d)")
_LABEL_ONLY_RE = re.compile(r"\s*(?P<label>[a-z]+)\s*(?:[:.)-])?\s*", re.IGNORECASE)
_COMMERCIAL_PREFIX = r"(?:(?P<label>[a-z]+)\s*(?:[:.)-]\s*)?)?"
_REWARD_RE = re.compile(
    rf"\s*{_COMMERCIAL_PREFIX}\+\s*(?P<amount>\d+)\s*(?P<unit>gems?)?\s*",
    re.IGNORECASE,
)
_FREE_RE = re.compile(
    rf"\s*{_COMMERCIAL_PREFIX}(?P<free>free|0)\s*(?P<unit>gems?)?\s*",
    re.IGNORECASE,
)
_PRICE_RE = re.compile(
    rf"\s*{_COMMERCIAL_PREFIX}(?P<sign>-\s*)?(?P<amount>\d+)\s*"
    rf"(?P<unit>gems?)?\s*",
    re.IGNORECASE,
)
_INTEGER_CANDIDATE_RE = re.compile(r"(?<![\d.])\d+(?![\d.])")
_OUTFIT_MARKER_PHRASES = (
    "insert outfit choice",
    "i'll wear",
    "i will wear",
    "i'd wear",
    "i should wear",
)


def _is_outfit_marker(value: Any) -> bool:
    """True when a line reads as the writer's outfit-choice marker.

    Matching is phrase containment, not an exact marker string, so an ordinary
    line of dialogue that happens to contain one of these phrases counts too.
    The rules owner chose that trade-off knowingly; `classify.outfit-choice`
    is where a disputed group gets an explicit editorial judgment.
    """
    text = _normalized_text(value).replace("\u2019", "'")
    return any(phrase in text for phrase in _OUTFIT_MARKER_PHRASES)


class StoryBundleError(ValueError):
    """Base class for a failure that must not publish a ready manifest."""


class StoryBundleUsageError(StoryBundleError):
    """The caller supplied an internally inconsistent build invocation."""


class StoryBundleInputError(StoryBundleError):
    """A source problem an editor can fix without changing the Runtime."""

    def __init__(self, message: str, *, issues: Sequence[Mapping[str, Any]]) -> None:
        normalized = tuple(dict(issue) for issue in issues)
        if not normalized:
            raise ValueError("StoryBundleInputError requires at least one issue")
        self.issues = normalized
        super().__init__(message)


class SourceSelectionError(StoryBundleInputError):
    """A selected source is not a safe XLSX file inside the Local Project."""


class WorkbookParseError(StoryBundleInputError):
    """An XLSX snapshot cannot be safely interpreted as Chapters data."""


class StoryBundleExistsError(StoryBundleError):
    """The target path exists but is not the same completed StoryBundle."""


class ChapterConflictError(StoryBundleError):
    """Multiple selected sources contain different versions of one chapter."""

    def __init__(self, conflicts: Sequence[Mapping[str, Any]]) -> None:
        self.conflicts = tuple(dict(item) for item in conflicts)
        chapters = ", ".join(str(item["chapter_number"]) for item in conflicts)
        super().__init__(f"Conflicting source versions need a choice for chapter(s): {chapters}")


def _input_issue(
    code: str,
    *,
    remediation: str,
    source: str | None = None,
    sheet: str | None = None,
    row: int | None = None,
    cell: str | None = None,
    observed: Any | None = None,
    expected: Any | None = None,
) -> dict[str, Any]:
    issue: dict[str, Any] = {
        "code": code,
        "user_actionable": True,
        "remediation": remediation,
    }
    for key, value in (
        ("source", source),
        ("sheet", sheet),
        ("row", row),
        ("cell", cell),
        ("observed", observed),
        ("expected", expected),
    ):
        if value is not None:
            issue[key] = value
    return issue


@dataclass(frozen=True, slots=True)
class BundleBuildReceipt:
    """Small result returned to the CLI/Agent after a successful build."""

    status: str
    bundle_path: Path
    manifest_path: Path
    bundle_id: str
    chapters: tuple[int | str, ...]
    diagnostic_counts: Mapping[str, int]

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "bundle_path": str(self.bundle_path),
            "manifest_path": str(self.manifest_path),
            "bundle_id": self.bundle_id,
            "chapters": list(self.chapters),
            "diagnostics": dict(self.diagnostic_counts),
            "read_first": str(self.manifest_path),
        }


@dataclass(frozen=True, slots=True)
class StoryBundle:
    """Validated manifest and path; all referenced data remains file-backed."""

    path: Path
    manifest: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class _HeaderMap:
    row: int
    columns: Mapping[str, int]
    labels: Mapping[str, str]
    inferred: frozenset[str] = frozenset()


@dataclass(frozen=True, slots=True)
class _ColumnProfile:
    """What one column actually holds below the header."""

    filled: int
    coverage: float
    average_length: float
    longest: int
    type_like: float
    rows: frozenset[int]


@dataclass(frozen=True, slots=True)
class _LoadedSource:
    source_id: str
    path: Path
    relative_path: str
    size: int
    digest: str
    workbook: WorkbookSnapshot


@dataclass(slots=True)
class _ChapterCandidate:
    chapter_id: str
    chapter_number: int | str
    source: _LoadedSource
    sheet: SheetSnapshot
    chapter: dict[str, Any]
    lines: list[dict[str, Any]]
    choices: dict[str, Any]
    source_map: list[dict[str, Any]]
    diagnostics: list[dict[str, Any]]
    content_digest: str


@dataclass(frozen=True, slots=True)
class _ChoiceMarker:
    depth: int
    branch_index: int
    premium: bool
    vip: bool


def build_story_bundle(
    source_paths: Sequence[str | os.PathLike[str]],
    *,
    project_root: str | os.PathLike[str],
    output_directory: str | os.PathLike[str] | None = None,
    chapter_sources: Mapping[int, str] | None = None,
    book_title: str | None = None,
) -> BundleBuildReceipt:
    """Parse explicit XLSX sources once and publish one immutable StoryBundle.

    ``chapter_sources`` resolves content conflicts by natural chapter number and
    the stable candidate ID returned with the conflict.  It is a user choice,
    not a capability token; every resulting fact remains bound to the newly
    read source SHA in the manifest.
    """

    root = _project_root(project_root)
    paths = _source_paths(source_paths, root)
    selected_sources = dict(chapter_sources or {})
    if any(not isinstance(number, int) or number < 1 for number in selected_sources):
        raise StoryBundleUsageError(
            "chapter source selections require positive chapter numbers"
        )
    loaded = _read_sources(paths, root)
    diagnostics: list[dict[str, Any]] = []
    candidates: list[_ChapterCandidate] = []
    workbook_issues: list[dict[str, Any]] = []
    unresolved_ordinal = 0

    for source in loaded:
        script_sheets, sheet_diagnostics = _script_sheets(source)
        diagnostics.extend(sheet_diagnostics)
        if not script_sheets:
            workbook_issues.extend(
                _missing_script_sheet_issues(source, sheet_diagnostics)
            )
            continue
        assignments, chapter_diagnostics = _chapter_assignments(
            source.path.name, [sheet for sheet, _header in script_sheets]
        )
        diagnostics.extend(
            _with_source(diagnostic, source=source) for diagnostic in chapter_diagnostics
        )
        for sheet, header in script_sheets:
            chapter_number = assignments[sheet.name]
            if chapter_number is None:
                unresolved_ordinal += 1
                chapter_key: int | str = f"unresolved-{unresolved_ordinal:03d}"
            else:
                chapter_key = chapter_number
            chapter_id = _chapter_id(chapter_key)
            candidate = _parse_chapter(
                source=source,
                sheet=sheet,
                header=header,
                chapter_id=chapter_id,
                chapter_number=chapter_key,
            )
            candidates.append(candidate)

    if workbook_issues:
        raise WorkbookParseError(
            "One or more workbooks have no visible Chapters script sheet",
            issues=workbook_issues,
        )

    chosen, duplicate_diagnostics = _choose_chapters(
        candidates, chapter_sources=selected_sources
    )
    diagnostics.extend(duplicate_diagnostics)
    chosen.sort(key=_chapter_sort_key)

    identity = {
        "format_version": FORMAT_VERSION,
        "parser_version": PARSER_VERSION,
        "book_title": book_title,
        "sources": [
            {
                "path": source.relative_path,
                "sha256": source.digest,
                "bytes": source.size,
            }
            for source in loaded
        ],
        "chapters": [
            {
                "chapter_id": candidate.chapter_id,
                "content_sha256": candidate.content_digest,
                "source_id": candidate.source.source_id,
                "sheet": candidate.sheet.name,
            }
            for candidate in chosen
        ],
        "chapter_sources": {
            str(number): path for number, path in sorted(selected_sources.items())
        },
    }
    bundle_id = f"sb-{_json_digest(identity)[:16]}"
    bundle_path = _target_bundle_path(root, bundle_id, output_directory)
    if bundle_path.exists():
        try:
            existing = load_story_bundle(bundle_path)
        except StoryBundleError as error:
            raise StoryBundleExistsError(
                f"Output target exists but is not a complete StoryBundle: {bundle_path}"
            ) from error
        if existing.manifest.get("bundle_id") != bundle_id:
            raise StoryBundleExistsError(
                f"Output directory already contains a different bundle: {bundle_path}"
            )
        return _receipt("reused", existing.path, existing.manifest)

    bundle_path.parent.mkdir(parents=True, exist_ok=True)
    working_path = Path(
        tempfile.mkdtemp(prefix=".story-bundle-build-", dir=bundle_path.parent)
    )
    (working_path / "chapters").mkdir()
    diagnostic_records = _number_diagnostics(diagnostics)
    diagnostic_counts = dict(Counter(item["severity"] for item in diagnostic_records))

    chapter_entries: list[dict[str, Any]] = []
    try:
        for order, candidate in enumerate(chosen, 1):
            candidate.chapter["order"] = order
            chapter_dir = working_path / "chapters" / candidate.chapter_id
            chapter_dir.mkdir()
            chapter_file = _write_json(
                chapter_dir / "chapter.json", candidate.chapter, root=working_path
            )
            lines_file = _write_ndjson(
                chapter_dir / "lines.ndjson", candidate.lines, root=working_path
            )
            choices_file = _write_json(
                chapter_dir / "choices.json", candidate.choices, root=working_path
            )
            source_map_file = _write_ndjson(
                chapter_dir / "source-map.ndjson", candidate.source_map, root=working_path
            )
            chapter_diagnostic_ids = [
                item["diagnostic_id"]
                for item in diagnostic_records
                if item.get("chapter_id") == candidate.chapter_id
            ]
            chapter_entries.append(
                {
                    "chapter_id": candidate.chapter_id,
                    "number": candidate.chapter_number,
                    "order": order,
                    "title": candidate.chapter.get("title"),
                    "source_id": candidate.source.source_id,
                    "sheet": candidate.sheet.name,
                    "content_sha256": candidate.content_digest,
                    "structure_status": candidate.choices["structure_status"],
                    "counts": {
                        "lines": len(candidate.lines),
                        "choice_groups": len(candidate.choices["groups"]),
                        "branches": sum(
                            len(group["branches"])
                            for group in candidate.choices["groups"]
                        ),
                        "max_depth": max(
                            (group["depth"] for group in candidate.choices["groups"]),
                            default=0,
                        ),
                    },
                    "diagnostic_ids": chapter_diagnostic_ids,
                    "files": {
                        "chapter": chapter_file,
                        "lines": lines_file,
                        "choices": choices_file,
                        "source_map": source_map_file,
                    },
                }
            )

        diagnostics_file = _write_ndjson(
            working_path / "diagnostics.ndjson", diagnostic_records, root=working_path
        )
        manifest = {
            "format": FORMAT,
            "format_version": FORMAT_VERSION,
            "bundle_id": bundle_id,
            "status": "ready",
            "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "parser": {"name": PARSER_NAME, "version": PARSER_VERSION},
            "book": {"title": book_title},
            "chapter_sources": identity["chapter_sources"],
            "sources": [
                {
                    "source_id": source.source_id,
                    "kind": "xlsx",
                    "path": source.relative_path,
                    "sha256": source.digest,
                    "bytes": source.size,
                    "media_type": XLSX_MEDIA_TYPE,
                }
                for source in loaded
            ],
            "chapters": chapter_entries,
            "diagnostics": {
                "path": diagnostics_file["path"],
                "sha256": diagnostics_file["sha256"],
                "bytes": diagnostics_file["bytes"],
                "counts": diagnostic_counts,
            },
        }
        _validate_manifest_data(working_path, manifest)
        _write_json(working_path / "manifest.json", manifest, root=working_path)
        _load_verified_story_bundle(working_path)
        if bundle_path.exists():
            raise StoryBundleExistsError(
                f"Output target appeared while the StoryBundle was being built: {bundle_path}"
            )
        os.replace(working_path, bundle_path)
    except BaseException:
        if working_path.exists():
            shutil.rmtree(working_path, ignore_errors=True)
        raise

    return _receipt("created", bundle_path, manifest)


def load_story_bundle(bundle_path: str | os.PathLike[str]) -> StoryBundle:
    """Load and fully validate a ready StoryBundle without consulting Excel."""

    loaded, _counts = _load_verified_story_bundle(bundle_path)
    return loaded


def _load_verified_story_bundle(
    bundle_path: str | os.PathLike[str],
) -> tuple[StoryBundle, dict[str, int]]:

    path = Path(bundle_path).resolve(strict=True)
    if not path.is_dir():
        raise StoryBundleError(f"StoryBundle path is not a directory: {path}")
    manifest_path = path / "manifest.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise StoryBundleError(f"Missing or invalid StoryBundle manifest: {manifest_path}") from error
    if not isinstance(manifest, dict):
        raise StoryBundleError(f"StoryBundle manifest is not an object: {manifest_path}")
    _validate_manifest_data(path, manifest)
    loaded = StoryBundle(path=path, manifest=manifest)
    return loaded, _verify_loaded_story_bundle(loaded)


def verify_story_bundle(
    bundle: StoryBundle | str | os.PathLike[str],
) -> dict[str, int]:
    """Validate every shard and every internal reference, using Bundle files only."""

    bundle_path = bundle.path if isinstance(bundle, StoryBundle) else bundle
    _loaded, counts = _load_verified_story_bundle(bundle_path)
    return counts


def _verify_loaded_story_bundle(loaded: StoryBundle) -> dict[str, int]:
    total_lines = 0
    total_groups = 0
    total_branches = 0
    for entry in loaded.manifest["chapters"]:
        files = entry["files"]
        chapter = _read_json_object(loaded.path / files["chapter"]["path"])
        lines = list(iter_ndjson(loaded.path / files["lines"]["path"]))
        choices = _read_json_object(loaded.path / files["choices"]["path"])
        source_map = list(iter_ndjson(loaded.path / files["source_map"]["path"]))
        chapter_id = str(entry["chapter_id"])
        if chapter.get("chapter_id") != chapter_id or choices.get("chapter_id") != chapter_id:
            raise StoryBundleError(f"Chapter shard identity mismatch for {chapter_id}")
        if chapter.get("number") != entry.get("number"):
            raise StoryBundleError(f"Chapter number mismatch for {chapter_id}")
        if chapter.get("title") != entry.get("title"):
            raise StoryBundleError(f"Chapter title mismatch for {chapter_id}")
        if chapter.get("source") != {
            "source_id": entry.get("source_id"),
            "sheet": entry.get("sheet"),
        }:
            raise StoryBundleError(f"Chapter source provenance mismatch for {chapter_id}")
        if choices.get("structure_status") != entry.get("structure_status"):
            raise StoryBundleError(
                f"Chapter structure status does not match the manifest for {chapter_id}"
            )
        _validate_chapter_records(chapter_id, lines, choices, source_map)
        content_digest = _json_digest(
            {
                "chapter": {
                    "number": chapter.get("number"),
                    "title": chapter.get("title"),
                },
                "lines": lines,
                "choices": choices,
            }
        )
        if content_digest != entry.get("content_sha256"):
            raise StoryBundleError(
                f"Chapter content digest does not match the manifest for {chapter_id}"
            )
        observed = {
            "lines": len(lines),
            "choice_groups": len(choices["groups"]),
            "branches": sum(len(group["branches"]) for group in choices["groups"]),
            "max_depth": max((group["depth"] for group in choices["groups"]), default=0),
        }
        if observed != entry.get("counts"):
            raise StoryBundleError(f"Chapter counts do not match the manifest for {chapter_id}")
        total_lines += observed["lines"]
        total_groups += observed["choice_groups"]
        total_branches += observed["branches"]
    diagnostics = list(
        iter_ndjson(loaded.path / loaded.manifest["diagnostics"]["path"])
    )
    diagnostic_ids = [item.get("diagnostic_id") for item in diagnostics]
    if any(not isinstance(item, str) for item in diagnostic_ids) or len(
        diagnostic_ids
    ) != len(set(diagnostic_ids)):
        raise StoryBundleError("StoryBundle diagnostic IDs are missing or duplicated")
    severities = [item.get("severity") for item in diagnostics]
    if any(not isinstance(item, str) or not item for item in severities):
        raise StoryBundleError("StoryBundle diagnostic severities are invalid")
    observed_diagnostic_counts = dict(Counter(severities))
    if observed_diagnostic_counts != loaded.manifest["diagnostics"].get("counts"):
        raise StoryBundleError("StoryBundle diagnostic counts do not match the manifest")
    chapter_ids = {
        str(entry["chapter_id"]) for entry in loaded.manifest["chapters"]
    }
    for diagnostic in diagnostics:
        diagnostic_chapter = diagnostic.get("chapter_id")
        if diagnostic_chapter is not None and diagnostic_chapter not in chapter_ids:
            raise StoryBundleError(
                "StoryBundle diagnostic references an unknown chapter"
            )
    for entry in loaded.manifest["chapters"]:
        expected_ids = [
            diagnostic["diagnostic_id"]
            for diagnostic in diagnostics
            if diagnostic.get("chapter_id") == entry["chapter_id"]
        ]
        if entry.get("diagnostic_ids") != expected_ids:
            raise StoryBundleError(
                "StoryBundle chapter diagnostic index does not match diagnostics for "
                f"{entry['chapter_id']}"
            )
    return {
        "chapters": len(loaded.manifest["chapters"]),
        "lines": total_lines,
        "choice_groups": total_groups,
        "branches": total_branches,
        "diagnostics": len(diagnostics),
    }


def iter_ndjson(path: Path) -> Iterable[dict[str, Any]]:
    """Yield validated object records from one Bundle NDJSON shard."""

    try:
        with path.open("r", encoding="utf-8") as handle:
            for physical_line, raw in enumerate(handle, 1):
                if not raw.strip():
                    raise StoryBundleError(f"Blank NDJSON record at {path}:{physical_line}")
                value = json.loads(raw)
                if not isinstance(value, dict):
                    raise StoryBundleError(
                        f"NDJSON record is not an object at {path}:{physical_line}"
                    )
                yield value
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise StoryBundleError(f"Invalid NDJSON in {path}: {error}") from error


def _read_json_object(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise StoryBundleError(f"Invalid JSON object: {path}") from error
    if not isinstance(value, dict):
        raise StoryBundleError(f"JSON file is not an object: {path}")
    return value


def _project_root(value: str | os.PathLike[str]) -> Path:
    try:
        root = Path(value).resolve(strict=True)
    except FileNotFoundError as error:
        raise SourceSelectionError(
            f"Local Project does not exist: {value}",
            issues=(
                _input_issue(
                    "project.not-found",
                    observed={"project_root": str(value)},
                    expected={"project_root": "existing directory"},
                    remediation="Select an existing Local Project directory.",
                ),
            ),
        ) from error
    if not root.is_dir():
        raise SourceSelectionError(
            f"Local Project is not a directory: {root}",
            issues=(
                _input_issue(
                    "project.not-directory",
                    observed={"project_root": str(root)},
                    expected={"project_root": "directory"},
                    remediation="Use the Local Project directory, not a file, as --project-root.",
                ),
            ),
        )
    return root


def _source_paths(
    values: Sequence[str | os.PathLike[str]], root: Path
) -> tuple[Path, ...]:
    if not values:
        raise StoryBundleUsageError("At least one XLSX source is required")
    paths: list[Path] = []
    seen: set[Path] = set()
    issues: list[dict[str, Any]] = []
    for value in values:
        try:
            path = Path(value)
            if not path.is_absolute():
                path = root / path
            path = path.resolve(strict=True)
        except FileNotFoundError:
            issues.append(
                _input_issue(
                    "source.not-found-or-outside-project",
                    source=str(value),
                    expected={"location": "existing file inside the Local Project"},
                    remediation="Select an existing workbook from the current Local Project.",
                )
            )
            continue
        try:
            relative = path.relative_to(root)
        except ValueError:
            issues.append(
                _input_issue(
                    "source.not-found-or-outside-project",
                    source=str(value),
                    observed={"resolved_path": str(path)},
                    expected={"location": "inside the Local Project"},
                    remediation="Move or select the workbook inside the current Local Project.",
                )
            )
            continue
        source_label = relative.as_posix()
        if path in seen:
            raise StoryBundleUsageError(
                f"Source was selected more than once: {source_label}"
            )
        if not path.is_file():
            issues.append(
                _input_issue(
                    "source.not-regular-file",
                    source=source_label,
                    expected={"source_type": "regular file"},
                    remediation="Select a regular .xlsx workbook file.",
                )
            )
            continue
        if path.suffix.casefold() != ".xlsx":
            issues.append(
                _input_issue(
                    "source.not-xlsx",
                    source=source_label,
                    observed={"extension": path.suffix},
                    expected={"extension": ".xlsx"},
                    remediation="Export or save the Chapters workbook as .xlsx and select that file.",
                )
            )
            continue
        if path.name.startswith("~$"):
            issues.append(
                _input_issue(
                    "source.office-temporary",
                    source=source_label,
                    observed={"filename": path.name},
                    expected={"filename_prefix": "not ~$"},
                    remediation="Select the saved workbook rather than the Office temporary lock file.",
                )
            )
            continue
        if "chapters-reviews" in relative.parts:
            issues.append(
                _input_issue(
                    "source.generated-review",
                    source=source_label,
                    expected={"location": "outside chapters-reviews/"},
                    remediation="Select an original workbook outside the generated review directory.",
                )
            )
            continue
        seen.add(path)
        paths.append(path)
    if issues:
        raise SourceSelectionError(
            "One or more selected sources cannot be used",
            issues=issues,
        )
    return tuple(sorted(paths, key=lambda item: item.relative_to(root).as_posix().casefold()))


def _read_sources(paths: Sequence[Path], root: Path) -> tuple[_LoadedSource, ...]:
    loaded: list[_LoadedSource] = []
    issues: list[dict[str, Any]] = []
    for ordinal, path in enumerate(paths, 1):
        try:
            flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
            descriptor = os.open(path, flags)
            with os.fdopen(descriptor, "rb") as handle:
                before = os.fstat(handle.fileno())
                if not stat.S_ISREG(before.st_mode):
                    source_label = path.relative_to(root).as_posix()
                    raise SourceSelectionError(
                        f"Source is not a regular file: {path}",
                        issues=(
                            _input_issue(
                                "source.not-regular-file",
                                source=source_label,
                                expected={"source_type": "regular file"},
                                remediation="Select a regular .xlsx workbook file.",
                            ),
                        ),
                    )
                payload = handle.read()
                after = os.fstat(handle.fileno())
            if (
                before.st_dev,
                before.st_ino,
                before.st_size,
                before.st_mtime_ns,
            ) != (
                after.st_dev,
                after.st_ino,
                after.st_size,
                after.st_mtime_ns,
            ):
                raise OSError(f"Source changed while it was read: {path}")
            workbook = read_xlsx_snapshot(payload)
        except XlsxSnapshotError as error:
            source_label = path.relative_to(root).as_posix()
            issues.append(
                _input_issue(
                    error.code,
                    source=source_label,
                    sheet=error.sheet,
                    row=error.row,
                    cell=error.cell,
                    observed=error.observed or {"bytes": len(payload)},
                    expected=error.expected
                    or {"container": "valid, supported OOXML ZIP package"},
                    remediation=error.remediation
                    or "Re-export the workbook as a valid .xlsx file and try again.",
                )
            )
            continue
        loaded.append(
            _LoadedSource(
                source_id=f"src-{ordinal:03d}",
                path=path,
                relative_path=path.relative_to(root).as_posix(),
                size=len(payload),
                digest=sha256(payload).hexdigest(),
                workbook=workbook,
            )
        )
    if issues:
        raise WorkbookParseError(
            "One or more XLSX sources could not be safely read",
            issues=issues,
        )
    return tuple(loaded)


def _script_sheets(
    source: _LoadedSource,
) -> tuple[list[tuple[SheetSnapshot, _HeaderMap]], list[dict[str, Any]]]:
    found: list[tuple[SheetSnapshot, _HeaderMap]] = []
    diagnostics: list[dict[str, Any]] = []
    for sheet in source.workbook.sheets:
        if sheet.name.strip().casefold() in _AUXILIARY_SHEETS:
            # A sheet called Templates is a template even when it parses
            # cleanly: RKS keeps one full of specimen rows, and reading it as
            # a chapter added 20 choice groups of scaffolding to the audit.
            continue
        header = _detect_header(sheet)
        if header is not None:
            if sheet.state.strip().casefold() == "visible":
                conflicts = _header_conflicts(sheet, header)
                blocking = [item for item in conflicts if item["severity"] == "error"]
                if blocking:
                    diagnostics.append(
                        _with_source(
                            {
                                "severity": "warning",
                                "code": "workbook.header-contradicts-data",
                                "message": "A sheet's column labels do not match what those columns hold.",
                                "sheet": sheet.name,
                                "user_actionable": True,
                                "impact": "The sheet was excluded; every count would have been read from the wrong column.",
                                "details": {
                                    "header_row": header.row,
                                    "columns": blocking,
                                },
                            },
                            source=source,
                        )
                    )
                    continue
                for conflict in conflicts:
                    diagnostics.append(
                        _with_source(
                            {
                                "severity": "warning",
                                "code": "workbook.header-column-suspect",
                                "message": "A column's contents do not look like what its label says.",
                                "sheet": sheet.name,
                                "user_actionable": True,
                                "impact": "Confirm the column before relying on the checks that read it.",
                                "details": conflict,
                            },
                            source=source,
                        )
                    )
                if header.inferred:
                    diagnostics.append(
                        _with_source(
                            {
                                "severity": "warning",
                                "code": "workbook.header-column-inferred",
                                "message": "A required column has no header label and was identified by its contents.",
                                "sheet": sheet.name,
                                "user_actionable": True,
                                "impact": "Confirm the column, then label it so it never has to be guessed again.",
                                "details": {
                                    "header_row": header.row,
                                    "columns": {
                                        field: _column_letters(header.columns[field])
                                        for field in sorted(header.inferred)
                                    },
                                },
                            },
                            source=source,
                        )
                    )
                found.append((sheet, header))
            else:
                diagnostics.append(
                    _with_source(
                        {
                            "severity": "warning",
                            "code": "workbook.hidden-script-sheet",
                            "message": "A hidden sheet has Chapters headers and was excluded.",
                            "sheet": sheet.name,
                            "impact": "Its story content is not present in this StoryBundle.",
                        },
                        source=source,
                    )
                )
            continue
        if any(_meaningful(cell) for cell in sheet.cells):
            probable_row, observation = _probable_header_observation(sheet)
            missing = sorted(
                _REQUIRED_FIELDS.difference(observation["recognized_headers"])
            )
            details: dict[str, Any] = {
                "recognized_headers": observation["recognized_headers"],
                "missing_required_headers": missing,
            }
            if probable_row is not None:
                details["probable_header_row"] = probable_row
            diagnostics.append(
                _with_source(
                    {
                        "severity": "warning",
                        "code": "workbook.unrecognized-sheet",
                        "message": "A non-auxiliary sheet contains data but has no reliable Chapters header.",
                        "sheet": sheet.name,
                        "impact": "The sheet was excluded; verify whether it contains story content.",
                        "details": details,
                    },
                    source=source,
                )
            )
    return found, diagnostics


def _missing_script_sheet_issues(
    source: _LoadedSource, diagnostics: Sequence[Mapping[str, Any]]
) -> tuple[dict[str, Any], ...]:
    sheets = {sheet.name: sheet for sheet in source.workbook.sheets}
    hidden_script_issues: list[dict[str, Any]] = []
    contradicted_issues: list[dict[str, Any]] = []
    missing_header_issues: list[dict[str, Any]] = []
    for diagnostic in diagnostics:
        sheet_name = diagnostic.get("sheet")
        sheet = sheets.get(sheet_name) if isinstance(sheet_name, str) else None
        if sheet is None:
            continue
        code = diagnostic.get("code")
        if code == "workbook.hidden-script-sheet":
            header = _detect_header(sheet)
            hidden_script_issues.append(
                _input_issue(
                    "workbook.script-sheet-hidden",
                    source=source.relative_path,
                    sheet=sheet.name,
                    row=header.row if header is not None else None,
                    observed={"sheet_state": sheet.state},
                    expected={"sheet_state": "visible"},
                    remediation="Make the Chapters script sheet visible or select a workbook with a visible script sheet.",
                )
            )
        elif code == "workbook.header-contradicts-data":
            details = diagnostic.get("details") or {}
            contradicted_issues.append(
                _input_issue(
                    "workbook.header-contradicts-data",
                    source=source.relative_path,
                    sheet=sheet.name,
                    row=details.get("header_row"),
                    observed={"columns": details.get("columns", [])},
                    expected={
                        "columns": "each labelled column holds what its label says",
                    },
                    remediation="Open the sheet at the header row and check that each label sits above the column it names; a column dragged out from under its header is the usual cause.",
                )
            )
        elif code == "workbook.unrecognized-sheet":
            candidate_row, observed = _probable_header_observation(sheet)
            if not observed["recognized_headers"]:
                continue
            missing_header_issues.append(
                _input_issue(
                    "workbook.missing-required-headers",
                    source=source.relative_path,
                    sheet=sheet.name,
                    row=candidate_row,
                    observed=observed,
                    expected={
                        "required_headers": sorted(_REQUIRED_FIELDS),
                        "accepted_labels": {
                            field: list(_HEADER_ALIASES[field])
                            for field in sorted(_REQUIRED_FIELDS)
                        },
                        "minimum_recognized_headers": 4,
                    },
                    remediation="On one visible row, add the required Chapters headers plus at least one other supported script header (for example Role ID), and keep every label unique.",
                )
            )
    if hidden_script_issues:
        return tuple(hidden_script_issues)
    if contradicted_issues:
        return tuple(contradicted_issues)
    if missing_header_issues:
        return tuple(missing_header_issues)
    return (
        _input_issue(
            "workbook.no-script-sheet",
            source=source.relative_path,
            observed={
                "sheets": [
                    {"name": sheet.name, "state": sheet.state}
                    for sheet in source.workbook.sheets
                ]
            },
            expected={"sheet": "at least one visible sheet with Chapters headers"},
            remediation="First verify that this is the intended Chapters workbook. If it is, add or unhide a script sheet with the required Chapters headers.",
        ),
    )


def _probable_header_observation(
    sheet: SheetSnapshot,
) -> tuple[int | None, dict[str, Any]]:
    rows: dict[int, list[tuple[str, str]]] = {}
    for cell in sheet.cells:
        field = _header_field(cell.value)
        if field is not None:
            rows.setdefault(cell.row, []).append((field, str(cell.value)))
    if not rows:
        return None, {"recognized_headers": [], "labels": []}
    row, matches = max(
        rows.items(),
        key=lambda item: (len({field for field, _label in item[1]}), -item[0]),
    )
    return row, {
        "recognized_headers": sorted({field for field, _label in matches}),
        "labels": [label for _field, label in matches],
    }


def _detect_header(sheet: SheetSnapshot) -> _HeaderMap | None:
    """Which column is which, read from the whole header block.

    No single row can be trusted to name every column.  A production sheet
    stacks two header rows -- row 1 the bilingual labels a writer reads, row 3
    the canonical snake_case names -- and neither is complete: in the books we
    have, no canonical row names the Line column at all, one sheet has its
    Dialogue Type label overwritten with a blank space, and another is missing
    that header cell entirely.  So the block is read as a whole.  The header
    row states its own columns, the rows above it fill in what it leaves
    unnamed, and a required column that no row names is inferred from what the
    column itself holds.
    """

    labelled: dict[int, dict[str, list[CellSnapshot]]] = {}
    for cell in sheet.cells:
        field = _header_field(cell.value)
        if field is not None:
            labelled.setdefault(cell.row, {}).setdefault(field, []).append(cell)
    if not labelled:
        return None

    # Anchor the block on the row naming the most columns rather than on the
    # first label found: a stray "Notes" in a preamble must not drag the block
    # away from the real header below it.
    anchor = min(labelled, key=lambda row: (-len(labelled[row]), row))
    block = sorted(row for row in labelled if abs(row - anchor) <= _HEADER_BLOCK_SPAN)
    # The header is the LAST row of the block: everything above it is preamble
    # and the story starts below it, so choosing an upper row would leak the
    # rows between into the story as extra lines.
    header_row = block[-1]

    columns: dict[str, int] = {}
    labels: dict[str, str] = {}
    taken: set[int] = set()
    for row in (header_row, *(item for item in block if item != header_row)):
        for field, cells in sorted(labelled[row].items()):
            # A field named twice on one row names nothing: there is no way to
            # tell which of the two columns was meant.  A column already
            # spoken for keeps its first field for the same reason.
            if field in columns or len(cells) != 1 or cells[0].column in taken:
                continue
            columns[field] = cells[0].column
            labels[field] = str(cells[0].value)
            taken.add(cells[0].column)

    inferred = _infer_columns(sheet, header_row, columns, taken)
    for field, (column, label) in inferred.items():
        columns[field] = column
        labels[field] = label

    if not _REQUIRED_FIELDS.issubset(columns) or len(columns) < 4:
        return None
    return _HeaderMap(
        row=header_row,
        columns=columns,
        labels=labels,
        inferred=frozenset(inferred),
    )


def _profile_columns(
    sheet: SheetSnapshot, header_row: int
) -> tuple[dict[int, _ColumnProfile], int]:
    """What each column below the header holds, one pass over the sheet."""

    values: dict[int, list[Any]] = {}
    rows: dict[int, set[int]] = {}
    story_rows: set[int] = set()
    for cell in sheet.cells:
        if cell.row <= header_row or not _story_value(cell):
            continue
        story_rows.add(cell.row)
        values.setdefault(cell.column, []).append(cell.value)
        rows.setdefault(cell.column, set()).add(cell.row)
    total = len(story_rows)
    profiles: dict[int, _ColumnProfile] = {}
    for column, items in values.items():
        lengths = [len(str(item)) for item in items]
        profiles[column] = _ColumnProfile(
            filled=len(items),
            coverage=len(items) / total if total else 0.0,
            average_length=sum(lengths) / len(lengths),
            longest=max(lengths),
            type_like=sum(1 for item in items if _reads_as_dialogue_type(item))
            / len(items),
            rows=frozenset(rows[column]),
        )
    return profiles, total


def _reads_as_dialogue_type(value: Any) -> bool:
    if _choice_marker(value) is not None:
        return True
    text = _normalized_text(value)
    return text in _DIALOGUE_TYPE_WORDS or "choice" in text or "background" in text


def _choice_rows(sheet: SheetSnapshot, column: int | None, header_row: int) -> set[int]:
    if column is None:
        return set()
    return {
        cell.row
        for cell in sheet.cells
        if cell.column == column
        and cell.row > header_row
        and _choice_marker(cell.value) is not None
    }


def _infer_columns(
    sheet: SheetSnapshot,
    header_row: int,
    columns: Mapping[str, int],
    taken: set[int],
) -> dict[str, tuple[int, str]]:
    """A required column no header row names, read from its own contents.

    Only ever one candidate is accepted.  A sheet carries decoy columns -- the
    example blocks pasted off to the right hold the same words as the real
    Dialogue Type column -- so a field with two plausible columns is left
    unresolved and the sheet is reported instead of quietly mis-read.
    """

    missing = _REQUIRED_FIELDS.difference(columns)
    if not missing:
        return {}
    profiles, total = _profile_columns(sheet, header_row)
    if total < _PROFILE_MINIMUM_ROWS:
        return {}
    free = {
        column: profile
        for column, profile in profiles.items()
        if column not in taken
    }
    resolved: dict[str, tuple[int, str]] = {}

    def claim(field: str, candidates: Sequence[int], label: str) -> None:
        if len(candidates) != 1:
            return
        resolved[field] = (candidates[0], label)
        taken.add(candidates[0])
        free.pop(candidates[0], None)

    if "dialogue_type" in missing:
        # The one column filled on nearly every row with Dialogue Type words.
        # The decoys fail on coverage: they hold a few dozen rows of a
        # template, not the whole chapter.
        claim(
            "dialogue_type",
            [
                column
                for column, profile in sorted(free.items())
                if profile.coverage >= _TYPE_COLUMN_FILLED
                and profile.type_like >= _TYPE_COLUMN_WORDS_TO_INFER
            ],
            "(inferred: holds Dialogue Type words on every row)",
        )
    if "content" in missing:
        # The script column is the wordy one, and it has to win by a clear
        # margin: two columns of similar width are two columns nobody can
        # tell apart from the outside.
        ranked = sorted(
            (
                (profile.average_length, column)
                for column, profile in free.items()
                if profile.coverage >= _CONTENT_COLUMN_FILLED
            ),
            reverse=True,
        )
        if ranked and (
            len(ranked) == 1 or ranked[0][0] >= _CONTENT_COLUMN_MARGIN * ranked[1][0]
        ):
            claim("content", [ranked[0][1]], "(inferred: the long-text column)")
    type_column = columns.get("dialogue_type")
    if type_column is None and "dialogue_type" in resolved:
        type_column = resolved["dialogue_type"][0]
    if "line" in missing:
        # Line is sparse by nature -- it labels branches, so it is empty on
        # every ordinary story row.  What identifies it is where it is filled:
        # on the Choice rows.
        marker_rows = _choice_rows(sheet, type_column, header_row)
        if marker_rows:
            claim(
                "line",
                [
                    column
                    for column, profile in sorted(free.items())
                    if profile.filled
                    and profile.longest <= _LINE_COLUMN_LONGEST
                    and len(profile.rows & marker_rows) / profile.filled
                    >= _LINE_COLUMN_ON_CHOICES
                ],
                "(inferred: branch labels on the Choice rows)",
            )
    return resolved


def _header_conflicts(
    sheet: SheetSnapshot, header: _HeaderMap
) -> list[dict[str, Any]]:
    """Confirm the columns against what sits below them.

    A label can be right about the name and wrong about the column: a column
    gets dragged, a template is pasted one column across, a header row is
    edited while the data below it is not.  Every one of those produces counts
    that look plausible and are wrong, which is the one failure an editor
    cannot see, so the three columns every count depends on are checked
    against their own contents before the sheet is accepted.
    """

    profiles, total = _profile_columns(sheet, header.row)
    if total < _PROFILE_MINIMUM_ROWS:
        return []
    empty = _ColumnProfile(0, 0.0, 0.0, 0, 0.0, frozenset())
    problems: list[dict[str, Any]] = []

    def report(field: str, severity: str, observed: Mapping[str, Any], expected: Mapping[str, Any]) -> None:
        problems.append(
            {
                "field": field,
                "column": _column_letters(header.columns[field]),
                "label": header.labels[field],
                "severity": severity,
                "observed": dict(observed),
                "expected": dict(expected),
            }
        )

    dialogue = profiles.get(header.columns["dialogue_type"], empty)
    if (
        dialogue.coverage < _TYPE_COLUMN_FILLED
        or dialogue.type_like < _TYPE_COLUMN_WORDS
    ):
        report(
            "dialogue_type",
            "error",
            {
                "filled_share": round(dialogue.coverage, 2),
                "dialogue_type_words_share": round(dialogue.type_like, 2),
            },
            {
                "filled_share": f">= {_TYPE_COLUMN_FILLED}",
                "dialogue_type_words_share": f">= {_TYPE_COLUMN_WORDS}",
            },
        )

    content = profiles.get(header.columns["content"], empty)
    # Another column holding several times more text than the one labelled as
    # the script is the signature of a dragged column: the story has to be
    # somewhere, and it is not where the label says.
    rival = max(
        (
            profile.average_length
            for column, profile in profiles.items()
            if column != header.columns["content"]
            and profile.coverage >= _CONTENT_COLUMN_FILLED
        ),
        default=0.0,
    )
    if content.coverage < _CONTENT_COLUMN_EMPTY or (
        rival >= _CONTENT_COLUMN_OUTCLASSED * max(content.average_length, 1.0)
    ):
        report(
            "content",
            "error",
            {
                "filled_share": round(content.coverage, 2),
                "average_length": round(content.average_length, 1),
                "widest_other_column": round(rival, 1),
            },
            {
                "filled_share": f">= {_CONTENT_COLUMN_EMPTY}",
                "widest_other_column": (
                    f"< {_CONTENT_COLUMN_OUTCLASSED}x the script column"
                ),
            },
        )

    line = profiles.get(header.columns["line"], empty)
    marker_rows = _choice_rows(sheet, header.columns.get("dialogue_type"), header.row)
    if line.filled and marker_rows:
        share = len(line.rows & marker_rows) / line.filled
        if share < _LINE_COLUMN_ON_CHOICES_TO_WARN:
            # A warning, not a refusal: Line is sparse, and a chapter may
            # legitimately label rows that are not Choice rows.  What it must
            # not be is a column that has nothing to do with branches.
            report(
                "line",
                "warning",
                {"share_on_choice_rows": round(share, 2)},
                {"share_on_choice_rows": f">= {_LINE_COLUMN_ON_CHOICES_TO_WARN}"},
            )
    return problems


def _chapter_assignments(
    filename: str, sheets: Sequence[SheetSnapshot]
) -> tuple[dict[str, int | None], list[dict[str, Any]]]:
    assignments: dict[str, int | None] = {}
    diagnostics: list[dict[str, Any]] = []
    explicit: list[int | None] = []
    for sheet in sheets:
        match = _SHEET_CHAPTER_RE.search(sheet.name) or _BARE_SHEET_CHAPTER_RE.fullmatch(sheet.name)
        explicit.append(int(match.group("number")) if match else None)

    filename_numbers: list[int] = []
    range_match = _FILE_RANGE_RE.search(Path(filename).stem)
    if range_match:
        start, end = int(range_match.group("start")), int(range_match.group("end"))
        if end >= start and end - start <= 500:
            filename_numbers = list(range(start, end + 1))
    elif len(sheets) == 1:
        singles = [int(match.group("number")) for match in _FILE_SINGLE_RE.finditer(Path(filename).stem)]
        if singles:
            filename_numbers = [singles[-1]]

    fallback = filename_numbers if len(filename_numbers) == len(sheets) else []
    for index, sheet in enumerate(sheets):
        number = explicit[index]
        if number is None and fallback:
            number = fallback[index]
        assignments[sheet.name] = number
        if number is None:
            diagnostics.append(
                {
                    "severity": "warning",
                    "code": "chapter.number-unknown",
                    "message": f"No chapter number could be resolved for sheet {sheet.name!r}.",
                    "sheet": sheet.name,
                    "user_actionable": True,
                    "observed": {"sheet_name": sheet.name, "workbook_filename": filename},
                    "expected": {
                        "chapter_number": "an unambiguous positive number in the sheet name or workbook filename"
                    },
                    "remediation": "Rename the sheet to 'Chapter N' or add an unambiguous chapter number to the workbook filename.",
                    "impact": "Chapter-number-dependent checks must return unknown.",
                }
            )
        elif fallback and explicit[index] is not None and number != fallback[index]:
            diagnostics.append(
                {
                    "severity": "warning",
                    "code": "chapter.number-conflict",
                    "message": "The sheet chapter number conflicts with the filename range; the sheet name was used.",
                    "sheet": sheet.name,
                    "details": {"sheet_number": number, "filename_number": fallback[index]},
                    "impact": "Confirm the intended chapter order before relying on cross-chapter checks.",
                }
            )
    return assignments, diagnostics


def _parse_chapter(
    *,
    source: _LoadedSource,
    sheet: SheetSnapshot,
    header: _HeaderMap,
    chapter_id: str,
    chapter_number: int | str,
) -> _ChapterCandidate:
    cells = {(cell.row, cell.column): cell for cell in sheet.cells}
    mapped_columns = set(header.columns.values())
    row_numbers = sorted(
        {
            cell.row
            for cell in sheet.cells
            if cell.row > header.row
            and cell.column in mapped_columns
            and _story_value(cell)
        }
    )
    lines: list[dict[str, Any]] = []
    source_map: list[dict[str, Any]] = []
    title: str | None = None
    metadata_refs: dict[str, list[str]] = {}
    all_used_columns = sorted({cell.column for cell in sheet.cells if _meaningful(cell)})
    extra_column_numbers = [column for column in all_used_columns if column not in mapped_columns]
    header_cells = {(cell.row, cell.column): cell for cell in sheet.cells if cell.row <= header.row}

    for seq, row in enumerate(row_numbers, 1):
        line_id = f"{chapter_id}:l{seq:06d}"
        fields: dict[str, Any] = {}
        field_cells: dict[str, str] = {}
        formulae: dict[str, dict[str, Any]] = {}
        for field in _CANONICAL_FIELDS:
            column = header.columns.get(field)
            cell = cells.get((row, column)) if column is not None else None
            if cell is None or not _meaningful(cell):
                continue
            fields[field] = cell.value
            field_cells[field] = cell.coordinate
            if cell.formula is not None:
                formulae[field] = {
                    "cell": cell.coordinate,
                    "formula": cell.formula,
                    "cached_value": cell.value,
                    "raw_value": cell.raw_value,
                    "data_type": cell.data_type,
                }

        extra_fields: dict[str, dict[str, Any]] = {}
        extra_cells: dict[str, str] = {}
        for column in extra_column_numbers:
            cell = cells.get((row, column))
            if cell is None or not _meaningful(cell):
                continue
            letter = _column_letters(column)
            label_cell = next(
                (
                    header_cells[(candidate_row, column)]
                    for candidate_row in range(header.row, 0, -1)
                    if (candidate_row, column) in header_cells
                    and _meaningful(header_cells[(candidate_row, column)])
                ),
                None,
            )
            extra_fields[letter] = {
                "header": label_cell.value if label_cell is not None else None,
                "value": cell.value,
            }
            extra_cells[letter] = cell.coordinate
            if cell.formula is not None:
                formulae[f"extra:{letter}"] = {
                    "cell": cell.coordinate,
                    "formula": cell.formula,
                    "cached_value": cell.value,
                    "raw_value": cell.raw_value,
                    "data_type": cell.data_type,
                }

        metadata_type = _metadata_type(fields)
        if metadata_type == "title" and fields.get("content") is not None:
            title = str(fields["content"])
        kind = _line_kind(fields, metadata_type)
        record: dict[str, Any] = {
            "line_id": line_id,
            "seq": seq,
            "kind": kind,
            "fields": fields,
            "branch_path": [],
        }
        if metadata_type is not None:
            record["metadata_type"] = metadata_type
            metadata_refs.setdefault(metadata_type, []).append(line_id)
        if extra_fields:
            record["extra_fields"] = extra_fields
        lines.append(record)
        occupied = [
            cell.column
            for cell in sheet.cells
            if cell.row == row and _meaningful(cell)
        ]
        span_start = _column_letters(min(occupied or mapped_columns))
        span_end = _column_letters(max(occupied or mapped_columns))
        mapping: dict[str, Any] = {
            "line_id": line_id,
            "excel_row": row,
            "range": f"{span_start}{row}:{span_end}{row}",
            "cells": field_cells,
        }
        if extra_cells:
            mapping["extra_cells"] = extra_cells
        if formulae:
            mapping["formulae"] = formulae
        source_map.append(mapping)

    choice_diagnostics: list[dict[str, Any]] = []
    choices = _build_choice_graph(chapter_id, lines, choice_diagnostics)
    chapter_diagnostics = [
        _with_chapter(_with_source(item, source=source), chapter_id, sheet.name)
        for item in choice_diagnostics
    ]
    chapter_diagnostics.extend(
        _thought_bubble_diagnostics(source, sheet, chapter_id, lines)
    )
    chapter_diagnostics.extend(
        _excluded_data_diagnostics(
            source, sheet, header, chapter_id, included_rows=row_numbers
        )
    )
    chapter = {
        "chapter_id": chapter_id,
        "number": chapter_number,
        "order": None,
        "title": title,
        "source": {"source_id": source.source_id, "sheet": sheet.name},
        "header_row": header.row,
        "columns": {
            field: {
                "column": _column_letters(column),
                "source_header": header.labels[field],
            }
            for field, column in sorted(header.columns.items(), key=lambda item: item[1])
        },
        "metadata_refs": metadata_refs,
    }
    _validate_chapter_records(chapter_id, lines, choices, source_map)
    content_digest = _json_digest(
        {"chapter": {"number": chapter_number, "title": title}, "lines": lines, "choices": choices}
    )
    return _ChapterCandidate(
        chapter_id=chapter_id,
        chapter_number=chapter_number,
        source=source,
        sheet=sheet,
        chapter=chapter,
        lines=lines,
        choices=choices,
        source_map=source_map,
        diagnostics=chapter_diagnostics,
        content_digest=content_digest,
    )


def _build_choice_graph(
    chapter_id: str,
    lines: list[dict[str, Any]],
    diagnostics: list[dict[str, Any]],
) -> dict[str, Any]:
    groups: list[dict[str, Any]] = []
    group_by_id: dict[str, dict[str, Any]] = {}
    branch_by_id: dict[str, dict[str, Any]] = {}
    active_groups: dict[int, str] = {}
    active_branches: dict[int, str] = {}
    run_info = _choice_runs(lines)

    def ancestors(branch_id: str | None) -> list[str]:
        result: list[str] = []
        current = branch_id
        while current is not None:
            result.append(current)
            group = group_by_id[branch_by_id[current]["group_id"]]
            current = group["parent_branch_id"]
        return list(reversed(result))

    def mark(group: dict[str, Any], status: str) -> None:
        rank = {"complete": 0, "recovered": 1, "uncertain": 2}
        if rank[status] > rank[group["structure_status"]]:
            group["structure_status"] = status

    def add_diagnostic(
        code: str,
        message: str,
        *,
        line_id: str | None = None,
        group: dict[str, Any] | None = None,
        impact: str,
        details: Mapping[str, Any] | None = None,
    ) -> None:
        item: dict[str, Any] = {
            "severity": "warning",
            "code": code,
            "message": message,
            "impact": impact,
        }
        if line_id is not None:
            item["line_id"] = line_id
        if group is not None:
            item["group_id"] = group["group_id"]
            group["diagnostic_codes"].append(code)
        if details:
            item["details"] = dict(details)
        diagnostics.append(item)

    def close_from(depth: int, merge_line_id: str | None, *, reason: str | None = None) -> None:
        for item_depth in sorted(
            (value for value in active_groups if value >= depth), reverse=True
        ):
            group = group_by_id[active_groups[item_depth]]
            for branch in group["branches"]:
                if branch["merge_line_id"] is None and merge_line_id is not None:
                    branch["merge_line_id"] = merge_line_id
            if merge_line_id is None and group["branches"]:
                mark(group, "uncertain")
                add_diagnostic(
                    "choice.merge-not-confirmed",
                    "No explicit mainline row confirms where this choice rejoins.",
                    group=group,
                    impact="Checks that depend on the merge point must return unknown.",
                    details={"reason": reason} if reason else None,
                )
            active_groups.pop(item_depth, None)
            active_branches.pop(item_depth, None)

    for position, line in enumerate(lines):
        line_id = line["line_id"]
        marker = _choice_marker(line["fields"].get("dialogue_type"))
        if marker is None:
            if _is_choice_role(line):
                add_diagnostic(
                    "choice.button-without-marker",
                    "A Choice-role row has no valid Choice-family Dialogue Type.",
                    line_id=line_id,
                    impact="The row cannot be assigned to a reliable choice group.",
                )
                if active_groups:
                    close_from(
                        1,
                        None,
                        reason="an unparseable Choice-role button began",
                    )
                continue
            if active_branches and _is_callback_control(line):
                branch_id = active_branches[max(active_branches)]
                line["kind"] = "choice_control"
                line["branch_path"] = ancestors(branch_id)
                continue
            if active_groups:
                close_from(1, line_id)
            continue

        is_button, inferred = _is_choice_button(
            position, line, marker, active_groups, active_branches, branch_by_id, run_info
        )
        if not is_button:
            run_has_role, first_role_position = run_info.get(
                position, (False, None)
            )
            if (
                run_has_role
                and first_role_position is not None
                and position < first_role_position
            ):
                # Production sheets may tag one or more setup/question rows
                # with the upcoming button's Choice marker.  They belong to
                # the enclosing branch (if any), never to the still-active
                # choice at the same depth.
                if any(depth >= marker.depth for depth in active_groups):
                    close_from(marker.depth, line_id)
                parent_branch_id = (
                    active_branches.get(marker.depth - 1)
                    if marker.depth > 1
                    else None
                )
                if parent_branch_id is not None:
                    parent_branch = branch_by_id[parent_branch_id]
                    parent_branch["content_line_ids"].append(line_id)
                    line["kind"] = "choice_content"
                    line["branch_path"] = ancestors(parent_branch_id)
                continue
            if any(depth > marker.depth for depth in active_groups):
                close_from(marker.depth + 1, line_id)
            branch_id = active_branches.get(marker.depth)
            if branch_id is None:
                shallower = [depth for depth in active_branches if depth < marker.depth]
                branch_id = active_branches[max(shallower)] if shallower else None
            if branch_id is None:
                add_diagnostic(
                    "choice.unconfirmed-marker-run",
                    "A Choice-family row has no confirmed branch button or active branch.",
                    line_id=line_id,
                    impact="The row remains story content but is outside the choice graph.",
                    details={"depth": marker.depth, "branch_index": marker.branch_index},
                )
                continue
            branch = branch_by_id[branch_id]
            branch["content_line_ids"].append(line_id)
            if not _priced_free(branch):
                # A branch its own price cell called free stays free, however
                # its payoff rows are typed.
                branch["premium"] = bool(
                    branch["premium"] or marker.premium or marker.vip
                )
            branch["vip"] = bool(branch["vip"] or marker.vip)
            branch_group = group_by_id[branch["group_id"]]
            branch_group["signals"]["has_premium_branch"] = bool(
                branch_group["signals"]["has_premium_branch"]
                or branch["premium"]
            )
            branch_group["signals"]["has_vip_branch"] = bool(
                branch_group["signals"]["has_vip_branch"] or branch["vip"]
            )
            line["kind"] = "choice_content"
            line["branch_path"] = ancestors(branch_id)
            continue

        close_from(marker.depth + 1, None, reason="a sibling or parent button began")
        parent_branch_id = active_branches.get(marker.depth - 1) if marker.depth > 1 else None
        group: dict[str, Any] | None = None
        current_group_id = active_groups.get(marker.depth)
        if current_group_id is not None:
            current = group_by_id[current_group_id]
            if current["parent_branch_id"] == parent_branch_id:
                group = current
        source_label = _branch_label(line["fields"].get("line"))
        starts_new = group is None or (
            marker.branch_index == 1
            and bool(group["branches"])
        )
        if starts_new:
            if group is not None:
                close_from(marker.depth, None, reason="a new choice group began")
                parent_branch_id = (
                    active_branches.get(marker.depth - 1) if marker.depth > 1 else None
                )
            group_id = f"{chapter_id}:g{len(groups) + 1:04d}"
            preceding_line_id = lines[position - 1]["line_id"] if position else None
            outfit_marker = (
                preceding_line_id
                if position
                and _is_outfit_marker(lines[position - 1]["fields"].get("content"))
                else None
            )
            group = {
                "group_id": group_id,
                "order": len(groups) + 1,
                "depth": marker.depth,
                "parent_branch_id": parent_branch_id,
                "preceding_line_id": preceding_line_id,
                "structure_status": "complete",
                "diagnostic_codes": [],
                "signals": {
                    "outfit_marker_line_id": outfit_marker,
                    "has_premium_branch": False,
                    "has_vip_branch": False,
                },
                "branches": [],
            }
            groups.append(group)
            group_by_id[group_id] = group
            active_groups[marker.depth] = group_id
            if parent_branch_id is not None:
                branch_by_id[parent_branch_id]["child_group_ids"].append(group_id)
            elif marker.depth > 1:
                mark(group, "uncertain")
                add_diagnostic(
                    "choice.missing-parent",
                    "A nested Choice button has no active parent branch.",
                    line_id=line_id,
                    group=group,
                    impact="Nested-choice parentage checks must return unknown.",
                    details={"depth": marker.depth},
                )
            if marker.branch_index != 1:
                mark(group, "uncertain")
                add_diagnostic(
                    "choice.group-starts-without-branch-1",
                    "A choice group begins with a branch index other than 1.",
                    line_id=line_id,
                    group=group,
                    impact="Branch ordering may not match the intended source structure.",
                    details={"branch_index": marker.branch_index},
                )

        assert group is not None
        if inferred:
            mark(group, "recovered")
            add_diagnostic(
                "choice.button-inferred-from-label",
                "A branch button was inferred from its whole Line label because role_id was not Choice.",
                line_id=line_id,
                group=group,
                impact="The recovered structure is usable, but the editor should verify the button row.",
            )
        if any(branch["source_index"] == marker.branch_index for branch in group["branches"]):
            mark(group, "recovered")
            add_diagnostic(
                "choice.duplicate-branch-index",
                "A confirmed button repeats a branch index already used in this group.",
                line_id=line_id,
                group=group,
                impact="Appearance order, rather than the repeated index, is used for navigation.",
            )
        if source_label is not None and any(
            branch.get("source_label") == source_label for branch in group["branches"]
        ):
            mark(group, "uncertain")
            add_diagnostic(
                "choice.duplicate-branch-label",
                "A confirmed button repeats a Line branch label already used in this group.",
                line_id=line_id,
                group=group,
                impact="Price-label and branch-order checks must treat this group cautiously.",
            )
        branch_order = len(group["branches"]) + 1
        expected_label = _expected_label(source_label, branch_order)
        if source_label is not None and expected_label is not None and source_label != expected_label:
            mark(group, "uncertain")
            add_diagnostic(
                "choice.branch-label-order-conflict",
                "The branch label suffix does not match button appearance order.",
                line_id=line_id,
                group=group,
                impact="The raw label is preserved; ordered pricing checks may be unknown.",
                details={"observed": source_label, "expected": expected_label},
            )
        branch_id = f"{group['group_id']}:b{branch_order:02d}"
        commercial = _commercial_term(
            line["fields"].get("line"), expected_label=expected_label
        )
        commercial_price = bool(
            commercial is not None
            and commercial.get("kind") == "price"
            and commercial.get("parse_status") == "parsed"
        )
        # The price cell decides whether this branch costs anything, and it
        # outranks the Dialogue Type.  Writers mark every row of a paid group
        # "Premium Choice N" including the free way out, then price that one
        # `c-free`, which is `c-0`: 89 branches in one book.  Reading the type
        # instead left those groups looking like they had no free exit at all.
        commercial_free = bool(
            commercial is not None and commercial.get("kind") == "free"
        )
        branch = {
            "branch_id": branch_id,
            "group_id": group["group_id"],
            "order": branch_order,
            "source_index": marker.branch_index,
            "source_label": source_label,
            "button_line_id": line_id,
            "premium": bool(
                (marker.premium or marker.vip or commercial_price)
                and not commercial_free
            ),
            "vip": marker.vip,
            "content_line_ids": [],
            "child_group_ids": [],
            "merge_line_id": None,
            "commercial_terms": (
                []
                if commercial is None
                else [
                    {
                        **commercial,
                        "evidence": {"line_id": line_id, "field": "line"},
                    }
                ]
            ),
        }
        group["branches"].append(branch)
        branch_by_id[branch_id] = branch
        active_branches[marker.depth] = branch_id
        group["signals"]["has_premium_branch"] = bool(
            group["signals"]["has_premium_branch"] or branch["premium"]
        )
        group["signals"]["has_vip_branch"] = bool(
            group["signals"]["has_vip_branch"] or branch["vip"]
        )
        line["kind"] = "choice_button"
        line["branch_path"] = ancestors(branch_id)

    if active_groups:
        close_from(1, None, reason="the chapter ended")
    status = "complete"
    if any(group["structure_status"] == "uncertain" for group in groups):
        status = "uncertain"
    elif any(group["structure_status"] == "recovered" for group in groups):
        status = "recovered"
    return {
        "chapter_id": chapter_id,
        "structure_status": status,
        "root_group_ids": [
            group["group_id"] for group in groups if group["parent_branch_id"] is None
        ],
        "groups": groups,
    }


def _choice_runs(lines: Sequence[Mapping[str, Any]]) -> Mapping[int, tuple[bool, int | None]]:
    result: dict[int, tuple[bool, int | None]] = {}
    position = 0
    while position < len(lines):
        marker = _choice_marker(lines[position]["fields"].get("dialogue_type"))
        if marker is None:
            position += 1
            continue
        end = position + 1
        while end < len(lines):
            candidate = _choice_marker(lines[end]["fields"].get("dialogue_type"))
            if candidate is None or (
                candidate.depth,
                candidate.branch_index,
            ) != (marker.depth, marker.branch_index):
                break
            end += 1
        choice_roles = [index for index in range(position, end) if _is_choice_role(lines[index])]
        first = choice_roles[0] if choice_roles else None
        for index in range(position, end):
            result[index] = (bool(choice_roles), first)
        position = end
    return result


def _is_choice_button(
    position: int,
    line: Mapping[str, Any],
    marker: _ChoiceMarker,
    active_groups: Mapping[int, str],
    active_branches: Mapping[int, str],
    branches: Mapping[str, Mapping[str, Any]],
    run_info: Mapping[int, tuple[bool, int | None]],
) -> tuple[bool, bool]:
    run_has_role, _first_role_position = run_info.get(position, (False, None))
    if _is_choice_role(line):
        return True, False
    if run_has_role:
        return False, False
    label = _branch_label(line["fields"].get("line"))
    if label is None:
        return False, False
    branch_id = active_branches.get(marker.depth)
    if branch_id is None or marker.depth not in active_groups:
        return True, not _is_choice_role(line)
    branch = branches[branch_id]
    if label != branch.get("source_label") or marker.branch_index != branch["source_index"]:
        return True, not _is_choice_role(line)
    return False, False


def _choice_marker(value: Any) -> _ChoiceMarker | None:
    if not isinstance(value, str):
        return None
    match = _CHOICE_RE.fullmatch(value.replace("_", " "))
    if match is None:
        return None
    return _ChoiceMarker(
        depth=len(re.findall(r"Sub", match.group("subs"), flags=re.IGNORECASE)) + 1,
        branch_index=int(match.group("index")),
        premium=match.group("premium") is not None,
        vip=match.group("vip") is not None,
    )


def _branch_label(value: Any) -> str | None:
    if not isinstance(value, str) or not value.strip():
        return None
    match = _LABEL_ONLY_RE.fullmatch(value)
    if match is not None:
        label = match.group("label").casefold()
        return None if label == "free" else label
    for pattern in (_REWARD_RE, _FREE_RE, _PRICE_RE):
        match = pattern.fullmatch(value)
        if match is not None and match.group("label"):
            return match.group("label").casefold()
    return None


def _expected_label(source_label: str | None, branch_order: int) -> str | None:
    if source_label is None or branch_order > 26:
        return None
    return f"{source_label[:-1]}{chr(ord('a') + branch_order - 1)}"


def _priced_free(branch: Mapping[str, Any]) -> bool:
    """Whether this branch's own price cell says it costs nothing."""

    return any(
        term.get("kind") == "free" for term in branch.get("commercial_terms", ()) or ()
    )


def _commercial_term(value: Any, *, expected_label: str | None) -> dict[str, Any] | None:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return {
            "kind": "unparsed",
            "raw": value,
            "parse_status": "invalid",
            "reason": "unsupported_value_type",
        }
    if isinstance(value, (int, float)):
        if isinstance(value, float) and (not math.isfinite(value) or not value.is_integer()):
            return {
                "kind": "unparsed",
                "raw": value,
                "parse_status": "invalid",
                "reason": "non_integral_number",
            }
        amount = abs(int(value))
        return {
            "kind": "free" if amount == 0 else "price",
            "raw": value,
            "amount": amount,
            "unit": None,
            "parse_status": "parsed",
        }
    if not isinstance(value, str):
        return {
            "kind": "unparsed",
            "raw": str(value),
            "parse_status": "invalid",
            "reason": "unsupported_value_type",
        }
    if not value.strip() or _LABEL_ONLY_RE.fullmatch(value):
        return None
    for pattern, kind in ((_REWARD_RE, "reward"), (_FREE_RE, "free"), (_PRICE_RE, "price")):
        match = pattern.fullmatch(value)
        if match is None:
            continue
        label = match.group("label")
        if label is not None and expected_label is not None and label.casefold() != expected_label:
            return {
                "kind": "unparsed",
                "raw": value,
                "parse_status": "invalid",
                "reason": "branch_label_context_mismatch",
            }
        amount = 0 if kind == "free" else int(match.group("amount"))
        actual_kind = "free" if kind == "price" and amount == 0 else kind
        return {
            "kind": actual_kind,
            "raw": value,
            "amount": amount,
            "unit": "gem" if match.groupdict().get("unit") else None,
            "parse_status": "parsed",
        }
    candidates = len(_INTEGER_CANDIDATE_RE.findall(value))
    candidates += len(re.findall(r"\bfree\b", value, flags=re.IGNORECASE))
    return {
        "kind": "unparsed",
        "raw": value,
        "parse_status": "ambiguous" if candidates > 1 else "invalid",
        "reason": "multiple_commercial_markers" if candidates > 1 else "whole_value_grammar_mismatch",
    }


def _choose_chapters(
    candidates: Sequence[_ChapterCandidate], *, chapter_sources: Mapping[int, str]
) -> tuple[list[_ChapterCandidate], list[dict[str, Any]]]:
    grouped: dict[int | str, list[_ChapterCandidate]] = {}
    for candidate in candidates:
        grouped.setdefault(candidate.chapter_number, []).append(candidate)
    chosen: list[_ChapterCandidate] = []
    diagnostics: list[dict[str, Any]] = []
    conflicts: list[dict[str, Any]] = []
    used_selections: set[int] = set()
    for number, variants in grouped.items():
        ordered = sorted(
            variants, key=lambda item: (item.source.relative_path.casefold(), item.sheet.name.casefold())
        )
        digests = {item.content_digest for item in ordered}
        if len(digests) == 1:
            chosen.append(ordered[0])
            diagnostics.extend(ordered[0].diagnostics)
            if len(ordered) > 1:
                diagnostics.append(
                    {
                        "severity": "information",
                        "code": "chapter.identical-duplicate",
                        "message": f"Chapter {number} appears identically in multiple sources; one copy was retained.",
                        "chapter_id": ordered[0].chapter_id,
                        "details": {
                            "sources": [
                                {"path": item.source.relative_path, "sheet": item.sheet.name}
                                for item in ordered
                            ]
                        },
                        "impact": "No story analysis needs to be repeated for the duplicate copy.",
                    }
                )
            continue
        selection = chapter_sources.get(number) if isinstance(number, int) else None
        selected = [item for item in ordered if _candidate_id(item) == selection]
        if len(selected) == 1:
            used_selections.add(number)  # type: ignore[arg-type]
            chosen.append(selected[0])
            diagnostics.extend(selected[0].diagnostics)
            diagnostics.append(
                {
                    "severity": "information",
                    "code": "chapter.conflict-resolved",
                    "message": f"Chapter {number} uses the source selected by the editor.",
                    "chapter_id": selected[0].chapter_id,
                    "details": {
                        "candidate_id": _candidate_id(selected[0]),
                        "path": selected[0].source.relative_path,
                        "sheet": selected[0].sheet.name,
                    },
                    "impact": "Only the selected chapter version is included in the ready StoryBundle.",
                }
            )
            continue
        conflicts.append(
            {
                "chapter_number": number,
                "question": f"Chapter {number} has different versions. Which source should be used?",
                "candidates": [
                    {
                        "candidate_id": _candidate_id(item),
                        "path": item.source.relative_path,
                        "sheet": item.sheet.name,
                        "content_sha256": item.content_digest,
                    }
                    for item in ordered
                ],
            }
        )
    if conflicts:
        raise ChapterConflictError(conflicts)
    unused = sorted(set(chapter_sources).difference(used_selections))
    if unused:
        raise StoryBundleUsageError(
            "Chapter source selections did not match a current conflict: "
            + ", ".join(str(item) for item in unused)
        )
    return chosen, diagnostics


def _candidate_id(candidate: _ChapterCandidate) -> str:
    identity = {
        "path": candidate.source.relative_path,
        "sheet": candidate.sheet.name,
        "content_sha256": candidate.content_digest,
    }
    return f"candidate-{_json_digest(identity)[:12]}"


def _thought_bubble_diagnostics(
    source: _LoadedSource,
    sheet: SheetSnapshot,
    chapter_id: str,
    lines: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    result = []
    for line in lines:
        raw = line["fields"].get("thought_bubble")
        normalized = _normalized_text(raw)
        if normalized and normalized != "yes":
            result.append(
                _with_chapter(
                    _with_source(
                        {
                            "severity": "warning",
                            "code": "workbook.unrecognized-thought-bubble",
                            "message": "Thought Bubble is not exactly Yes, so the line was not classified as inner monologue.",
                            "line_id": line["line_id"],
                            "details": {"raw_value": raw},
                            "impact": "Thought-bubble-dependent checks must use the preserved raw value.",
                        },
                        source=source,
                    ),
                    chapter_id,
                    sheet.name,
                )
            )
    return result


def _excluded_data_diagnostics(
    source: _LoadedSource,
    sheet: SheetSnapshot,
    header: _HeaderMap,
    chapter_id: str,
    *,
    included_rows: Sequence[int],
) -> list[dict[str, Any]]:
    included = set(included_rows)
    mapped = set(header.columns.values())
    formula_only = [
        cell
        for cell in sheet.cells
        if cell.row > header.row
        and cell.row not in included
        and cell.column in mapped
        and cell.formula is not None
        and _meaningful(cell)
    ]
    if not formula_only:
        return []
    return [
        _with_chapter(
            _with_source(
                {
                    "severity": "information",
                    "code": "workbook.formula-only-rows-excluded",
                    "message": "Rows populated only by helper formulas were excluded from story order.",
                    "details": {
                        "count": len(formula_only),
                        "sample_cells": [cell.coordinate for cell in formula_only[:20]],
                        "truncated": len(formula_only) > 20,
                    },
                    "impact": "Cached helper results are not treated as authored story lines.",
                },
                source=source,
            ),
            chapter_id,
            sheet.name,
        )
    ]


def _validate_chapter_records(
    chapter_id: str,
    lines: Sequence[Mapping[str, Any]],
    choices: Mapping[str, Any],
    source_map: Sequence[Mapping[str, Any]],
) -> None:
    line_ids = [str(line.get("line_id")) for line in lines]
    if len(line_ids) != len(set(line_ids)):
        raise StoryBundleError(f"Duplicate line IDs in {chapter_id}")
    expected = [f"{chapter_id}:l{index:06d}" for index in range(1, len(lines) + 1)]
    if line_ids != expected or [line.get("seq") for line in lines] != list(range(1, len(lines) + 1)):
        raise StoryBundleError(f"Non-contiguous story order in {chapter_id}")
    mapped = [str(item.get("line_id")) for item in source_map]
    if mapped != line_ids:
        raise StoryBundleError(f"Source map is not aligned with story lines in {chapter_id}")
    groups = choices.get("groups")
    if not isinstance(groups, list):
        raise StoryBundleError(f"Choice groups are invalid in {chapter_id}")
    group_ids = {group.get("group_id") for group in groups}
    branch_ids = {
        branch.get("branch_id") for group in groups for branch in group.get("branches", [])
    }
    for group in groups:
        parent = group.get("parent_branch_id")
        if parent is not None and parent not in branch_ids:
            raise StoryBundleError(f"Unknown parent branch {parent!r} in {chapter_id}")
        for branch in group.get("branches", []):
            refs = [branch.get("button_line_id"), *branch.get("content_line_ids", [])]
            merge = branch.get("merge_line_id")
            if merge is not None:
                refs.append(merge)
            if any(ref not in line_ids for ref in refs):
                raise StoryBundleError(f"Choice branch references an unknown line in {chapter_id}")
            if any(child not in group_ids for child in branch.get("child_group_ids", [])):
                raise StoryBundleError(f"Choice branch references an unknown child group in {chapter_id}")
    for line in lines:
        if any(branch not in branch_ids for branch in line.get("branch_path", [])):
            raise StoryBundleError(f"Line has an unknown branch path in {chapter_id}")


def _validate_manifest_data(bundle_path: Path, manifest: Mapping[str, Any]) -> None:
    if manifest.get("format") != FORMAT or manifest.get("format_version") != FORMAT_VERSION:
        raise StoryBundleError("Unsupported StoryBundle format or version")
    if manifest.get("status") != "ready":
        raise StoryBundleError("StoryBundle manifest is not ready")
    bundle_id = manifest.get("bundle_id")
    if not isinstance(bundle_id, str) or re.fullmatch(r"sb-[0-9a-f]{16}", bundle_id) is None:
        raise StoryBundleError("StoryBundle manifest has an invalid bundle ID")
    parser = manifest.get("parser")
    if parser != {"name": PARSER_NAME, "version": PARSER_VERSION}:
        raise StoryBundleError("StoryBundle parser identity is invalid")
    book = manifest.get("book")
    if not isinstance(book, Mapping) or not (
        book.get("title") is None or isinstance(book.get("title"), str)
    ):
        raise StoryBundleError("StoryBundle book identity is invalid")
    chapter_sources = manifest.get("chapter_sources")
    if not isinstance(chapter_sources, Mapping) or any(
        not isinstance(number, str)
        or not number.isdigit()
        or int(number) < 1
        or not isinstance(candidate_id, str)
        or re.fullmatch(r"candidate-[0-9a-f]{12}", candidate_id) is None
        for number, candidate_id in chapter_sources.items()
    ):
        raise StoryBundleError("StoryBundle chapter selections are invalid")
    sources = manifest.get("sources")
    if not isinstance(sources, list) or not sources:
        raise StoryBundleError("StoryBundle manifest has no source inventory")
    source_ids: set[str] = set()
    source_identity: list[dict[str, Any]] = []
    for source in sources:
        if not isinstance(source, Mapping):
            raise StoryBundleError("StoryBundle source inventory is invalid")
        source_id = source.get("source_id")
        path_value = source.get("path")
        digest = source.get("sha256")
        byte_count = source.get("bytes")
        if (
            not isinstance(source_id, str)
            or not source_id
            or source_id in source_ids
            or not isinstance(path_value, str)
            or not path_value
            or PurePosixPath(path_value).is_absolute()
            or ".." in PurePosixPath(path_value).parts
            or not isinstance(digest, str)
            or re.fullmatch(r"[0-9a-f]{64}", digest) is None
            or isinstance(byte_count, bool)
            or not isinstance(byte_count, int)
            or byte_count < 0
            or source.get("kind") != "xlsx"
            or source.get("media_type") != XLSX_MEDIA_TYPE
        ):
            raise StoryBundleError("StoryBundle source inventory is invalid")
        source_ids.add(source_id)
        source_identity.append(
            {"path": path_value, "sha256": digest, "bytes": byte_count}
        )
    chapters = manifest.get("chapters")
    if not isinstance(chapters, list) or not chapters:
        raise StoryBundleError("StoryBundle manifest has no chapter index")
    seen_ids: set[str] = set()
    for entry in chapters:
        if not isinstance(entry, Mapping) or not isinstance(entry.get("chapter_id"), str):
            raise StoryBundleError("StoryBundle chapter index is invalid")
        if entry["chapter_id"] in seen_ids:
            raise StoryBundleError("StoryBundle chapter IDs are not unique")
        seen_ids.add(entry["chapter_id"])
        if entry.get("source_id") not in source_ids or not isinstance(entry.get("sheet"), str):
            raise StoryBundleError(
                f"StoryBundle chapter {entry['chapter_id']} has invalid source provenance"
            )
        content_digest = entry.get("content_sha256")
        if not isinstance(content_digest, str) or re.fullmatch(r"[0-9a-f]{64}", content_digest) is None:
            raise StoryBundleError(
                f"StoryBundle chapter {entry['chapter_id']} has an invalid content digest"
            )
        files = entry.get("files")
        if not isinstance(files, Mapping):
            raise StoryBundleError(f"StoryBundle chapter {entry['chapter_id']} has no files")
        for label in ("chapter", "lines", "choices", "source_map"):
            _verify_file_record(bundle_path, files.get(label))
    expected_identity = {
        "format_version": FORMAT_VERSION,
        "parser_version": PARSER_VERSION,
        "book_title": book.get("title"),
        "sources": source_identity,
        "chapters": [
            {
                "chapter_id": entry["chapter_id"],
                "content_sha256": entry["content_sha256"],
                "source_id": entry["source_id"],
                "sheet": entry["sheet"],
            }
            for entry in chapters
        ],
        "chapter_sources": dict(chapter_sources),
    }
    if bundle_id != f"sb-{_json_digest(expected_identity)[:16]}":
        raise StoryBundleError("StoryBundle manifest identity does not match its bundle ID")
    diagnostics = manifest.get("diagnostics")
    if not isinstance(diagnostics, Mapping):
        raise StoryBundleError("StoryBundle diagnostics index is invalid")
    _verify_file_record(bundle_path, diagnostics)


def _verify_file_record(bundle_path: Path, record: Any) -> None:
    if not isinstance(record, Mapping) or not isinstance(record.get("path"), str):
        raise StoryBundleError("StoryBundle file record is invalid")
    relative = PurePosixPath(record["path"])
    if relative.is_absolute() or ".." in relative.parts:
        raise StoryBundleError(f"StoryBundle file path escapes the bundle: {relative}")
    path = (bundle_path / Path(*relative.parts)).resolve(strict=True)
    try:
        path.relative_to(bundle_path)
    except ValueError as error:
        raise StoryBundleError(f"StoryBundle file path escapes the bundle: {relative}") from error
    if not path.is_file():
        raise StoryBundleError(f"StoryBundle file is missing: {relative}")
    payload = path.read_bytes()
    if record.get("bytes") != len(payload) or record.get("sha256") != sha256(payload).hexdigest():
        raise StoryBundleError(f"StoryBundle file integrity check failed: {relative}")


def _write_json(path: Path, value: Any, *, root: Path) -> dict[str, Any]:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2).encode("utf-8") + b"\n"
    return _write_bytes(path, payload, root=root)


def _write_ndjson(
    path: Path, values: Iterable[Mapping[str, Any]], *, root: Path
) -> dict[str, Any]:
    payload = b"".join(
        json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        + b"\n"
        for value in values
    )
    return _write_bytes(path, payload, root=root)


def _write_bytes(path: Path, payload: bytes, *, root: Path) -> dict[str, Any]:
    with path.open("xb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    return {
        "path": path.relative_to(root).as_posix(),
        "sha256": sha256(payload).hexdigest(),
        "bytes": len(payload),
    }


def _target_bundle_path(
    root: Path, bundle_id: str, output_directory: str | os.PathLike[str] | None
) -> Path:
    if output_directory is None:
        return root / "chapters-reviews" / bundle_id / "story-bundle"
    output = Path(output_directory)
    if not output.is_absolute():
        output = root / output
    output = output.resolve(strict=False)
    try:
        output.relative_to(root)
    except ValueError as error:
        raise StoryBundleUsageError(
            "StoryBundle output must remain inside the Local Project"
        ) from error
    return output


def _receipt(status: str, path: Path, manifest: Mapping[str, Any]) -> BundleBuildReceipt:
    counts = manifest.get("diagnostics", {}).get("counts", {})
    return BundleBuildReceipt(
        status=status,
        bundle_path=path,
        manifest_path=path / "manifest.json",
        bundle_id=str(manifest["bundle_id"]),
        chapters=tuple(entry["number"] for entry in manifest["chapters"]),
        diagnostic_counts=dict(counts) if isinstance(counts, Mapping) else {},
    )


def _number_diagnostics(values: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for index, value in enumerate(values, 1):
        item = dict(value)
        item["diagnostic_id"] = f"diag-{index:05d}"
        result.append(item)
    return result


def _with_source(value: Mapping[str, Any], *, source: _LoadedSource) -> dict[str, Any]:
    return {**dict(value), "source_id": source.source_id, "source_path": source.relative_path}


def _with_chapter(value: Mapping[str, Any], chapter_id: str, sheet: str) -> dict[str, Any]:
    return {**dict(value), "chapter_id": chapter_id, "sheet": sheet}


def _chapter_id(number: int | str) -> str:
    if isinstance(number, int):
        return f"ch-{number:03d}"
    safe = re.sub(r"[^a-z0-9]+", "-", str(number).casefold()).strip("-")
    return f"ch-{safe or 'unresolved'}"


def _chapter_sort_key(candidate: _ChapterCandidate) -> tuple[int, Any, str, str]:
    number = candidate.chapter_number
    if isinstance(number, int):
        return (0, number, candidate.source.relative_path, candidate.sheet.name)
    return (1, str(number), candidate.source.relative_path, candidate.sheet.name)


def _line_kind(fields: Mapping[str, Any], metadata_type: str | None) -> str:
    if metadata_type is not None:
        return "metadata"
    if _normalized_text(fields.get("thought_bubble")) == "yes":
        return "thought_bubble"
    dialogue_type = _normalized_text(fields.get("dialogue_type"))
    if _choice_marker(fields.get("dialogue_type")) is not None:
        return "choice_content"
    if dialogue_type == "text":
        return "narration" if _normalized_text(fields.get("role_id")) == "narration" else "dialogue"
    if "background" in dialogue_type:
        return "background"
    if dialogue_type in {"direction", "stage direction", "transition"}:
        return "direction"
    if any(fields.get(field) not in (None, "") for field in ("animation", "background_panning", "background_music", "sound_effects")) and fields.get("content") in (None, ""):
        return "direction"
    return "other"


def _metadata_type(fields: Mapping[str, Any]) -> str | None:
    for field in ("dialogue_type", "role_id"):
        value = _normalized_text(fields.get(field)).rstrip(":").strip()
        if value in _METADATA_TYPES:
            return _METADATA_TYPES[value]
    return None


def _is_choice_role(line: Mapping[str, Any]) -> bool:
    return _normalized_text(line["fields"].get("role_id")) == "choice"


def _is_callback_control(line: Mapping[str, Any]) -> bool:
    return _normalized_text(line["fields"].get("special_type")) == "callback"


def _meaningful(cell: CellSnapshot) -> bool:
    if cell.value is None:
        return cell.formula is not None
    return not (isinstance(cell.value, str) and cell.value == "")


def _story_value(cell: CellSnapshot) -> bool:
    return cell.formula is None and _meaningful(cell)


def _normalize_label(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    normalized = unicodedata.normalize("NFKC", value).replace("\ufeff", "")
    return re.sub(r"[\W_]+", "_", normalized.casefold(), flags=re.UNICODE).strip("_")


def _header_label_fragments(value: str) -> tuple[str, ...]:
    """Every part of one header cell that may carry the column's own name.

    Production sheets stack a Chinese label above its English name inside a
    single cell, and often append a parenthetical usage note.  Each line, and
    each line with its note removed, becomes a candidate; whole-fragment
    equality against `_HEADER_ALIASES` still decides, so a label that merely
    contains an alias never matches.
    """

    fragments: list[str] = []
    for raw in (value, *re.split(r"[\r\n]+", value)):
        for candidate in (raw, _HEADER_NOTE_RE.sub("", raw)):
            normalized = _normalize_label(candidate)
            if normalized and normalized not in fragments:
                fragments.append(normalized)
    return tuple(fragments)


def _header_field(value: Any) -> str | None:
    """The canonical field one header cell names, or None."""

    if not isinstance(value, str):
        return None
    if not _ALIAS_TO_FIELD:
        _ALIAS_TO_FIELD.update(
            {
                _normalize_label(alias): field
                for field, aliases in _HEADER_ALIASES.items()
                for alias in aliases
            }
        )
    for fragment in _header_label_fragments(value):
        field = _ALIAS_TO_FIELD.get(fragment)
        if field is not None:
            return field
    return None


def _normalized_text(value: Any) -> str:
    return str(value).strip().casefold().replace("_", " ") if value is not None else ""


def _column_letters(column: int) -> str:
    letters = ""
    while column:
        column, remainder = divmod(column - 1, 26)
        letters = chr(65 + remainder) + letters
    return letters


def _json_digest(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return sha256(payload).hexdigest()
