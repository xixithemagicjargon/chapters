# CLI 错误与恢复契约

面向编辑的一切用词以共享 [editor-language.md](editor-language.md) 为准。本文件的错误码、字段名和恢复步骤是给 Agent 看的，**一个都不许出现在编辑面前**：不展示堆栈、内部异常名、错误码，也不要求编辑理解它们。

任一 `prepare`、`metrics` 或 `validate` 命令退出码非零或返回 `status=error` 时读取本文件。`validate` 正常返回的 `status=invalid` 是可修正的校验 receipt，不属于顶层 CLI 错误。

`prepare` 错误不产生可供下游使用的 StoryBundle；只有成功 receipt 中的 `manifest_path` 可以继续进入 Metrics 或 Editorial。后续命令错误也不产生可发布结果。

## 读取错误

CLI 将单个 JSON 对象写到 stderr。Agent 先按顶层 `error` 分流，不从自然语言 `message` 猜错误类型，也不把插件错误归咎于编辑的 Excel。

### `source_input_error`

表示无需修改插件实现即可解决的来源选择或 Workbook 输入问题。读取全部 `issues[]`，每项包含稳定的 `code`、`user_actionable=true`、`remediation`，并在能够可靠定位时包含：

- `source`：能安全解析时为 Local Project 相对路径；文件缺失或位于项目外时保留 Agent 传入的选择值；
- `sheet`；
- `row`、`cell`；
- `observed` 与 `expected`。

先处理责任归属：`project.*`、缺失路径或项目外路径可能是 Agent 选错参数，必须先用文件工具核对并在既定用户范围内自行修正；确认文件确实缺失或不可用时才请编辑处理。大多数 `workbook.*` 表示文件内容、格式或工作表结构需要编辑修复；但 `workbook.no-script-sheet` 也可能表示“全部 Excel”范围中混入了普通表格。此时先核对是否选错文件，并让编辑确认它是否本来就应该是 Chapters 稿件；完全没有 Chapters 表头信号时，不得要求编辑给普通 Notes/跟踪表添加剧本表头。

需要编辑操作时，一次汇总全部问题。按 `editor-language.md` 的清单行形状逐条给出：第一行是位置（Excel 文件名 · Sheet · 行号或单元格），第二行是哪里不对，第三行是怎么改——把 `remediation` 转写成编辑能直接照做的一句中文动作。不得自动修改、另存或覆盖原 Excel。请编辑修复并保存，或用修复后的文件替换原文件；得到确认后，用同一明确来源范围重新运行 `prepare`。

如果 issue 没有 Sheet/行列，说明问题位于工作簿包、文件类型或整本结构层，不得编造位置。

面向编辑的回复固定包含三样，缺一不可：

1. 一句话说清现状 —— 「**这次还没开始审核，你的 Excel 我一个字都没动。**」
2. 按清单行形状汇总的待修清单（位置 / 哪里不对 / 怎么改）。
3. 一句下一步 —— 「**改好保存，或者用新文件替换掉旧的，然后告诉我一声，我重新检查。**」

不要只转述英文 `message`，也不要把它原样贴给编辑。

### `chapter_conflict`

这不是格式损坏，是有多个文件都声称是同一章。读取全部 `conflicts[].candidates`，写成一道编辑能直接回答的选择题，一次问完所有冲突章节：

> 有两个文件都写着第 3 章：`A.xlsx` 的 `Chapter 3`，和 `B.xlsx` 的 `Ch3`。这次该用哪个？

把编辑的回答映射回对应 `candidate_id`，通过 `--chapter-source N=CANDIDATE_ID` 重跑。**`candidate_id` 和任何内部 ID 都不许出现在问题里**——编辑只需要在文件名和 Sheet 名之间做选择。

### `usage_error`

表示 Agent 调用 CLI 的参数不合法。先查看该子命令的 `--help`，自行修正命令后重试，不要求编辑修改 Excel。相同参数错误重复出现时停止，并如实说明插件命令无法执行。

### `io_error`

先用文件工具核对 Agent 选出的路径、文件存在性和可读性。能够在既定用户范围内修正路径时自行修正并重试；文件确实不可访问时，向编辑说明具体文件和所需动作。不要把权限或路径错误说成 Excel 格式错误。

### `story_bundle_error`

表示已发布 Bundle 的完整性、内部状态或其他非输入格式问题。不要指导编辑修改 Excel。停止下游步骤，在内部记录里保留完整 `message`，然后给编辑一个能执行的动作，而不是一个诊断结论：

> **这次是插件自己出了问题，不是你的 Excel 有错。** 这次的审核没有完成，你的文件没有被改动。
> 麻烦把这段话和插件版本号一起发给维护者：<一句话说清插件在哪一步没走通，不含错误码和堆栈>

不要让编辑去看日志、不要贴 `message` 原文、不要建议编辑重装或改文件。

### `metrics_error`

检查 receipt/manifest 路径、章节 scope、annotations 和整本上下文参数。缺少或重复章节、annotation 结构错误、整本声明不成立等由 Agent 修正参数或 analysis 后重试，不要求编辑改 Excel。相同输入仍失败，或错误指向不可变 Metrics 产物冲突时停止，在内部记录里保留 `message`，并按上面 `story_bundle_error` 的话术告诉编辑这是插件自身的问题、请把插件版本号发给维护者。

`validate` 返回 `status=invalid` 时，按 receipt 的全部 `errors[]` 修正 annotations/findings/Metrics 绑定后重新校验；不得回看或修改 Excel。若 `validate` 返回顶层 `story_bundle_error`、`io_error` 或 `usage_error`，仍按本文件对应类别处理。

## 重试边界

只有命令参数、路径或编辑已修复的文件发生变化时才重试。不要对同一输入无变化地循环调用；相同 `error` 和问题清单再次出现时停止并给出可执行的下一步。

## 成功但带异常提示

成功 receipt 可能同时报告 warning/information。它们不是 prepare 错误。先从 manifest 判断诊断是否影响用户范围，再按需读取 `diagnostics.ndjson`：

- 能安全降级的结构不确定性继续审核，并将相关结果保留为 `unknown` 或提醒；
- `chapter.number-unknown` 等会改变章节归属或覆盖范围的问题，用编辑看得懂的文件名和 Sheet 名说明，并在需要其决定时集中询问一次；
- 不要求编辑处理任何诊断 ID 或 warning 代码，也不为消除 warning 回读 Excel；
- 因此保留为「无法判断」的项，按 `editor-language.md` 写进「需要你确认的」并紧跟一句缺什么。
