# StoryBundle v0.1.0

StoryBundle 是 Workbook Adapter 与所有下游之间唯一的文件 Interface。它把 Excel 的工作表、技术列、稀疏单元格、Choice 嵌套、异常恢复和来源定位隐藏在一个可验证的深模块后面。Agent、Metrics 和报告只学习本契约，不学习 OOXML。

当前只有 `.xlsx` 一种输入，因此 Workbook Adapter 是模块内部的具体实现，不公开通用 Adapter Interface。出现第二种真实输入格式时，再在实现内部提取 seam；StoryBundle 的文件 Interface 不因此改变。

## 不变量

- 源 Excel 只读。`prepare` 可以读取明确传入的工作簿；不得修改、重命名、另存或删除它们。
- 在每次 `prepare` 尝试内，Workbook Adapter 将每个明确传入的工作簿读为一个字节快照，并从该快照解析一次。冲突处理后重跑 `prepare` 是新的尝试，会重新读取当时的源快照。`manifest.json` 成功发布后，任何下游步骤都不得再打开 Excel，包括“补上下文”“确认原文”或重新统计。
- Bundle 自包含：完成审计所需的故事文本、选择结构、诊断、来源指纹和 Excel 定位都在 `story-bundle/` 内。源文件随后不可用也不影响读取和溯源。
- Bundle 不可变。`manifest.json` 最后发布；它存在且通过 `validate` 才表示 Bundle 完成。不得修补一个已发布 Bundle，输入变化时创建新 Bundle。
- `story-bundle/` 只保存来源事实和确定性解析结果，不保存 Metrics、Agent 判断、笔记或报告。
- 所有清单路径都是 Bundle 内相对路径。读取者使用 manifest 给出的路径，不按命名约定猜路径，也不接受越过 Bundle 根目录的路径。
- Bundle 内 ID 只在该 Bundle 中稳定。跨 Bundle 比较使用 manifest 中的来源和内容哈希，不把 `line_id`、`group_id` 或 `branch_id` 当作永久业务 ID。

## 目录

```text
<project>/chapters-reviews/<bundle-id>/
├── story-bundle/
│   ├── manifest.json
│   ├── diagnostics.ndjson
│   └── chapters/
│       └── ch-NNN/
│           ├── chapter.json
│           ├── lines.ndjson
│           ├── choices.json
│           └── source-map.ndjson
├── derived/
│   └── metrics/
│       └── <metrics-id>/
│           └── metrics.json
├── analysis/
│   ├── notes/
│   ├── annotations.ndjson
│   ├── findings.ndjson
│   └── audit-report.md            # 仅完整审核生成
```

`story-bundle/` 由 Runtime 拥有并保持只读；`derived/` 是可重建的确定性产物；`analysis/` 是 Agent 可写区，完整报告也属于这里。三者不能互相混写。

## 唯一入口：`manifest.json`

Agent 总是先读取 manifest，并由它决定下一步。manifest 至少描述：

- `format`、`format_version`、`bundle_id`、`status=ready` 和 Parser 身份；
- 输入来源的 `source_id`、项目相对路径与原始字节 SHA-256；
- 按故事顺序排列的章节；
- 每章的 `chapter_id`、来源、Sheet、内容 SHA-256、四个 shard 路径、对象数量和文件 SHA-256；
- `diagnostics.ndjson` 的路径与按严重度汇总的数量。

manifest 不内嵌正文、完整 Choice 树或逐行位置。它是目录和摘要，不是把所有中间结果一次塞进 Agent 上下文的容器。

## Shards

### `diagnostics.ndjson`

一行一个解析诊断。它记录代码、严重度、受影响的 source/chapter/line/group ID 和简短细节。Agent 先看 manifest 的计数；只有存在相关诊断时才筛选本文件。诊断是来源结构事实，不是 Editorial Finding。

### `chapter.json`

一章一个小型元数据文件：章节身份、逻辑顺序、来源与 Sheet 引用、标题、技术列映射和元信息 line 引用。它适合确认范围，不包含完整正文；shard 摘要留在 manifest。

### `lines.ndjson`

一行一个按故事顺序排列的规范行。核心字段包括 `line_id`、`seq`、`kind`、可选 `metadata_type`、稀疏 `fields` 和完整 `branch_path`。

- `fields` 只保留非空来源值；不要期待每条记录拥有相同键。
- `branch_path` 从外层到内层列出当前行所属分支，可表达 L3 及更深嵌套。
- 物理 Excel 行号和单元格不在这里；正文分析无需携带位置噪声。
- **`seq` 是 Bundle 内部的故事行序号，不是 Excel 行号。**两者相差该 Sheet 的表头行数，把 `seq` 当行号报给编辑会给出对不上的位置。要行号就读 `source_map.ndjson` 的 `excel_row`，要单元格就读 `cells` / `range`。
- 需要连续上下文时，按 `seq` 读取一个有界窗口，不加载整章。

#### Callback 区域

`fields.special_type` 为 `Callback`（大小写不敏感）的行是**舞台指示，读者永远看不到**。它分两种，靠 `content` 区分：

- **条件行** —— 措辞不固定，例如 `If players chose "..." in chapter 2`、`If MC picked either PC outfit in chapter 3`、`If player selected "Sassy Saxophone." above`。它开启一个只在该条件成立时展示的变体。
- **结束行** —— 文本固定为 `End callback`，收掉整个区域。

一个区域是 if-elif 链，不是单个块：

```text
条件行 A          <- special_type=Callback
  A 成立时展示的正文
条件行 B          <- special_type=Callback，同时关掉 A 的变体
  B 成立时展示的正文
End callback      <- special_type=Callback，收掉整个区域
```

**同一区域内的多个变体互斥，任何一次阅读只会展示其中一个。** 因此判断“读者连续看到什么”时，必须按展示路径分别计算（区域前正文 + 单个变体 + 区域后正文），既不能把标记行当正文，也不能把多个变体首尾相接。

条件行和结束行都不是叙述散文：不要评价它们的英文写法，也不要把它们当作角色台词或旁白节拍。

### `choices.json`

该章 Choice 结构索引。它保存根组、任意深度的 group/branch 关系、顺序、父分支、结构状态、按钮与合流 `line_id`、Premium/VIP 信号和已词法解析的商业项。

这是查找 PC/FC/PO 候选、L1/L2/L3、分支和合流的首选文件。它只保存确定性结构和信号，不把“回报是否足够”“是否重大剧情转折”等语义判断伪装成 Parser 事实。

### `source-map.ndjson`

一行一个逻辑行到 Excel 行/单元格的映射。来源相对路径和 Sheet 从 manifest/chapter 记录取得；本文件不重复正文值。

Choice Group 与 Branch 通过其按钮、内容或合流 `line_id` 溯源。只有在已形成候选 Finding、需要核对 Excel 坐标或发布最终证据时才读取 source-map。

## 渐进式展露

推荐顺序固定为：

1. 读取 `manifest.json` 的章节目录、计数和诊断摘要。
2. 只读取目标章的 `chapter.json`。
3. 选择类问题先查 `choices.json`；文本类问题先用 `rg` 定位 `lines.ndjson` 中的 ID、角色或短语。
4. 用 `sed` 读取命中附近的有界 NDJSON 行，用 `jq` 过滤精确对象；把需要继续工作的 ID 和结论写入 `analysis/notes/`。
5. 候选问题成立后，最后查 `source-map.ndjson`，补齐 Excel 引用并写 Finding。

示例命令中的路径必须来自 manifest：

```bash
jq '{bundle_id, chapters: [.chapters[] | {chapter_id, files, counts}], diagnostics}' "$manifest_path"
jq '.groups[] | select(.group_id == "ch-003:g0003")' "$choices_path"
rg -n 'ch-003:g0003:b01|ch-003:l000123' "$lines_path"
sed -n '120,150p' "$lines_path"
jq -c 'select(.line_id == "ch-003:l000123")' "$source_map_path"
```

其中 `manifest_path` 来自 `prepare` receipt，其余路径来自目标章的 manifest `files.*.path`，并相对 StoryBundle 根目录解析。

不要用 `cat`、`jq -s` 或等价方式把所有章节、所有行或整个 source-map 一次读入上下文。manifest 告诉 Agent 有什么；`rg`、`jq` 和 `sed` 帮 Agent 只取当前判断需要的内容。

## Runtime Interface

Python 公开面按构建/加载、计算、校验三类职责组织：

```python
build_story_bundle(source_paths, *, project_root, output_directory=None,
                   chapter_sources=None, book_title=None)
load_story_bundle(bundle_path)
verify_story_bundle(bundle)

compute_metrics(bundle_path, *, annotations_path=None, chapter_numbers=None,
                complete_book=False, declared_total_chapters=None)
verify_metrics(metrics_path, *, bundle_path, annotations_path=None)

validate_artifacts(bundle_path, *, metrics_path=None,
                   findings_path=None, annotations_path=None)
```

- `build_story_bundle` 是唯一允许读取 Excel 的 Python 操作，发布后返回 `BundleBuildReceipt`。发生同章多版本冲突时，异常返回每个 path/Sheet 的稳定 `candidate_id`；`chapter_sources` 按章接收该 ID，因此同一工作簿内的不同 Sheet 也能唯一选择。
- 编辑可修复的来源或 Workbook 格式错误使用输入异常携带结构化 `issues[]`，由 CLI 发布为 `source_input_error`；它与 Agent 参数、IO 和已发布 Bundle 完整性错误分开。Agent 的恢复行为见 [command-errors.md](command-errors.md)。
- `load_story_bundle` 只从 Bundle 目录加载已就绪 manifest，并验证 manifest 身份、来源声明、安全相对路径、全部被索引文件的字节摘要，以及 shard 内部身份、计数和 Choice/branch/line/source-map 引用；它返回文件后备的 `StoryBundle`，不读 Excel，也不提供跳过完整性验证的公共开关。
- `verify_story_bundle` 是显式只读复核：无论传入路径还是已加载对象，都从磁盘路径重新加载并完整验证，返回计数摘要，不写产物，也不信任可能过期的内存 manifest。
- `compute_metrics` 只从已发布 Bundle 与可选 annotations 计算；可选 `chapter_numbers` 必须是不重复的自然章号序列，只计算该 scope，并把排序后的规范化 scope 写入 context、receipt 和 Metrics identity。章节 scope 与 `complete_book` 互斥；整本检查始终使用完整 Bundle。结果只发布到规范的 `derived/metrics/<metrics-id>/metrics.json`，并返回 `MetricsReceipt`。
- `verify_metrics` 只读现有 Metrics，使用显式传入的 Bundle 与 annotations，并从产物 context 恢复章节 scope，按当前 config 重算并做字节级比对，同时要求文件位于规范路径；它返回 `MetricsReceipt`，不发布新结果。
- `validate_artifacts` 先只读加载并深层校验 Bundle；Bundle 无效时直接报错。在有效 Bundle 上，它汇总可选 Metrics/annotations/findings 的结构、引用、证据、当前 Editorial Rubric 版本和绑定错误，一次返回 `ArtifactValidationReceipt`，不做 Editorial 判断。annotation/Finding 的 `rubric_version` 缺失或与 `editorial-rubric.md` 顶部 `Version` 不同时校验失败。

Agent 不直接调用内部 Parser。面向 Agent 的入口为：

```text
python3 shared/scripts/chapters.py prepare  ...
python3 shared/scripts/chapters.py metrics  ...
python3 shared/scripts/chapters.py validate ...
```

- `prepare` 接收明确的 `.xlsx` 路径并返回 Bundle 与 manifest 路径；它是唯一可读取 Excel 的命令。
- `metrics` 只接收已发布的 manifest，可重复使用 `--chapter N` 限定自然章号 scope，并把确定性结果写到同级 `derived/metrics/<metrics-id>/`；`--chapter` 与 `--complete-book` 互斥。CLI receipt 返回本次结果的准确路径与 scope。不同 annotations/context（包括章节 scope）产生不同 ID，不覆盖旧结果。
- `validate` 校验 Bundle 或分析产物的结构、哈希和引用，不重新打开 Excel，也不做 Editorial 判断。

Runtime 不生成模型 prompt、task、分片、submission、checkpoint 或 finalize 工作流。已有 Agent 直接依据 Skill 和共享规则浏览 Bundle、写 notes/annotations/findings，并在需要时生成报告。
