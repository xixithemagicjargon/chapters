# 审核历史与 Analysis 更新契约

仅在 `prepare` 返回 `reused`，或用户要求处理 Local Project 的全部 Excel 时读取本文件。历史比较必须发生在 `prepare` 成功之后；不要预先打开 Excel 或另建来源索引。

## 当前审核

以成功 receipt 返回的 `manifest_path` 为当前 manifest。路径解析后的当前 manifest 必须从所有历史候选中排除；当前 Bundle 永远不能作为自己的比较基线。

## `created`：选择历史基线

从同一 Local Project 的 `chapters-reviews/*/story-bundle/manifest.json` 查找候选，丢弃当前 manifest、非 `ready`、格式/Parser 主版本不兼容或无法读取的候选。候选还必须满足至少一个安全书籍身份条件：与当前 manifest 至少有一个相同的项目相对 source path；或者两者 `book.title` 均非空且完全相同。只有章号重合不能证明是同一本书。

对剩余候选按以下顺序选择一个基线：

1. 当前 `book.title` 非空时，优先同标题；
2. 与当前 manifest 重合的项目相对 source path 数量最多；
3. 与当前 manifest 重合的自然章号数量最多；
4. `created_at` 最新。

若没有满足安全书籍身份条件的候选，则没有历史基线：当前全部章节视为 `new`，不得自比较、仅凭章号跨书匹配或跳过评价。工作簿全部重命名且没有明确书名时，宁可放弃复用，也不猜测基线。

选定一个基线后，按自然章号比较 `content_sha256`：同章同摘要为 `unchanged`，同章不同摘要为 `changed`，只在当前出现为 `new`，只在基线出现为 `removed`。向编辑展示人类可读的章节与文件变化，不展示 Bundle ID 或内部哈希。

确定性 Metrics 可以重算。只有 `unchanged` 章、且 `rubric_version` 与当前 `editorial-rubric.md` 完全一致的旧 analysis 记录才可作为复用候选，并且必须复制到当前 analysis 候选集后，针对当前 Bundle 重新 `validate`；不能假定跨 Bundle 的逻辑 ID 永久稳定。旧记录缺少版本或版本不同，表示其语义规则已经过期，必须按当前 Rubric 重做，不能只改版本号。`changed`、`new` 及其影响的跨章结论必须复查。

## `reused`：复用同一 Bundle

`reused` 只证明 StoryBundle 输入与选择未变，不证明 `analysis/` 正确或适合本次用户范围。先确认每条 annotation/Finding 的 `rubric_version` 与当前 Rubric 相同，再对准备复用的 annotations、findings 和 Metrics 重新运行 `validate`。缺少版本或版本不匹配时按当前规则重做语义分析，不要原样复用或仅替换版本字段。

- 已验证产物完整覆盖本次请求时直接复用，不重复追加记录；
- 覆盖不足或需要修改时，先定义本次活动范围：目标章/选择点与适用 `rule_id`；
- 不向现有 NDJSON 盲目追加。

生成完整的候选记录集合时：

- annotations 以 `(key, target_ref)` 唯一；活动范围内旧记录全部由本次保留或更新后的记录替换，范围外只保留仍能通过当前 Bundle 验证的记录；
- findings 以 `(rule_id, scope_ref)` 划定替换范围；活动范围内先移除旧记录，再写入本次要保留的完整 strength/risk/suggestion/information 集合；
- 完整审核把本次用户要求的章节/选择范围和其中全部适用 Rubric 视为活动范围，因此重写该范围的 canonical annotations/findings 集合，而不是累积历次结果；只有用户明确要求审核整个 Bundle 时，活动范围才是整个 Bundle。范围外记录仅在仍能针对当前 Bundle 与 Rubric 验证时保留，不得因一次局部完整审核而删除。

先用候选 annotations 生成或验证对应 Metrics，再对候选 annotations、findings 和 Metrics 一起运行 `validate`。只有验证成功的完整集合才能成为本次答复或报告的来源。旧 `audit-report.md` 是展示层，不属于已验证结构化状态；完整审核每次都从本次已验证产物重新生成报告。
