# Findings v0.1.0

Finding 是审核对外发布的最小结论单位。确定性结果和 Editorial 判断使用同一证据语言，但来源与分类保持分离；不生成总分或把主观判断包装成硬失败。

## 产物归属

```text
<review>/derived/metrics/<metrics-id>/metrics.json
                                             # Runtime 的完整确定性计算
<review>/analysis/notes/                    # Agent 草稿，可随分析推进更新
<review>/analysis/annotations.ndjson        # Agent 的显式语义判断
<review>/analysis/findings.ndjson           # Agent 发布的 Editorial/信息 Findings
```

Runtime 不写 `analysis/`；Agent 不写 `story-bundle/` 或改写 Metrics 观察值。硬检查与信息项直接保存在 `metrics.json`，不复制成第二份 Findings 文件。每次 Metrics receipt 给出准确的 `<metrics-id>` 和结果路径；不同 annotations/context 形成新的目录，不覆盖旧结果。语义 annotation 是独立输入：需要它的确定性规则在 annotation 缺失或证据不足时返回 `unknown`，不得猜成 `true` 或 `false`。

## 三种 Finding

| `kind` | `classification` | 用途 |
|---|---|---|
| `hard_check` | `pass`、`fail`、`unknown` | Runtime 按 `metrics-config.json` 得出的确定性或依赖完备的结果 |
| `editorial` | `strength`、`risk`、`suggestion` | Agent 按 `editorial-rubric.md` 作出的编辑判断 |
| `information` | `report`、`reminder` | 数值事实、例外价位、缺失上下文或需编辑留意事项 |

`unknown` 只表示规则适用但所需数据或语义依赖不足；它不是失败，也不能为完成报告而补猜。不适用的规则不生成硬检查 Finding。每条 Editorial Finding 必须带 `confidence: high|medium|low`。

## NDJSON 记录

`findings.ndjson` 每个物理行是一个完整 JSON 对象，只允许 Agent 写入 `editorial` 与 `information`；`hard_check` 只由 Runtime 写在 `metrics.json`。每条记录至少包含：

- `rubric_version`：逐字复制当前 `editorial-rubric.md` 顶部的 `Version`；
- `rule_id`；
- `kind` 和与之匹配的 `classification`；
- `scope_ref`：一个能在当前 StoryBundle 中解析的 chapter/group/branch/line ID；
- `evidence`：一个或多个下述证据对象；
- `analysis_zh`：简短中文结论及其依据。

按需要添加 `observed`、`expected`、`confidence`、`suggestion_en`。`suggestion_en` 只用于可以直接采用的具体英文修改建议，且永不自动回写 Excel。

最小 Editorial 记录示例：

```json
{"rubric_version":"0.44.0","rule_id":"editorial.button-intent","kind":"editorial","classification":"strength","scope_ref":"ch-001:g0011:b01","evidence":[{"line_id":"ch-001:l000190","field":"content","excerpt":"Show my skills and steal my button back from him.","source":{"path":"HMQ 1-5.xlsx","sheet":"Chapter 1","row":193,"cell":"E193"}}],"analysis_zh":"按钮表达了明确行动与即时目标。","confidence":"high"}
```

## 证据

### 稿件证据

每个稿件证据使用最小形状：

```json
{
  "line_id": "ch-001:l000190",
  "field": "content",
  "excerpt": "Show my skills and steal my button back from him.",
  "source": {
    "path": "HMQ 1-5.xlsx",
    "sheet": "Chapter 1",
    "row": 193,
    "cell": "E193"
  }
}
```

分析时先记录 `line_id`、`field` 和逐字来自 `lines.ndjson` 的 `excerpt`；不要引用 notes 中的二手摘要。Group、Branch 或 Chapter 作为结论范围写入 `scope_ref`，上下文路径可以保留在 notes，不扩张正式 Evidence Interface。

候选 Finding 成立后才读取该章 `source-map.ndjson`，并在最终记录中补齐：

- manifest 中的项目相对路径；
- 原始 Sheet 名；
- Excel 行与单元格；
- 与逻辑引用一致的原文摘录。

这样，Agent 平时使用干净的逻辑 ID，发布时仍可从 Finding 追到准确 Excel 位置。不得为了补位置重新读取 Excel。

`line_id`、`scope_ref`、`target_ref` 等逻辑 ID 是 NDJSON 的必需字段，只服务 `validate` 的核对。**给编辑看的报告和答复只写 Excel 定位，不出现这些内部标识符。** 行号取 source map 的 `excel_row`，不要用 `lines.ndjson` 的 `seq` —— 它是 Bundle 内部序号，和 Excel 行号相差表头行数。

Metrics 聚合的完整计算范围、输入 ID、观察值与期望值保存在 receipt 指向的 `metrics.json`；不能只保存最终数字。Agent-authored Finding 仍引用直接相关的 line/field 证据，不复制或重算 Metrics。缺章、未证明为最终章、缺少全书覆盖等没有单一单元格的事实由 Metrics 的 `unknown`/reminder 与 `metrics.json` 表达，不伪造空白单元格引用。

## Annotations

`analysis/annotations.ndjson` 一行一个语义判断，最小字段是 `rubric_version`、`key`、`target_ref`、`value` 和非空 `evidence`；可按需添加 confidence 与简短理由。`rubric_version` 必须逐字匹配当前 `editorial-rubric.md` 顶部的 `Version`。只允许 `is_customization`、`intimacy_level`、`major_plot_turn`、`pc_category`、`is_outfit_choice` 五个 key，且 `target_ref` 必须是当前 Bundle 中存在的 Choice Group ID；evidence 使用与 Finding 相同的 line/field 形状。例如捏脸流程、亲密度等级或“重大剧情转折”属于 annotation，而不是 Parser 字段。

前三个 key 服务确定性 Metrics。`pc_category` 是纯分类标签，不参与任何数值计算：它的 `value` 是 1–2 个标签码组成的数组，标签码取自 `editorial-rubric.md` 的 `classify.pc-category`；两个标签必须来自不同分类；`["unmatched"]`（判定为不属于现有分类）和 `["unknown"]`（证据不足未判定）只能单独出现。每一个识别出来的 PC Choice Group 都需要一条自己的记录，缺记录不等于 `unmatched`。

`is_outfit_choice` 是布尔或 `unknown`，只能给 Parser 的标记短语漏掉的换装选择**补上** PO；写 `false` 不会撤销标记短语已经确认的 PO。缺这条 annotation 不会让任何指标变成 `unknown`，Parser 的判定照常生效。判定标准见 `editorial-rubric.md` 的 `classify.outfit-choice`。

```json
{"rubric_version":"0.44.0","key":"major_plot_turn","target_ref":"ch-023:g0004","value":true,"evidence":[{"line_id":"ch-023:l000177","field":"content","excerpt":"..."}],"confidence":"high"}
```

Metrics 只能显式读取当前 review 的 annotations；缺失、`unknown` 或引用无效都会让依赖规则保持 `unknown`。Agent 修改 annotation 后可以重跑 Metrics，但不会修改 StoryBundle。

## 发布前校验

最终 Findings 必须满足：

1. `kind` 与 `classification` 匹配；
2. `scope_ref`/`target_ref` 与所有 `line_id` 在当前 manifest 及 shard 中存在；
3. excerpt 与指定 `lines.ndjson` 字段完全一致；
4. `source` 精确等于当前 Bundle 由 source-map 解出的 `path/sheet/row/cell`；
5. 每条 annotation 与 Finding 的 `rubric_version` 都等于当前 `editorial-rubric.md` 的版本；
6. Editorial 规则只使用 `editorial-rubric.md`，硬检查只使用 `metrics-config.json`；
7. `unknown` 的缺失依赖和最终提醒没有被静默丢弃。

`shared/scripts/chapters.py validate` 可以检查结构、哈希、外键和可追溯性；它不评价叙事含义，也不生成或改写 Finding。

## Agent 工作方式

Agent 直接阅读 Skill、规则和 StoryBundle。它把阶段性定位写入 notes，把可复用的语义判断写入 annotations，把最终结论写入 findings。不要生成 prompt 包、模型 task、submission、覆盖账本、checkpoint 或模型 finalize 产物。
